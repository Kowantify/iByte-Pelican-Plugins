<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use IByte\MinecraftManager\Models\Operation;
use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\Input;

/** Write-ahead recovery outside the server volume; no manager directory on Wings. */
final class InstallWorkspace
{
    private array $journal = [];
    private array $directories = [];
    private int $sequence = 0;
    private int $backupBytes = 0;

    public function __construct(private NodeFiles $node, private Operation $operation)
    {
        $plan = $operation->plan;
        if (($plan['filesystem_format'] ?? null) === 2) {
            $this->journal = $plan['journal'] ?? [];
            $this->directories = $plan['temporary_directories'] ?? [];
        }
    }

    public function directory(): string { return storage_path('app/minecraft-manager-recovery/'.$this->operation->id); }

    public function save(): void
    {
        $plan = $this->operation->fresh()->plan;
        $plan['filesystem_format'] = 2;
        $plan['journal'] = $this->journal;
        $plan['temporary_directories'] = $this->directories;
        $this->operation->update(['plan'=>$plan]);
    }

    /** Reserve an absent temporary sibling before the native downloader can write it. */
    public function temporary(string $hint, string $extension = 'part', bool $persist = true): string
    {
        Input::path($hint);
        $parent = dirname($hint);
        $path = ($parent === '.' ? '' : $parent.'/').'.download-'.$this->operation->id.'-'.(++$this->sequence).'.'.$extension;
        if ($this->node->hashOrNull($path) !== null || isset($this->journal[$path])) { throw new Failure('node_path_collision', ['file'=>$path]); }
        $this->journal[$path] = ['old'=>null, 'new'=>null, 'allowed'=>[], 'temporary'=>true, 'download'=>true];
        if ($persist) { $this->save(); $this->parents([$path]); }
        return $path;
    }

    /** Capture old bytes and persist expected writes before making any live change. */
    public function reserve(array $writes, bool $persist = true): void
    {
        $untracked = array_filter(array_keys($writes), fn ($path) => !isset($this->journal[$path]));
        $entries = $this->node->entries($untracked);
        foreach ($writes as $path=>$hash) {
            Input::nodePath($path);
            if (explode('/', $path)[0] === '.minecraft-manager') { throw new Failure('unsafe_path'); }
            if (!isset($this->journal[$path])) {
                $old = null; $backup = null;
                if (isset($entries[$path])) {
                    if (!($entries[$path]['file'] ?? false) || ($entries[$path]['symlink'] ?? false)) { throw new Failure('node_path_collision', ['file'=>$path]); }
                    $directory = $this->directory();
                    if (!is_dir($directory) && !mkdir($directory, 0700, true)) { throw new Failure('staging_unwritable'); }
                    $backup = hash('sha256', $path).'.bin';
                    $result = $this->node->verifiedRead($path, null, [], $directory.'/'.$backup);
                    chmod($directory.'/'.$backup, 0600);
                    $this->backupBytes += $result['size'];
                    if ($this->backupBytes > 2147483648) { throw new Failure('pack_size_limit'); }
                    $old = $result['sha256'];
                }
                $this->journal[$path] = ['old'=>$old, 'new'=>$old, 'allowed'=>[], 'backup_disk'=>$backup, 'temporary'=>false];
            }
            $this->journal[$path]['new'] = $hash;
            if ($hash !== null) { unset($this->journal[$path]['download']); }
            if (!in_array($hash, $this->journal[$path]['allowed'], true)) { $this->journal[$path]['allowed'][] = $hash; }
        }
        if ($persist) { $this->save(); }
    }

    public function parents(array $paths): void
    {
        $create = [];
        foreach ($paths as $path) {
            $parent = dirname(Input::nodePath($path));
            while ($parent !== '.') {
                $create[$parent] = true;
                $parent = dirname($parent);
            }
        }
        uksort($create, static fn ($a, $b) => substr_count($a, '/') <=> substr_count($b, '/'));
        foreach ($create as $directory=>$_) {
            if (!$this->node->exists($directory)) { $this->directories[$directory] = true; }
        }
        $this->save();
        foreach ($create as $directory=>$_) { $this->node->mkdir($directory); }
    }

    public function expect(string $path, ?string $hash): void
    {
        $current = $this->node->hashOrNull($path);
        if ($current !== $hash) { throw new Failure('file_changed_during_install', ['file'=>$path]); }
    }

    public function original(string $path): ?string { return $this->journal[$path]['old']; }

    public function promote(string $source, string $path, string $hash): void
    {
        if (($this->journal[$path]['new'] ?? null) !== $hash || !isset($this->journal[$source]) || !in_array(null, $this->journal[$source]['allowed'], true)) {
            throw new Failure('operation_ownership_lost');
        }
        $this->expect($source, $hash);
        $this->expect($path, $this->original($path));
        if ($this->original($path) !== null) { $this->node->remove($path); }
        $this->node->move($source, $path);
        $this->expect($path, $hash);
    }

    public function retire(string $path, string $hash): void
    {
        $this->reserve([$path=>null]);
        $this->expect($path, $hash);
        $this->node->remove($path);
    }

    /** Root extraction is temporary. Existing entries are put back by native rename. */
    public function expand(string $archive, array $entries, array $selected, array $directories = [], ?callable $progress = null): array
    {
        $writes = [];
        foreach ($entries as $path=>$local) { $writes[$path] = hash_file('sha256', $local); }
        $this->reserve($writes);
        $this->parents([...array_keys($entries), ...array_map(static fn ($directory) => $directory.'/.placeholder', $directories)]);
        $saved = []; $results = []; $targets = []; $transitions = [];
        foreach ($entries as $path=>$local) {
            if ($this->original($path) !== null) {
                $saved[$path] = $this->temporary($path, 'part', false);
                $transitions[$saved[$path]] = $this->original($path);
            }
            if (isset($selected[$path])) {
                $targets[$path] = $this->temporary($selected[$path], 'part', false);
                $transitions[$targets[$path]] = $writes[$path];
            }
            $transitions[$path] = null;
        }
        $this->reserve($transitions);
        $this->parents([...array_values($saved), ...array_values($targets)]);
        foreach ($entries as $path=>$local) {
            $this->node->assertStopped();
            $this->expect($path, $this->original($path));
            if ($this->original($path) !== null) {
                $temporary = $saved[$path];
                $this->node->move($path, $temporary);
            }
        }
        $this->node->extract($archive, '.');
        $completed = 0;
        foreach ($entries as $path=>$local) {
            $hash = $writes[$path];
            $this->expect($path, $hash);
            if (isset($selected[$path])) {
                $target = $targets[$path];
                $this->node->move($path, $target);
                $results[$path] = $target;
            } else {
                $this->node->remove($path);
            }
            if (isset($saved[$path])) {
                $this->expect($saved[$path], $this->original($path));
                $this->node->move($saved[$path], $path);
            }
            ++$completed;
            if ($progress && ($completed % 25 === 0 || $completed === count($entries))) { $progress(['phase'=>'verify', 'files'=>$completed, 'total'=>count($entries), 'file'=>$path]); }
        }
        return $results;
    }

    public function rollback(): void
    {
        // Check ALL paths first. Never partially restore around an operator edit.
        foreach ($this->journal as $path=>$item) {
            $this->node->assertStopped();
            if (!$this->node->exists($path)) { continue; }
            $this->node->assertRegular($path);
            $hash = $this->node->hash($path);
            if ($hash !== $item['old'] && !in_array($hash, $item['allowed'], true) && empty($item['download'])) {
                throw new Failure('file_changed_during_install', ['file'=>$path]);
            }
        }
        foreach ($this->journal as $path=>$item) {
            if ($item['old'] !== null) { $this->backup($path, $item); }
        }
        foreach (array_reverse($this->journal, true) as $path=>$item) {
            $this->node->assertStopped();
            $current = $this->node->exists($path) ? $this->node->hash($path) : null;
            if ($current === $item['old']) { continue; }
            if ($current !== null) { $this->node->remove($path); }
            if ($item['old'] !== null) {
                $backup = $this->backup($path, $item);
                // Exceptional recovery only: original user bytes, never a provider payload.
                $this->node->upload($path, $backup);
                $this->expect($path, $item['old']);
            }
        }
    }

    private function backup(string $path, array $item): string
    {
        $name = hash('sha256', $path).'.bin';
        $file = $this->directory().'/'.$name;
        if (($item['backup_disk'] ?? '') !== $name || !is_file($file) || is_link($file) || hash_file('sha256', $file) !== $item['old']) {
            throw new Failure('rollback_backup_missing', ['file'=>$path]);
        }
        return $file;
    }

    public function cleanup(bool $removeBackups): void
    {
        $temporary = array_keys(array_filter($this->journal, static fn ($item) => !empty($item['temporary'])));
        $entries = $this->node->entries($temporary);
        foreach ($this->journal as $path=>$item) {
            if (empty($item['temporary']) || !isset($entries[$path])) { continue; }
            if (!($entries[$path]['file'] ?? false) || ($entries[$path]['symlink'] ?? false)) { throw new Failure('node_path_collision', ['file'=>$path]); }
            $current = $this->node->hashOrNull($path);
            if ($current === null) { continue; }
            if (!in_array($current, $item['allowed'], true) && empty($item['download'])) { throw new Failure('file_changed_during_install', ['file'=>$path]); }
            $this->node->remove($path);
        }
        $directories = array_keys($this->directories);
        usort($directories, static fn ($a, $b) => strlen($b) <=> strlen($a));
        foreach ($directories as $directory) { $this->node->removeEmptyDirectory($directory); }
        if ($removeBackups && is_dir($this->directory()) && !is_link($this->directory())) {
            foreach (new \FilesystemIterator($this->directory()) as $file) {
                if ($file->isFile() && !$file->isLink() && preg_match('/\A[0-9a-f]{64}\.bin\z/D', $file->getFilename())) { unlink($file->getPathname()); }
            }
            if (!(new \FilesystemIterator($this->directory()))->valid()) { rmdir($this->directory()); }
        }
    }
}
