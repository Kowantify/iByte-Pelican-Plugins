<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Console;

use App\Models\Server;
use App\Repositories\Daemon\DaemonServerRepository;
use IByte\MinecraftManager\Models\Operation;
use IByte\MinecraftManager\Operations\NodeFiles;
use IByte\MinecraftManager\Operations\InstallWorkspace;
use Illuminate\Console\Command;
use Throwable;

final class ReconcileInstall extends Command
{
    protected $signature = 'minecraft-manager:reconcile {operation} {--inspect : Show recovery paths and checksums} {--worker-stopped : Acknowledge that the install worker is stopped} {--restore-files : Restore verified private recovery copies for a direct install}';
    protected $description = 'Verify manually restored files/startup and release an interrupted install reservation';

    public function handle(): int
    {
        $op = Operation::find($this->argument('operation'));
        if (!$op) { $this->error('Operation not found.'); return self::FAILURE; }
        $journal = $op->plan['journal'] ?? [];
        if ($this->option('inspect')) {
            $this->line(json_encode(['status' => $op->status, 'journal' => $journal,
                'private_recovery_directory'=>storage_path('app/minecraft-manager-recovery/'.$op->id)], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
            return self::SUCCESS;
        }
        $beforeApply = in_array($op->status, ['queued', 'preflight', 'downloading', 'verifying'], true);
        $stale = ($beforeApply || in_array($op->status, ['applying', 'verifying-result', 'rolling-back'], true)) && $op->updated_at->lt(now()->subSeconds(1860));
        if ($beforeApply && $stale && !$journal && $this->option('worker-stopped')) {
            $op->update(['status' => 'failed', 'step' => 'interrupted-before-apply', 'error_code' => 'worker_interrupted', 'server_slot' => null, 'finished_at' => now()]);
            $this->info('Stale operation stopped before any live replacement; reservation released. Staging files may remain.');
            return self::SUCCESS;
        }
        if (!$this->option('worker-stopped') || (!$stale && $op->status !== 'needs-reconciliation') || !$journal) {
            $this->error('Stop the install worker and restore the recorded files/startup first. Use --inspect. Only interrupted installs with a journal can be reconciled; active phases must be older than 31 minutes.');
            return self::FAILURE;
        }
        try {
            $server = Server::findOrFail($op->server_id);
            if ($server->uuid !== $op->server_uuid || $server->node_id !== $op->node_id) { throw new \IByte\MinecraftManager\Support\Failure('source_identity_or_plugin_changed'); }
            $node = app(NodeFiles::class, ['server' => $server]); $node->assertStopped();
            $direct = ($op->plan['filesystem_format'] ?? null) === 2;
            $workspace = $direct ? new InstallWorkspace($node, $op) : null;
            if ($this->option('restore-files')) {
                if (!$workspace) { $this->error('Use the recorded node backup paths for this older install.'); return self::FAILURE; }
                $workspace->rollback();
            }
            foreach ($journal as $path => $item) {
                if ($direct && !empty($item['temporary'])) { continue; }
                $current = $node->exists($path) ? $node->hash($path) : null;
                if ($current !== $item['old']) { $this->error('File still differs from recorded pre-install state: '.$path); return self::FAILURE; }
            }
            $previous = $op->plan['previous_startup'] ?? null;
            if (!$previous || $server->startup !== $previous['startup'] || $server->image !== $previous['docker_image'] || (bool) $server->skip_scripts !== (bool) $previous['skip_scripts']) { $this->error('Restore the pre-install startup/image settings before reconciliation.'); return self::FAILURE; }
            app(DaemonServerRepository::class)->setServer($server)->sync();
            if ($workspace) { $workspace->cleanup(true); }
            $op->update(['status' => 'failed', 'step' => 'manually-restored-and-verified', 'server_slot' => null, 'finished_at' => now()]);
            $this->info('Pre-install files and startup verified; operation reservation released. Backups retained.');
            return self::SUCCESS;
        } catch (Throwable $error) {
            $this->error($error instanceof \IByte\MinecraftManager\Support\Failure ? $error->reason : 'Node verification or sync failed. Reservation retained.');
            return self::FAILURE;
        }
    }
}
