<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use App\Models\Server;
use App\Repositories\Daemon\DaemonFileRepository;
use App\Repositories\Daemon\DaemonServerRepository;
use GuzzleHttp\Psr7\Utils;
use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\Input;

class NodeFiles
{
    public function __construct(protected Server $server) {}

    protected function files(): DaemonFileRepository { return app(DaemonFileRepository::class)->setServer($this->server); }

    public function assertStopped(): void
    {
        $fresh = $this->server->fresh();
        if (!$fresh || $fresh->uuid !== $this->server->uuid || $fresh->node_id !== $this->server->node_id || $fresh->status !== null || $fresh->transfer) {
            throw new Failure('server_state_changed');
        }
        $state = app(DaemonServerRepository::class)->setServer($fresh)->getDetails(5)['state'] ?? 'unknown';
        if ($state !== 'offline') { throw new Failure($state === 'missing' ? 'node_unavailable' : 'server_must_be_stopped'); }
    }

    public function mkdir(string $path): void
    {
        $root = '/';
        foreach (explode('/', Input::path($path)) as $part) {
            $entries = $this->files()->getDirectory($root);
            $entry = collect($entries)->firstWhere('name', $part);
            // Repository listings are raw Wings Stat JSON, not Panel File models.
            if ($entry && (!($entry['directory'] ?? false) || ($entry['file'] ?? true) || ($entry['symlink'] ?? false))) {
                throw new Failure('node_path_collision', ['file' => rtrim($root, '/').'/'.$part]);
            }
            if (!$entry) { $this->files()->createDirectory($part, $root)->throw(); }
            $root = rtrim($root, '/') . '/' . $part;
        }
    }

    public function exists(string $path): bool
    {
        Input::path($path);
        try { return collect($this->files()->getDirectory('/' . (dirname($path) === '.' ? '' : dirname($path))))->contains('name', basename($path)); }
        catch (\Illuminate\Http\Client\RequestException $error) { if ($error->response->status() === 404) { return false; } throw $error; }
    }

    public function upload(string $path, string $local): void
    {
        Input::path($path);
        if (dirname($path) !== '.') { $this->mkdir(dirname($path)); }
        $handle = fopen($local, 'rb');
        if ($handle === false) { throw new Failure('staging_unwritable'); }
        try {
            $this->files()->getHttpClient()->timeout(300)->withQueryParameters(['file' => '/' . $path])
                ->withBody(Utils::streamFor($handle), 'application/octet-stream')
                ->post('/api/servers/' . $this->server->uuid . '/files/write')->throw();
        } finally { if (is_resource($handle)) { fclose($handle); } }
    }

    public function hash(string $path, int $limit = 536870912): string
    {
        Input::path($path);
        $response = $this->files()->getHttpClient()->timeout(300)->withOptions(['stream' => true])
            ->get('/api/servers/' . $this->server->uuid . '/files/contents', ['file' => '/'.$path, 'download' => '1'])->throw();
        $body = $response->toPsrResponse()->getBody(); $hash = hash_init('sha256'); $bytes = 0;
        try {
            while (!$body->eof()) {
                $chunk = $body->read(65536); $bytes += strlen($chunk);
                if ($bytes > $limit) { throw new Failure('artifact_size_limit'); }
                hash_update($hash, $chunk);
            }
            $length = $response->header('Content-Length');
            if ($length !== '' && $bytes !== (int) $length) { throw new Failure('size_mismatch'); }
        } finally { $body->close(); }
        return hash_final($hash);
    }

    public function text(string $path, int $limit = 1048576): string
    {
        if (!$this->exists($path)) { return ''; }
        $response = $this->files()->getHttpClient()->timeout(20)->withOptions(['stream' => true])
            ->get('/api/servers/'.$this->server->uuid.'/files/contents', ['file' => '/'.Input::path($path)])->throw();
        $body = $response->toPsrResponse()->getBody();
        try { $text = $body->read($limit + 1); if (strlen($text) > $limit) { throw new Failure('artifact_size_limit'); } return $text; }
        finally { $body->close(); }
    }

    public function move(string $from, string $to): void
    {
        Input::path($from); Input::path($to);
        if (dirname($to) !== '.') { $this->mkdir(dirname($to)); }
        $this->files()->renameFiles('/', [['from' => $from, 'to' => $to]])->throw();
    }

    public function remove(string $path): void { $this->files()->deleteFiles('/', [Input::path($path)])->throw(); }
}
