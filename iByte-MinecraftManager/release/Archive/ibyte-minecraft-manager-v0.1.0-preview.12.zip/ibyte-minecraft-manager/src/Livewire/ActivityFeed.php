<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Livewire;

use App\Models\Server;
use IByte\MinecraftManager\Models\Operation;
use IByte\MinecraftManager\Operations\ReviewService;
use IByte\MinecraftManager\Support\Access;
use IByte\MinecraftManager\Support\Failure;
use Livewire\Attributes\Locked;
use Livewire\Attributes\On;
use Livewire\Component;

final class ActivityFeed extends Component
{
    #[Locked] public bool $admin = false;
    #[Locked] public ?int $serverId = null;
    #[Locked] public ?string $serverUuid = null;
    #[Locked] public ?string $error = null;

    public function mount(bool $admin = false, ?int $serverId = null, ?string $serverUuid = null): void
    {
        $this->admin = $admin; $this->serverId = $serverId; $this->serverUuid = $serverUuid;
        $this->authorizeFeed();
    }

    private function authorizeFeed(): ?Server
    {
        if ($this->admin) { abort_unless(auth()->user()?->isRootAdmin(), 403); return null; }
        $server = Server::find($this->serverId);
        abort_unless($server && $server->uuid === $this->serverUuid, 403);
        app(Access::class)->authorize(auth()->user(), $server);
        return $server;
    }

    public function cancelReview(string $id): void
    {
        $server = $this->authorizeFeed(); abort_unless($server && !$this->admin, 403);
        $this->error = null;
        try { app(ReviewService::class)->cancel(auth()->user(), $server, $id); }
        catch (Failure $error) { $this->error = $error->reason; }
    }

    public function acknowledge(string $id): void
    {
        $server = $this->authorizeFeed(); abort_unless($server && !$this->admin, 403);
        app(ReviewService::class)->acknowledge(auth()->user(), $server, $id);
    }

    #[On('imm-operation-queued')]
    public function refreshProgress(): void { $this->authorizeFeed(); }

    public function render(): \Illuminate\Contracts\View\View
    {
        $server = $this->authorizeFeed();
        $operations = Operation::query();
        if ($server) { $operations->where('server_id', $server->id)->where('server_uuid', $server->uuid)->orderByRaw('server_slot IS NOT NULL DESC'); }
        return view('ibyte-minecraft-manager::activity-feed', ['operations' => $operations->latest()->limit($this->admin ? 50 : 30)->get()]);
    }
}
