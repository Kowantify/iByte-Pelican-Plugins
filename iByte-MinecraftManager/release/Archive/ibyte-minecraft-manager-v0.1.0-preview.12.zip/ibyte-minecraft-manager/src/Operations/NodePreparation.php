<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use IByte\MinecraftManager\Modpacks\ArchiveExtractor;
use IByte\MinecraftManager\Support\Failure;

/** Remote payloads stay on Wings. Archive inspection alone uses private Panel disk. */
final class NodePreparation
{
    private array $sources = [];
    private int $sequence = 0;

    public function __construct(private NodeFiles $node, private string $root, private \Closure $progress) {}

    public function fetch(array $artifact, string $local): array
    {
        $remote = $this->root.'/sources/'.(++$this->sequence).'/payload.zip';
        $this->node->pullMany([['path'=>$remote, ...$artifact]], $this->progress);
        $result = $this->node->verifiedRead($remote, $artifact['size'] ?? null, $artifact['hashes'] ?? [], $local);
        $this->sources[$local] = $remote;
        return $result;
    }

    public function extract(string $archive, string $destination): array
    {
        // Validate paths, types, expansion limits, CRCs and collisions BEFORE Wings extraction.
        $files = (new ArchiveExtractor)->extract($archive, $destination);
        $directory = $this->root.'/expanded/'.(++$this->sequence);
        $this->node->extract($this->sources[$archive], $directory);
        foreach ($files as $path=>$local) { $this->sources[$local] = $directory.'/'.$path; }
        return $files;
    }

    public function source(string $local): string { return $this->sources[$local] ?? throw new Failure('staging_unwritable'); }

    public function complete(array $files, string $work): array
    {
        $downloads = [];
        $bytes = array_sum(array_column($files, 'size'));
        if ($bytes > 2147483648) { throw new Failure('pack_size_limit'); }
        foreach ($files as $path=>&$file) {
            if (!isset($file['artifact'])) { $file['remote'] = $this->source($file['local']); continue; }
            $file['remote'] = $this->root.'/sources/'.(++$this->sequence).'/payload.jar';
            $downloads[] = ['path'=>$file['remote'], ...$file['artifact']];
        }
        unset($file);
        if (count($downloads) > 2000) { throw new Failure('dependency_limit'); }
        if ($downloads) { $this->node->pullMany($downloads, $this->progress); }
        $total = count($files); $done = 0; $bytes = 0;
        foreach ($files as $path=>&$file) {
            ++$done; $bytes += $file['size'];
            if ($bytes > 2147483648) { throw new Failure('pack_size_limit'); }
            if (!isset($file['artifact'])) { continue; }
            ($this->progress)(['phase'=>'verify', 'files'=>$done-1, 'total'=>$total, 'file'=>$path]);
            $local = !empty($file['inspect_client']) ? $work.'/inspect.jar' : null;
            $verified = $this->node->verifiedRead($file['remote'], $file['size'], $file['artifact']['hashes'] ?? [], $local);
            $file['sha256'] = $verified['sha256'];
            if ($local) {
                $jar = new \ZipArchive;
                if ($jar->open($local, \ZipArchive::RDONLY) === true) {
                    $entry = $jar->statName('fabric.mod.json');
                    $metadata = $entry && $entry['size'] <= 1048576 ? json_decode($jar->getFromName('fabric.mod.json'), true) : null;
                    $jar->close();
                    if (($metadata['environment'] ?? null) === 'client') { unset($files[$path]); }
                }
                unlink($local);
            }
        }
        unset($file);
        return $files;
    }
}
