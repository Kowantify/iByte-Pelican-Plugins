<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Support;

/** Bounded disk streaming; never buffers complete game artifacts in PHP memory. */
class ArtifactDownloader
{
    public const HOSTS = [
        'cdn.modrinth.com', 'edge.forgecdn.net', 'mediafilez.forgecdn.net', 'media.forgecdn.net',
        'piston-data.mojang.com', 'launcher.mojang.com', 'fill-data.papermc.io', 'api.papermc.io',
        'api.purpurmc.org', 'meta.fabricmc.net', 'maven.fabricmc.net', 'maven.minecraftforge.net',
        'maven.neoforged.net', 'files.mcjars.app', 'versions.mcjars.app', 'mcjars.app',
    ];

    public function download(string $url, string $destination, ?int $size, array $hashes = []): array
    {
        $limit = 536870912;
        if ($size !== null && ($size <= 0 || $size > $limit)) { throw new Failure('artifact_size_limit'); }
        $originalHost = UrlPolicy::host($url, self::HOSTS);
        for ($hop = 0; $hop < 5; $hop++) {
            $host = UrlPolicy::host($url, self::HOSTS);
            $records = @dns_get_record($host, DNS_A | DNS_AAAA);
            $ips = [];
            foreach ($records ?: [] as $record) {
                if (isset($record['ip']) || isset($record['ipv6'])) { $ips[] = $record['ip'] ?? $record['ipv6']; }
            }
            $ip = UrlPolicy::pinnedAddress(array_values(array_unique($ips)));
            $file = fopen($destination, 'wb');
            if ($file === false) { throw new Failure('staging_unwritable'); }
            $bytes = 0; $headers = [];
            $curl = curl_init($url);
            curl_setopt_array($curl, [
                CURLOPT_USERAGENT => 'iByte-Minecraft-Manager/0.1.0-preview.12', CURLOPT_PROXY => '',
                CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 300, CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_RESOLVE => [$host . ':443:' . (str_contains($ip, ':') ? '['.$ip.']' : $ip)],
                CURLOPT_HEADERFUNCTION => static function ($handle, string $line) use (&$headers): int {
                    if (str_starts_with($line, 'HTTP/')) { $headers = []; }
                    if (str_contains($line, ':')) { [$name, $value] = explode(':', $line, 2); $headers[strtolower(trim($name))] = trim($value); }
                    return strlen($line);
                },
                CURLOPT_WRITEFUNCTION => static function ($handle, string $chunk) use ($file, &$bytes, $size, $limit): int {
                    $bytes += strlen($chunk);
                    if ($bytes > ($size ?? $limit) || $bytes > $limit) { return 0; }
                    $written = fwrite($file, $chunk);
                    return $written === false ? 0 : $written;
                },
            ]);
            try { $ok = curl_exec($curl); $status = curl_getinfo($curl, CURLINFO_RESPONSE_CODE); }
            finally { fclose($file); }
            if ($ok === false) { throw new Failure('artifact_download_failed'); }
            if ($status >= 300 && $status < 400) {
                $next = $headers['location'] ?? '';
                if (str_starts_with($next, '/')) { $next = 'https://' . $host . $next; }
                // No API headers are sent to artifacts, including cross-host redirects.
                UrlPolicy::host($next, self::HOSTS); $url = $next; continue;
            }
            if ($status !== 200) { throw new Failure($status === 403 ? 'author_restricted_download' : 'artifact_download_failed'); }
            if ($size !== null && $bytes !== $size) { throw new Failure('size_mismatch'); }
            $algorithm = null;
            foreach (['sha512' => 128, 'sha256' => 64, 'sha1' => 40] as $name => $length) {
                if (!isset($hashes[$name])) { continue; }
                if (!is_string($hashes[$name]) || !preg_match('/\A[0-9a-f]{'.$length.'}\z/Di', $hashes[$name])) { throw new Failure('invalid_hash'); }
                $algorithm = $name; break;
            }
            if ($hashes !== [] && $algorithm === null) { throw new Failure('weak_integrity_policy'); }
            if ($algorithm && !hash_equals(strtolower($hashes[$algorithm]), hash_file($algorithm, $destination))) { throw new Failure('hash_mismatch'); }
            return ['size' => $bytes, 'sha256' => hash_file('sha256', $destination), 'source_integrity' => $algorithm ?? 'https-and-size', 'host' => $originalHost];
        }
        throw new Failure('redirect_refused');
    }
}
