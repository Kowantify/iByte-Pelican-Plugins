    @if ($review && $reviewOpen)
        <x-filament::section>
            <x-slot name="heading">{{ __('ibyte-minecraft-manager::messages.release_review') }}</x-slot>
            <p>{{ $review->plan['release']['title'] }} · {{ $review->plan['release']['id'] }} · {{ $review->provider }}</p>
            <p>{{ __('ibyte-minecraft-manager::messages.review_no_changes') }}</p>
            <p>{{ __('ibyte-minecraft-manager::messages.current_setup') }}: {{ $review->plan['current']['software'] }} · {{ $review->plan['current']['version'] }}</p>
            <p>{{ __('ibyte-minecraft-manager::messages.proposed_version') }}: {{ $review->plan['proposed']['version'] }}</p>
            @if ($review->kind === 'package' && !isset($review->selection['items']) && $review->status === 'planned')
                <div class="grid gap-4 sm:grid-cols-2">
                    <label>Install for Minecraft version
                        <x-filament::input.wrapper><x-filament::input.select wire:model="installVersion">
                            <option value="">{{ $review->selection['version'] ?: 'Select a version' }}</option>
                            @foreach ($review->plan['release']['game_versions'] as $version)<option value="{{ $version }}">{{ $version }}</option>@endforeach
                        </x-filament::input.select></x-filament::input.wrapper>
                    </label>
                    <label>Install for loader / platform
                        <x-filament::input.wrapper><x-filament::input wire:model="installLoader" maxlength="128" :placeholder="$review->selection['loader'] ?: 'Select a loader, e.g. fabric or paper'" /></x-filament::input.wrapper>
                    </label>
                </div>
                <x-filament::button color="gray" wire:click="review({{ \Illuminate\Support\Js::from($review->selection['release']) }})">Review installation choices</x-filament::button>
            @endif
            @foreach ($review->plan['release']['files'] ?? [] as $file)
                <p>{{ $file['name'] }} · {{ number_format($file['size'] ?? 0) }} {{ __('ibyte-minecraft-manager::messages.bytes') }}</p>
            @endforeach
            <ul class="list-disc space-y-2">
                @foreach ($review->plan['blockers'] as $blocker)
                    <li>{{ __('ibyte-minecraft-manager::messages.errors.'.$blocker) }}</li>
                @endforeach
                @foreach ($review->plan['warnings'] ?? [] as $warning)
                    <li>{{ __('ibyte-minecraft-manager::messages.errors.'.$warning) }}</li>
                @endforeach
            </ul>
            @if ($review->status === 'planned' && $review->actor_id === auth()->id())
                @if ($review->plan['executable'])
                    <x-filament::button wire:click="install('{{ $review->id }}')" wire:confirm="Stop this server before installing. Install this exact selection and required dependencies? Existing configurations and worlds are preserved. Replaced files are backed up. Runtime installs update the Java image and startup command. The server will remain stopped." wire:loading.attr="disabled">{{ isset($review->selection['items']) ? 'Install '.count($review->selection['items']).' projects' : 'Install selected release' }}</x-filament::button>
                @endif
                <details><summary>Metadata check</summary><p>Checks provider metadata only. To install files, use the Install button above.</p><x-filament::button color="gray" wire:click="checkReadiness('{{ $review->id }}')" wire:loading.attr="disabled">{{ __('ibyte-minecraft-manager::messages.check_readiness') }}</x-filament::button></details>
            @endif
            <p>{{ __('ibyte-minecraft-manager::messages.expires', ['time' => $review->expires_at->toIso8601String()]) }}</p>
        </x-filament::section>
    @endif

