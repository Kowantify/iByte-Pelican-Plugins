<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use App\Models\Server;
use App\Models\User;
use App\Repositories\Daemon\DaemonServerRepository;
use App\Services\Servers\StartupModificationService;
use IByte\MinecraftManager\Models\Operation;
use IByte\MinecraftManager\Models\Profile;
use IByte\MinecraftManager\Models\Setting;
use IByte\MinecraftManager\Support\Access;
use IByte\MinecraftManager\Support\Failure;
use Illuminate\Support\Facades\Context;
use Throwable;

final class InstallExecutor
{
    public function __construct(private readonly InstallPreparer $preparer, private readonly Access $access) {}

    public function authorize(Operation $op): array
    {
        $server = Server::find($op->server_id); $actor = User::find($op->actor_id);
        if (!$this->access->pluginEnabled() || !$server || !$actor || $server->uuid !== $op->server_uuid || $server->node_id !== $op->node_id) { throw new Failure('source_identity_or_plugin_changed'); }
        $current = $op->fresh();
        if ($op->status !== 'planned' && ($current->server_slot !== $server->id || !in_array($current->status, ['queued', 'preflight', 'downloading', 'verifying', 'applying'], true))) { throw new Failure('operation_ownership_lost'); }
        $action = ['software' => 'software', 'package' => 'packages', 'pack' => 'packs'][$op->kind];
        $profile = $this->access->authorize($actor, $server, $action);
        if (!hash_equals($op->selection['fingerprint'], Access::fingerprint($server, $profile))
            || !hash_equals($op->selection['policy_digest'], hash('sha256', json_encode(app(\IByte\MinecraftManager\Support\Settings::class)->values(), JSON_THROW_ON_ERROR)))) { throw new Failure('stale_plan'); }
        foreach (['file.read', 'file.read-content', 'file.create', 'file.update', 'file.delete', ...($op->kind !== 'package' ? ['startup.update'] : [])] as $permission) {
            Context::forget("users.{$actor->id}.servers.{$server->id}.$permission");
            abort_unless($actor->can($permission, $server), 403);
        }
        return [$server, $actor, $profile];
    }

    private function runtimeSettings(Server $server, User $actor, Profile $profile, array $runtime): array
    {
        $image = null; $java = (int) $runtime['java'];
        foreach (array_unique([$server->image, ...array_values($server->egg->docker_images ?? [])]) as $candidate) {
            if (preg_match('~(?:java[_:-]?)(\d+)(?:\D|$)~i', $candidate, $match) && (int) $match[1] === $java) { $image = $candidate; break; }
        }
        if (!$image) { throw new Failure('java_image_not_approved'); }
        if ($image !== $server->image) {
            Context::forget("users.{$actor->id}.servers.{$server->id}.startup.docker-image");
            abort_unless($actor->can('startup.docker-image', $server), 403);
        }
        $arguments = in_array(strtoupper($runtime['software']), ['VELOCITY', 'BUNGEECORD', 'WATERFALL'], true) ? '' : ' nogui';
        return ['startup' => 'java -Xms128M -XX:MaxRAMPercentage=95.0 -jar "'.$runtime['launcher'].'"'.$arguments, 'docker_image' => $image, 'skip_scripts' => $server->skip_scripts];
    }

    public function run(Operation $op, array $release): void
    {
        [$server, $actor, $profile] = $this->authorize($op);
        $node = app(NodeFiles::class, ['server' => $server]); $node->assertStopped();
        if ($op->kind === 'software') { $this->runtimeSettings($server, $actor, $profile, ['software' => $release['project'], 'java' => $release['java'], 'launcher' => 'server.jar']); }
        $work = storage_path('app/minecraft-manager/'.$op->id);
        if (!is_dir($work) && !mkdir($work, 0700, true)) { throw new Failure('staging_unwritable'); }
        $journal = []; $startupChanged = false; $oldStartup = ['startup' => $server->startup, 'docker_image' => $server->image, 'skip_scripts' => $server->skip_scripts];
        try {
            $op->update(['status' => 'downloading', 'step' => 'prepare']);
            $prepared = $this->preparer->prepare($release, $op->selection, $profile, $work);
            $preparedProjects = [];
            foreach ($prepared['files'] as $file) { $preparedProjects[($file['owner']['provider'] ?? '').':'.($file['owner']['project'] ?? '')] = true; }
            $settings = $prepared['runtime'] ? $this->runtimeSettings($server, $actor, $profile, $prepared['runtime']) : null;
            $op->update(['status' => 'verifying', 'step' => 'stage']); $total = 0;
            $inventory = \Illuminate\Support\Facades\DB::table('imm_inventory')->where('server_id', $server->id)->get();
            foreach ($prepared['files'] as $path => $file) {
                $total += $file['size']; if ($total > 2147483648) { throw new Failure('pack_size_limit'); }
                $this->authorize($op); $node->assertStopped();
                $managed = $inventory->firstWhere('path', $path);
                $previous = $managed ? json_decode($managed->metadata, true) : [];
                if ($op->kind === 'package' && ($previous['owner']['kind'] ?? '') === 'pack') { throw new Failure('pack_owned_file'); }
                // Existing configuration and operator-owned root files are preserved.
                $root = explode('/', $path)[0];
                $configuration = in_array($root, ['config', 'defaultconfigs', 'kubejs', 'scripts', 'patchouli_books'], true)
                    || in_array($root, ['mods', 'plugins'], true) && !str_ends_with(strtolower($path), '.jar');
                if ($configuration && $node->exists($path)) { continue; }
                $old = $node->exists($path) ? $node->hash($path) : null;
                $stage = '.minecraft-manager/staging/'.$op->id.'/'.$path;
                $backup = '.minecraft-manager/backups/'.$op->id.'/'.$path;
                $node->upload($stage, $file['local']);
                if (!hash_equals($file['sha256'], $node->hash($stage))) { throw new Failure('node_hash_mismatch'); }
                $journal[$path] = ['old' => $old, 'new' => $file['sha256'], 'stage' => $stage, 'backup' => $backup, 'owner' => $file['owner']];
            }
            foreach ($inventory as $managed) {
                $meta = json_decode($managed->metadata, true); $owner = $meta['owner'] ?? [];
                $retire = $op->kind === 'pack' && ($owner['kind'] ?? '') === 'pack'
                    || $op->kind === 'software' && ($owner['kind'] ?? '') === 'software'
                    || $op->kind === 'package' && ($owner['kind'] ?? '') === 'package' && isset($preparedProjects[($owner['provider'] ?? '').':'.($owner['project'] ?? '')]);
                $path = $managed->path;
                if (!$retire || isset($prepared['files'][$path]) || !in_array(explode('/', $path)[0], ['mods', 'plugins', 'libraries', 'versions'], true) || !$node->exists($path)) { continue; }
                if ($node->hash($path) !== ($meta['sha256'] ?? '')) { throw new Failure('managed_file_modified'); }
                $journal[$path] = ['old' => $meta['sha256'], 'new' => null, 'stage' => null, 'backup' => '.minecraft-manager/backups/'.$op->id.'/'.$path, 'owner' => $owner];
            }
            $plan = $op->plan; $plan['journal'] = $journal; $plan['previous_startup'] = $oldStartup;
            $op->update(['plan' => $plan, 'status' => 'applying', 'step' => 'replace']);
            foreach ($journal as $path => $item) {
                $this->authorize($op); $node->assertStopped();
                $current = $node->exists($path) ? $node->hash($path) : null;
                if ($current !== $item['old']) { throw new Failure('file_changed_during_install'); }
                if ($item['old'] !== null) { $node->move($path, $item['backup']); }
                if ($item['new'] !== null) {
                    $node->move($item['stage'], $path);
                    if (!hash_equals($item['new'], $node->hash($path))) { throw new Failure('node_hash_mismatch'); }
                }
            }
            if ($settings) {
                [$fresh] = $this->authorize($op); $node->assertStopped();
                $startupChanged = true;
                $changed = app(StartupModificationService::class)->setUserLevel(User::USER_LEVEL_ADMIN)->handle($fresh, $settings);
                app(DaemonServerRepository::class)->setServer($changed)->sync();
            }
            $op->update(['status' => 'verifying-result', 'step' => 'verify']);
            $node->assertStopped();
            foreach ($journal as $path => $item) {
                if ($item['new'] === null ? $node->exists($path) : !hash_equals($item['new'], $node->hash($path))) { throw new Failure('node_hash_mismatch'); }
            }
            \Illuminate\Support\Facades\DB::transaction(function () use ($prepared, $server, $journal, $op): void {
                if ($prepared['runtime']) { Setting::updateOrCreate(['key' => 'runtime-'.$server->id], ['value' => $prepared['runtime']]); }
                foreach ($journal as $path => $item) {
                    if ($item['new'] === null) { \Illuminate\Support\Facades\DB::table('imm_inventory')->where('server_id', $server->id)->where('path', $path)->delete(); continue; }
                    \Illuminate\Support\Facades\DB::table('imm_inventory')->updateOrInsert(['server_id' => $server->id, 'path' => $path],
                        ['metadata' => json_encode(['sha256' => $item['new'], 'owner' => $item['owner'], 'operation' => $op->id], JSON_THROW_ON_ERROR), 'created_at' => now(), 'updated_at' => now()]);
                }
                $op->update(['status' => 'succeeded', 'step' => 'installed', 'server_slot' => null, 'finished_at' => now()]);
            });
        } catch (Throwable $error) {
            $safe = true;
            // Persisted journal also permits manual recovery after worker termination.
            if (in_array($op->fresh()->status, ['applying', 'verifying-result'], true)) {
                $op->update(['status' => 'rolling-back', 'step' => 'restore']);
                try {
                    $node->assertStopped();
                    if ($startupChanged) {
                        $fresh = $server->fresh();
                        if ($fresh->startup !== ($settings['startup'] ?? '') || $fresh->image !== ($settings['docker_image'] ?? '')) { throw new Failure('startup_changed_during_install'); }
                        $restored = app(StartupModificationService::class)->setUserLevel(User::USER_LEVEL_ADMIN)->handle($fresh, $oldStartup);
                        app(DaemonServerRepository::class)->setServer($restored)->sync();
                    }
                    foreach (array_reverse($journal, true) as $path => $item) {
                        $node->assertStopped();
                        $current = $node->exists($path) ? $node->hash($path) : null;
                        if ($current === $item['old']) { continue; }
                        if ($current !== null && $current !== $item['new']) { throw new Failure('file_changed_during_install'); }
                        if ($current !== null) { $node->remove($path); }
                        if ($item['old'] !== null) {
                            if (!$node->exists($item['backup']) || $node->hash($item['backup']) !== $item['old']) { throw new Failure('rollback_backup_missing'); }
                            $node->move($item['backup'], $path);
                        }
                    }
                } catch (Throwable) { $safe = false; }
            }
            $reason = $error instanceof Failure ? $error->reason : ($error instanceof \Symfony\Component\HttpKernel\Exception\HttpException ? 'permission_denied' : 'installation_failed');
            $op->update(['status' => $safe ? 'failed' : 'needs-reconciliation', 'step' => $safe ? 'restored-or-unchanged' : 'manual-recovery', 'error_code' => $reason,
                'server_slot' => $safe ? null : $server->id, 'finished_at' => now()]);
        } finally {
            // Only this generated operation directory is removed; Wings backups remain.
            $this->clean($work);
        }
    }

    private function clean(string $path): void
    {
        if (!is_dir($path) || is_link($path)) { return; }
        foreach (new \FilesystemIterator($path) as $file) { if ($file->isDir() && !$file->isLink()) { $this->clean($file->getPathname()); } else { @unlink($file->getPathname()); } }
        @rmdir($path);
    }
}
