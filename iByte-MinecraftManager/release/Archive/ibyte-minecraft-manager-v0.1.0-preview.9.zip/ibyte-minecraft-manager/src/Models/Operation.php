<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Models;

use Illuminate\Database\Eloquent\Model;

final class Operation extends Model
{
    protected $table = 'imm_operations';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $guarded = [];
    protected $hidden = ['idempotency', 'digest', 'server_slot'];

    protected function casts(): array
    {
        return [
            'actor_id' => 'integer', 'server_id' => 'integer', 'node_id' => 'integer', 'server_slot' => 'integer',
            'selection' => 'array', 'plan' => 'array', 'expires_at' => 'immutable_datetime',
            'started_at' => 'immutable_datetime', 'finished_at' => 'immutable_datetime',
            'acknowledged_at' => 'immutable_datetime',
        ];
    }
}
