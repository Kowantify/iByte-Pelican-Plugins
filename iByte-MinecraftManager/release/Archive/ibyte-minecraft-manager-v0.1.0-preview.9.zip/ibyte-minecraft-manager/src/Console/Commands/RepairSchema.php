<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Console\Commands;

use IByte\MinecraftManager\Support\SchemaInstaller;
use Illuminate\Console\Command;

final class RepairSchema extends Command
{
    protected $signature = 'minecraft-manager:repair-schema';
    protected $description = 'Add missing Minecraft Manager tables without deleting retained data';

    public function handle(): int
    {
        SchemaInstaller::install();
        $this->info('Minecraft Manager schema checked; existing records retained.');

        return self::SUCCESS;
    }
}
