<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Support;

final class Integrity
{
    public static function verify(string $bytes, array $hashes, int $expectedSize, bool $allowSha1 = false): string
    {
        if ($expectedSize < 0 || strlen($bytes) !== $expectedSize) {
            throw new Failure('size_mismatch');
        }
        $algorithm = null;
        foreach (['sha512' => 128, 'sha256' => 64, 'sha1' => 40] as $name => $length) {
            if (!array_key_exists($name, $hashes)) {
                continue;
            }
            if (!is_string($hashes[$name]) || !preg_match('/\A[0-9a-f]{' . $length . '}\z/Di', $hashes[$name])) {
                throw new Failure('invalid_hash');
            }
            $algorithm ??= $name;
        }
        if ($algorithm === null || ($algorithm === 'sha1' && !$allowSha1)) {
            throw new Failure('weak_integrity_policy');
        }
        if (!hash_equals(strtolower($hashes[$algorithm]), hash($algorithm, $bytes))) {
            throw new Failure('hash_mismatch');
        }

        return $algorithm;
    }
}
