<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Packages;

use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\Input;

/** Pure, bounded graph planner. The callback returns an exact normalized release. */
final class DependencyResolver
{
    public function resolve(string $root, callable $lookup, array $optional = [], array $embedded = []): array
    {
        $visiting = $resolved = $projects = $paths = [];
        $visit = function (string $id, int $depth = 0) use (&$visit, &$visiting, &$resolved, &$projects, &$paths, $lookup, $optional, $embedded): void {
            if (isset($visiting[$id])) {
                throw new Failure('dependency_cycle');
            }
            if (isset($resolved[$id]) || in_array($id, $embedded, true)) {
                return;
            }
            if ($depth > 32 || count($resolved) + count($visiting) >= 200) {
                throw new Failure('dependency_limit');
            }
            $visiting[$id] = true;
            $release = $lookup($id);
            if (($release['id'] ?? null) !== $id || !in_array($release['environment'] ?? '', ['required', 'optional', 'server'], true)) {
                throw new Failure('dependency_environment_unknown');
            }
            $project = Input::id($release['project'] ?? '');
            if (isset($projects[$project]) && $projects[$project] !== $id) {
                throw new Failure('dependency_conflict');
            }
            $projects[$project] = $id;
            foreach ($release['dependencies'] ?? [] as $dependency) {
                $kind = $dependency['dependency_type'] ?? 'unknown';
                $target = $dependency['version_id'] ?? null;
                if ($kind === 'embedded') {
                    continue;
                }
                if ($kind === 'optional' && !in_array($target, $optional, true)) {
                    continue;
                }
                if ($kind === 'incompatible') {
                    continue;
                }
                if ($kind !== 'required' && $kind !== 'optional') {
                    throw new Failure('dependency_semantics_unknown');
                }
                if (!$target) {
                    throw new Failure('dependency_exact_release_required');
                }
                $visit(Input::id($target), $depth + 1);
            }
            foreach ($release['files'] ?? [] as $file) {
                if (!($file['primary'] ?? false)) {
                    continue;
                }
                $path = strtolower(Input::filename($file['name'] ?? ''));
                if (isset($paths[$path]) && $paths[$path] !== $id) {
                    throw new Failure('filename_collision');
                }
                $paths[$path] = $id;
            }
            unset($visiting[$id]);
            $resolved[$id] = $release;
        };
        $visit($root);
        foreach ($resolved as $release) {
            foreach ($release['dependencies'] ?? [] as $dependency) {
                if (($dependency['dependency_type'] ?? '') === 'incompatible'
                    && (isset($resolved[$dependency['version_id'] ?? '']) || isset($projects[$dependency['project_id'] ?? '']))) {
                    throw new Failure('dependency_incompatible');
                }
            }
        }

        return array_values($resolved);
    }
}
