<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Modpacks;

use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\Input;
use ZipArchive;

/** Inspects ZIP central-directory metadata before any extraction. No live writes. */
final class ArchiveInspector
{
    public function inspect(string $file, int $maxBytes = 2147483648, int $maxEntries = 10000): array
    {
        $zip = new ZipArchive;
        if ($zip->open($file, ZipArchive::RDONLY | ZipArchive::CHECKCONS) !== true) {
            throw new Failure('invalid_archive');
        }
        try {
            if ($zip->numFiles > $maxEntries) {
                throw new Failure('archive_entry_limit');
            }
            $entries = [];
            $total = 0;
            foreach (range(0, max(0, $zip->numFiles - 1)) as $index) {
                if ($zip->numFiles === 0) {
                    break;
                }
                $stat = $zip->statIndex($index);
                if (!is_array($stat) || (($stat['encryption_method'] ?? 0) !== 0)) {
                    throw new Failure('invalid_archive');
                }
                $name = Input::path(rtrim($stat['name'], '/'));
                $folded = mb_strtolower($name, 'UTF-8');
                if (isset($entries[$folded]) || !mb_check_encoding($name, 'UTF-8')) {
                    throw new Failure('archive_duplicate');
                }
                $opsys = $attributes = 0;
                $zip->getExternalAttributesIndex($index, $opsys, $attributes);
                $type = ($attributes >> 16) & 0170000;
                if ((!in_array($type, [0, 0100000, 0040000], true))
                    || ($type === 0040000 && !str_ends_with($stat['name'], '/'))) {
                    throw new Failure('archive_special_file');
                }
                $size = $stat['size'];
                $total += $size;
                if ($size > min($maxBytes, 268435456) || $total > $maxBytes || $size / max(1, $stat['comp_size']) > 200) {
                    throw new Failure('archive_expansion_limit');
                }
                // Disallow a file being the parent of any other entry.
                foreach (explode('/', $name) as $part) {
                    if ($part === '') {
                        throw new Failure('unsafe_path');
                    }
                }
                $entries[$folded] = ['name' => $name, 'size' => $size, 'directory' => str_ends_with($stat['name'], '/')];
            }
            foreach ($entries as $key => $entry) {
                $parent = dirname($key);
                while ($parent !== '.') {
                    if (isset($entries[$parent]) && !$entries[$parent]['directory']) {
                        throw new Failure('archive_path_collision');
                    }
                    $parent = dirname($parent);
                }
            }

            return array_values($entries);
        } finally {
            $zip->close();
        }
    }
}
