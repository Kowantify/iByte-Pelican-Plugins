<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Modpacks;

use IByte\MinecraftManager\Support\Input;

/** Inputs must be Panel-owned lock records; a server file is never authority. */
final class ManagedDiff
{
    public function compare(array $previous, array $proposed, array $actual): array
    {
        $changes = $conflicts = [];
        foreach (array_unique([...array_keys($previous), ...array_keys($proposed)]) as $path) {
            Input::path($path);
            $old = $previous[$path] ?? null;
            $new = $proposed[$path] ?? null;
            $current = $actual[$path] ?? null;
            if ($new === $old) {
                if ($old !== $current) {
                    $conflicts[] = ['path' => $path, 'reason' => 'user_edit_preserved'];
                }
                continue;
            }
            if ($current !== $old && $current !== $new) {
                $conflicts[] = ['path' => $path, 'reason' => 'user_edit_preserved'];
                continue;
            }
            if ($current !== $new) {
                $changes[] = ['path' => $path, 'action' => $new === null ? 'remove' : ($old === null ? 'add' : 'replace'),
                    'before' => $current, 'after' => $new];
            }
        }

        return ['changes' => $changes, 'conflicts' => $conflicts];
    }
}
