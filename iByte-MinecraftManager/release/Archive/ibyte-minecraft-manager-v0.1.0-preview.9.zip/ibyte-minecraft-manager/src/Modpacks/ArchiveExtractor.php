<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Modpacks;

use IByte\MinecraftManager\Support\Failure;
use ZipArchive;

final class ArchiveExtractor
{
    public function extract(string $archive, string $destination): array
    {
        $entries = (new ArchiveInspector)->inspect($archive);
        $zip = new ZipArchive;
        if ($zip->open($archive, ZipArchive::RDONLY) !== true) { throw new Failure('invalid_archive'); }
        $files = []; $total = 0;
        try {
            foreach ($entries as $entry) {
                if ($entry['directory']) { continue; }
                $target = $destination.'/'.$entry['name'];
                if (!is_dir(dirname($target)) && !mkdir(dirname($target), 0700, true)) { throw new Failure('staging_unwritable'); }
                $read = $zip->getStream($entry['name']); $write = fopen($target, 'wb');
                if (!$read || !$write) { throw new Failure('invalid_archive'); }
                $bytes = 0;
                try {
                    while (!feof($read)) {
                        $chunk = fread($read, 65536);
                        if ($chunk === false) { throw new Failure('invalid_archive'); }
                        $bytes += strlen($chunk); $total += strlen($chunk);
                        if ($bytes > $entry['size'] || $total > 2147483648 || fwrite($write, $chunk) !== strlen($chunk)) { throw new Failure('archive_expansion_limit'); }
                    }
                } finally { fclose($read); fclose($write); }
                if ($bytes !== $entry['size']) { throw new Failure('size_mismatch'); }
                $stat = $zip->statName($entry['name']);
                if (sprintf('%08x', $stat['crc']) !== hash_file('crc32b', $target)) { throw new Failure('hash_mismatch'); }
                $files[$entry['name']] = $target;
            }
        } finally { $zip->close(); }
        return $files;
    }
}
