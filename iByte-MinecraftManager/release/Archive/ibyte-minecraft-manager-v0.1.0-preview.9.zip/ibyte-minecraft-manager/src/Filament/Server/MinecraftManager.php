<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Filament\Server;

use App\Models\Server;
use BackedEnum;
use Filament\Facades\Filament;
use Filament\Pages\Page;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;
use Filament\Schemas\Components\Section;
use IByte\MinecraftManager\Catalog\Catalog;
use IByte\MinecraftManager\Catalog\McJars;
use IByte\MinecraftManager\Models\Operation;
use IByte\MinecraftManager\Operations\ReviewService;
use IByte\MinecraftManager\Packages\Inventory;
use IByte\MinecraftManager\Support\Access;
use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\Input;
use IByte\MinecraftManager\Support\Settings;
use IByte\MinecraftManager\Support\ViewCache;
use Livewire\Attributes\Locked;
use Throwable;

final class MinecraftManager extends Page
{
    protected static string|BackedEnum|null $navigationIcon = 'tabler-brand-minecraft';
    protected static ?string $slug = 'minecraft-manager';
    protected static ?int $navigationSort = 98;
    protected string $view = 'ibyte-minecraft-manager::server';
    #[Locked] public string $area = 'overview';
    #[Locked] public array $results = [];
    #[Locked] public array $types = [];
    #[Locked] public array $versions = [];
    #[Locked] public array $builds = [];
    #[Locked] public array $releases = [];
    #[Locked] public array $inventory = [];
    #[Locked] public string $project = '';
    #[Locked] public string $software = '';
    #[Locked] public string $softwareVersion = '';
    #[Locked] public string $reviewId = '';
    #[Locked] public ?string $error = null;
    public string $provider = 'modrinth';
    public string $query = '';
    public string $sort = 'popular';
    public string $gameVersion = '';
    public string $loaderFilter = '';
    public string $packageType = 'mod';
    public string $installVersion = '';
    public string $installLoader = '';
    public string $selectedSoftware = '';
    public string $selectedSoftwareVersion = '';
    public string $selectedBuild = '';
    public string $selectedRelease = '';
    public string $softwareVersionQuery = '';
    public string $softwareBuildQuery = '';
    #[Locked] public bool $projectOpen = false;
    #[Locked] public bool $reviewOpen = false;
    #[Locked] public array $cart = [];
    public bool $experimental = false;
    public int $page = 1;
    public int $releasePage = 1;
    #[Locked] public int $buildPage = 1;
    #[Locked] public int $total = 0;

    public static function getNavigationLabel(): string { return trans('ibyte-minecraft-manager::messages.title'); }
    public function getTitle(): string { return self::getNavigationLabel(); }

    public static function getNavigationSort(): ?int
    {
        $sort = parent::getNavigationSort() ?? 98;
        $panel = Filament::getCurrentPanel();
        if (!$panel || $panel->getId() !== 'server') { return $sort; }
        // Subdomains can be a third-party page, resource or explicit navigation
        // item. Follow its registered position without changing its plugin.
        foreach (array_unique([...$panel->getPages(), ...$panel->getResources()]) as $page) {
            if ($page !== self::class && str_contains(strtolower(class_basename($page)), 'subdomain')) {
                $sort = max($sort, ($page::getNavigationSort() ?? 0) + 1);
            }
        }
        foreach ($panel->getNavigationItems() as $item) {
            if (preg_match('/sub\s?domains/i', $item->getLabel())) { $sort = max($sort, $item->getSort() + 1); }
        }
        return $sort;
    }

    public static function canAccess(): bool
    {
        $tenant = Filament::getTenant();

        return $tenant instanceof Server && app(Access::class)->allowed(auth()->user(), $tenant);
    }

    public function mount(): void
    {
        $this->guard();
        $sources = array_values(array_filter(['modrinth', 'curseforge'], fn ($p) => app(Settings::class)->providerEnabled($p)));
        $this->provider = $sources[0] ?? 'modrinth';
    }

    private function guard(string $action = 'browse'): Server
    {
        $server = Filament::getTenant();
        abort_unless($server instanceof Server, 403);
        app(Access::class)->authorize(auth()->user(), $server, $action);

        return $server;
    }

    private function run(callable $work): void
    {
        $this->guard();
        $this->error = null;
        try {
            $work();
        } catch (Failure $failure) {
            $this->error = $failure->reason;
        } catch (Throwable) {
            $this->error = 'request_failed';
        }
    }

    public function switchArea(string $area): void
    {
        $this->guard();
        abort_unless(in_array($area, ['overview', 'software', 'packages', 'packs', 'activity'], true), 422);
        $this->area = $area;
        $this->results = $this->releases = [];
        $this->project = $this->reviewId = '';
        $this->page = $this->releasePage = 1;
        $this->error = null;
        $this->query = $this->gameVersion = $this->loaderFilter = '';
        $this->installVersion = $this->installLoader = '';
        if ($area === 'software') { $this->browseSoftware(); }
        if (in_array($area, ['packages', 'packs'], true)) { $this->search(); }
    }

    public function updatedProvider(): void { $this->clearSelectionAndSearch(); }
    public function updatedPackageType(): void { $this->clearSelectionAndSearch(); }
    public function updatedSort(): void { $this->clearSelectionAndSearch(); }

    public function catalogForm(Schema $schema): Schema
    {
        return $schema->columns(['default'=>1,'md'=>2,'xl'=>4])->components([
            TextInput::make('query')->label('Search')->placeholder('Project name')->maxLength(100),
            Select::make('provider')->label('Provider')->options(fn () => array_intersect_key(['modrinth'=>'Modrinth','curseforge'=>'CurseForge'], array_flip(array_values(array_filter(['modrinth','curseforge'], fn ($p) => app(Settings::class)->providerEnabled($p))))))->live()->selectablePlaceholder(false),
            Select::make('packageType')->label('Content')->options(['mod'=>'Mods','plugin'=>'Plugins'])->live()->selectablePlaceholder(false)->visible(fn () => $this->area === 'packages'),
            Select::make('sort')->label('Sort by')->options(['popular'=>'Popularity','downloads'=>'Downloads','updated'=>'Last updated'])->live()->selectablePlaceholder(false)
                ->helperText(fn () => $this->provider === 'modrinth' && $this->sort === 'popular' ? 'Modrinth popularity is ranked by follows.' : null),
            Section::make('Filters')->compact()->collapsible()->collapsed()->columnSpanFull()->columns(['default'=>1,'md'=>3])->schema([
                TextInput::make('gameVersion')->label('Minecraft version')->placeholder('All versions')->maxLength(128),
                TextInput::make('loaderFilter')->label('Loader / platform')->placeholder('All loaders')->maxLength(128),
                Toggle::make('experimental')->label('Include beta and alpha releases'),
            ]),
        ]);
    }

    public function softwareForm(Schema $schema): Schema
    {
        return $schema->columns(['default'=>1,'md'=>3])->components([
            Select::make('selectedSoftware')->label('Server software')->placeholder('Select software')->searchable()->live()->selectablePlaceholder(false)
                ->options(fn () => collect($this->types)->filter(fn ($t) => $this->experimental || !$t['experimental'] && !$t['deprecated'])->pluck('title','id')->all()),
            Select::make('selectedSoftwareVersion')->label('Minecraft version')->placeholder('Select version')->searchable()->live()->selectablePlaceholder(false)->disabled(fn () => $this->software === '')
                ->options(fn () => $this->versionOptions())
                ->getSearchResultsUsing(fn (string $search) => $this->searchSoftwareVersions($search))
                ->getOptionLabelUsing(fn ($value) => $value),
            Select::make('selectedBuild')->label('Build')->placeholder('Select build')->searchable()->live()->selectablePlaceholder(false)->disabled(fn () => $this->softwareVersion === '')
                ->options(fn () => collect($this->builds)->filter(fn ($b) => $this->experimental || !($b['experimental'] ?? true))->pluck('name','uuid')->all())
                ->getSearchResultsUsing(fn (string $search) => $this->searchSoftwareBuilds($search))
                ->getOptionLabelUsing(fn ($value) => collect($this->builds)->firstWhere('uuid',$value)['name'] ?? $value),
            Toggle::make('experimental')->label('Include experimental releases')->live()->columnSpanFull(),
        ]);
    }

    private function versionOptions(): array
    {
        return collect($this->versions)->filter(fn ($v) => $this->experimental || ($v['type'] ?? '') === 'RELEASE')->mapWithKeys(fn ($v) => [$v['id'] => $v['id'].' · '.($v['type'] ?? '')])->all();
    }

    public function searchSoftwareVersions(string $search): array
    {
        $this->guard();
        if ($this->software === '') { return []; }
        $this->page = 1;
        $this->softwareVersionQuery = Input::text($search,100);
        $this->versions = app(McJars::class)->versions($this->software, 1, $this->softwareVersionQuery)['items'];
        return $this->versionOptions();
    }

    public function searchSoftwareBuilds(string $search): array
    {
        $this->guard();
        if ($this->softwareVersion === '') { return []; }
        $this->buildPage = 1;
        $this->softwareBuildQuery = Input::text($search,100);
        $this->builds = app(McJars::class)->builds($this->software,$this->softwareVersion,1,$this->softwareBuildQuery)['items'];
        return collect($this->builds)->filter(fn ($b) => $this->experimental || !($b['experimental'] ?? true))->pluck('name','uuid')->all();
    }

    private function clearSelectionAndSearch(): void
    {
        $this->guard();
        $this->project = $this->reviewId = $this->installVersion = $this->installLoader = '';
        $this->results = $this->releases = [];
        if (in_array($this->area, ['packages', 'packs'], true)) { $this->search(); }
    }

    public function browseSoftware(): void
    {
        $this->run(function (): void {
            if (!app(Settings::class)->providerEnabled('mcjars')) { throw new Failure('provider_disabled'); }
            $this->types = app(McJars::class)->types();
        });
    }

    public function chooseSoftware(string $id): void
    {
        $this->run(function () use ($id): void {
            if (!in_array($id, array_column($this->types, 'id'), true)) { throw new Failure('unknown_software'); }
            $this->software = Input::id($id);
            $this->page = 1;
            $this->softwareVersionQuery = $this->softwareBuildQuery = '';
            $this->selectedSoftware = $this->software;
            $this->selectedSoftwareVersion = $this->selectedBuild = $this->reviewId = '';
            $this->softwareVersion = '';
            $this->versions = app(McJars::class)->versions($id)['items'];
            $this->builds = [];
        });
    }

    public function softwareVersions(int $page = 1): void
    {
        $this->run(function () use ($page): void {
            $this->page = min(500, max(1, $page));
            $this->versions = app(McJars::class)->versions($this->software, $this->page, $this->softwareVersionQuery)['items'];
            $this->selectedSoftwareVersion = $this->softwareVersion = $this->selectedBuild = $this->reviewId = '';
            $this->builds = [];
        });
    }

    public function chooseVersion(string $version): void
    {
        $this->run(function () use ($version): void {
            if (!in_array($version, array_column($this->versions, 'id'), true)) { throw new Failure('invalid_selection'); }
            $this->softwareVersion = Input::id($version);
            $this->selectedSoftwareVersion = $this->softwareVersion;
            $this->selectedBuild = $this->reviewId = '';
            $this->buildPage = 1;
            $this->softwareBuildQuery = '';
            $this->builds = app(McJars::class)->builds($this->software, $version)['items'];
        });
    }

    public function softwareBuilds(int $page = 1): void
    {
        $this->run(function () use ($page): void {
            $this->buildPage = min(500, max(1, $page));
            $this->builds = app(McJars::class)->builds($this->software, $this->softwareVersion, $this->buildPage, $this->softwareBuildQuery)['items'];
            $this->selectedBuild = '';
        });
    }

    public function updatedSelectedSoftware(string $id): void { if ($id !== '') { $this->chooseSoftware($id); } }
    public function updatedSelectedSoftwareVersion(string $id): void { if ($id !== '') { $this->chooseVersion($id); } }
    public function closeProject(): void { $this->guard(); $this->projectOpen = false; }
    public function closeReview(): void { $this->guard(); $this->reviewOpen = false; }
    public function reviewSelectedBuild(): void { $this->review($this->selectedBuild); }
    public function reviewSelectedRelease(): void { $this->review($this->selectedRelease); }
    public function addSelectedRelease(): void { $this->addToCart($this->selectedRelease); }

    private function context(): array
    {
        $this->guard();
        if (!in_array($this->packageType, ['mod', 'plugin'], true)) { throw new Failure('invalid_content_type'); }
        $type = $this->area === 'packs' ? 'modpack' : $this->packageType;

        return ['type' => $type, 'sort' => $this->sort, 'version' => $this->gameVersion, 'loader' => $this->loaderFilter,
            'query' => $this->query, 'page' => $this->page, 'release_page' => $this->releasePage, 'experimental' => $this->experimental];
    }

    public function search(int $page = 1): void
    {
        $this->run(function () use ($page): void {
            abort_unless(in_array($this->area, ['packages', 'packs'], true), 422);
            $this->page = min(500, max(1, $page));
            $this->reviewId = '';
            $data = app(Catalog::class)->search($this->provider, $this->context());
            $this->results = $data['items'];
            $this->total = $data['total'];
            $this->releases = [];
            $this->project = '';
        });
    }

    public function inspectProject(string $project): void
    {
        $this->run(function () use ($project): void {
            if (!in_array($project, array_column($this->results, 'id'), true)) { throw new Failure('invalid_selection'); }
            $this->project = Input::id($project);
            $this->selectedRelease = ''; $this->projectOpen = true; $this->reviewOpen = false;
            $this->releasePage = 1;
            $this->releases = app(Catalog::class)->releases($this->provider, $project, $this->context());
        });
    }

    public function moreReleases(int $page): void
    {
        $this->run(function () use ($page): void {
            $this->releasePage = min(200, max(1, $page));
            $this->selectedRelease = '';
            $this->releases = app(Catalog::class)->releases($this->provider, $this->project, $this->context());
        });
    }

    public function review(string $id): void
    {
        $server = $this->guard('plan');
        $this->run(function () use ($server, $id): void {
            if ($this->area === 'software') {
                if (!in_array($id, array_column($this->builds, 'uuid'), true)) { throw new Failure('invalid_selection'); }
                $selection = ['kind' => 'software', 'provider' => 'mcjars', 'project' => $this->software,
                    'version' => $this->softwareVersion, 'release' => Input::id($id)];
            } else {
                if (!in_array($id, array_column($this->releases, 'id'), true)) { throw new Failure('invalid_selection'); }
                $context = $this->context();
                $selection = ['kind' => $this->area === 'packs' ? 'pack' : 'package', 'provider' => $this->provider,
                    'project' => $this->project, 'release' => Input::id($id), 'version' => $this->installVersion ?: $this->gameVersion,
                    'loader' => $this->installLoader ?: $this->loaderFilter, 'type' => $context['type']];
            }
            $selection['experimental'] = $this->experimental;
            $this->reviewId = app(ReviewService::class)->create(auth()->user(), $server, $selection)->id;
            $this->reviewOpen = true; $this->projectOpen = false;
        });
    }

    public function addToCart(string $release): void
    {
        $this->guard('plan');
        abort_unless($this->area === 'packages', 422);
        if (count($this->cart) >= 20) { $this->error = 'batch_limit'; return; }
        $this->review($release);
        if ($this->error) { return; }
        $op = app(ReviewService::class)->operation(auth()->user(), $this->guard('plan'), $this->reviewId);
        if (!$op->plan['executable']) { return; }
        $key = $op->provider.':'.$op->selection['project'];
        $this->cart[$key] = ['review' => $op->id, 'title' => $op->plan['release']['title'], 'provider' => $op->provider,
            'version' => $op->selection['version'], 'loader' => $op->selection['loader']];
        $this->reviewOpen = false; $this->reviewId = '';
    }

    public function removeFromCart(string $key): void { $this->guard('plan'); unset($this->cart[$key]); }
    public function clearCart(): void { $this->guard('plan'); $this->cart = []; }
    public function reviewCart(): void
    {
        $server = $this->guard('plan');
        $this->run(function () use ($server): void {
            $this->reviewId = app(ReviewService::class)->createBatch(auth()->user(), $server, array_column($this->cart, 'review'))->id;
            $this->projectOpen = false; $this->reviewOpen = true;
        });
    }

    public function checkReadiness(string $id): void
    {
        $server = $this->guard('plan');
        $this->run(fn () => app(ReviewService::class)->queue(auth()->user(), $server, $id));
    }

    public function install(string $id): void
    {
        $server = $this->guard('plan');
        $this->run(function () use ($server, $id): void {
            $service = app(ReviewService::class);
            $op = $service->operation(auth()->user(), $server, $id);
            if ($op->kind === 'package' && !isset($op->selection['items']) && ($this->installVersion !== '' && $this->installVersion !== $op->selection['version']
                || $this->installLoader !== '' && strtolower($this->installLoader) !== $op->selection['loader'])) { throw new Failure('review_choices_changed'); }
            $service->queue(auth()->user(), $server, $id, true);
            $this->reviewOpen = false; $this->projectOpen = false;
            if (isset($op->selection['items'])) { $this->cart = []; }
            $this->area = 'activity';
        });
    }

    public function cancelReview(string $id): void
    {
        $server = $this->guard('plan');
        $this->run(fn () => app(ReviewService::class)->cancel(auth()->user(), $server, $id));
    }

    public function acknowledge(string $id): void
    {
        $server = $this->guard('plan');
        $this->run(fn () => app(ReviewService::class)->acknowledge(auth()->user(), $server, $id));
    }

    public function scan(): void
    {
        $server = $this->guard();
        abort_unless(auth()->user()->can('file.read', $server), 403);
        $this->run(function () use ($server): void {
            if (!in_array($this->packageType, ['mod', 'plugin'], true)) { throw new Failure('invalid_content_type'); }
            $this->inventory = app(Inventory::class)->scan($server, $this->packageType);
        });
    }

    protected function getViewData(): array
    {
        $server = $this->guard();
        ViewCache::refresh(app('blade.compiler'));

        return [
            'profile' => app(Access::class)->profile($server), 'server' => $server,
            'runtime' => Access::runtime($server, app(Access::class)->profile($server)),
            'contentProviders' => array_values(array_filter(['modrinth', 'curseforge'], fn ($p) => app(Settings::class)->providerEnabled($p))),
            'operations' => Operation::where('server_id', $server->id)->where('server_uuid', $server->uuid)->latest()->limit(30)->get(),
            'review' => $this->reviewId ? Operation::whereKey($this->reviewId)->where('server_id', $server->id)->first() : null,
        ];
    }
}
