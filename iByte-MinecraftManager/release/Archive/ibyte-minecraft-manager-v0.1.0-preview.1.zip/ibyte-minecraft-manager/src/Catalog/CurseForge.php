<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Catalog;

use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\Input;

final class CurseForge
{
    private const CLASS_IDS = ['mod' => 6, 'plugin' => 5, 'modpack' => 4471];
    private const LOADER_IDS = ['forge' => 1, 'fabric' => 4, 'quilt' => 5, 'neoforge' => 6];

    public function __construct(private readonly JsonTransport $http) {}

    private function id(string $id): string
    {
        if (!preg_match('/\A[1-9][0-9]{0,12}\z/D', $id)) {
            throw new Failure('invalid_identifier');
        }

        return $id;
    }

    public function search(array $context): array
    {
        $query = [
            'gameId' => 432, 'classId' => self::CLASS_IDS[$context['type']],
            'searchFilter' => $context['query'], 'index' => ($context['page'] - 1) * 20, 'pageSize' => 20,
        ];
        if ($context['version'] !== '') {
            $query['gameVersion'] = $context['version'];
        }
        if ($context['loader'] !== '' && isset(self::LOADER_IDS[$context['loader']])) {
            $query['modLoaderType'] = self::LOADER_IDS[$context['loader']];
        }
        $body = $this->http->get('curseforge', '/v1/mods/search', $query);
        $items = [];
        foreach (Input::list($body, 'data', 20) as $hit) {
            $items[] = ['id' => $this->id((string) ($hit['id'] ?? '')), 'title' => Input::text($hit['name'] ?? '', 200),
                'description' => Input::text($hit['summary'] ?? ''), 'environment' => 'unknown'];
        }

        return ['items' => $items, 'total' => min(10000, (int) ($body['pagination']['totalCount'] ?? count($items))), 'page' => $context['page']];
    }

    public function releases(string $project, array $context): array
    {
        $query = ['pageSize' => 50, 'index' => ($context['release_page'] - 1) * 50];
        if ($context['version'] !== '') {
            $query['gameVersion'] = $context['version'];
        }
        if (isset(self::LOADER_IDS[$context['loader']])) {
            $query['modLoaderType'] = self::LOADER_IDS[$context['loader']];
        }
        $body = $this->http->get('curseforge', '/v1/mods/' . $this->id($project) . '/files', $query);
        $result = [];
        foreach (Input::list($body, 'data', 50) as $file) {
            if ($context['experimental'] || ($file['releaseType'] ?? null) === 1) {
                $result[] = ['id' => $this->id((string) $file['id']), 'title' => Input::text($file['displayName'] ?? '', 200),
                    'channel' => [1 => 'release', 2 => 'beta', 3 => 'alpha'][$file['releaseType'] ?? 0] ?? 'unknown'];
            }
        }

        return $result;
    }

    public function exact(string $project, string $id): array
    {
        $meta = $this->http->get('curseforge', '/v1/mods/' . $this->id($project))['data'] ?? [];
        $file = $this->http->get('curseforge', '/v1/mods/' . $this->id($project) . '/files/' . $this->id($id))['data'] ?? [];
        if ((string) ($meta['id'] ?? '') !== $project || (string) ($file['id'] ?? '') !== $id || (string) ($file['modId'] ?? '') !== $project) {
            throw new Failure('exact_release_unavailable');
        }
        if (($meta['allowModDistribution'] ?? null) === false || empty($file['downloadUrl'])) {
            throw new Failure('author_restricted_download');
        }
        $hashes = [];
        foreach (Input::list($file, 'hashes', 10) as $hash) {
            $algorithm = [1 => 'sha1', 2 => 'md5'][$hash['algo'] ?? 0] ?? null;
            if ($algorithm) {
                $hashes[$algorithm] = $hash['value'];
            }
        }

        return [
            'provider' => 'curseforge', 'project' => $project, 'id' => $id,
            'title' => Input::text($file['displayName'] ?? $id, 200), 'version' => $id,
            'channel' => [1 => 'release', 2 => 'beta', 3 => 'alpha'][$file['releaseType'] ?? 0] ?? 'unknown',
            'game_versions' => Input::list($file, 'gameVersions', 100),
            'loaders' => [], 'environment' => 'unknown',
            'project_type' => array_search($meta['classId'] ?? null, self::CLASS_IDS, true) ?: 'unknown',
            'files' => [['id' => $id, 'name' => Input::filename($file['fileName'] ?? ''), 'size' => $file['fileLength'] ?? null,
                'hashes' => $hashes, 'primary' => true]],
            'server_pack_id' => isset($file['serverPackFileId']) ? (string) $file['serverPackFileId'] : null,
            'dependencies' => Input::list($file, 'dependencies', 500),
            'compatibility' => 'unknown', 'reason' => 'native_fence_unavailable',
        ];
    }
}
