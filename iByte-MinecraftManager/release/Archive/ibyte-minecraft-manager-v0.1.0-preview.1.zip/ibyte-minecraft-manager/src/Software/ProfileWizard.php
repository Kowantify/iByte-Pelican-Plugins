<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Software;

use App\Models\Egg;
use IByte\MinecraftManager\Catalog\McJars;
use IByte\MinecraftManager\Models\Profile;
use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\Input;

final class ProfileWizard
{
    public function save(array $data, McJars $catalog): Profile
    {
        $egg = Egg::findOrFail($data['egg_id']);
        $types = array_column($catalog->types(), 'id');
        $software = Input::id($data['software']);
        if (!in_array($software, $types, true)) {
            throw new Failure('unknown_software');
        }
        $image = $data['image'];
        if (!in_array($image, array_values($egg->docker_images ?? []), true)) {
            throw new Failure('image_not_in_egg');
        }
        $variable = trim($data['version_variable'] ?? '');
        if ($variable !== '' && !$egg->variables()->where('env_variable', $variable)->exists()) {
            throw new Failure('variable_not_in_egg');
        }
        $type = $data['content_type'];
        if (!in_array($type, ['none', 'mod', 'plugin', 'proxy'], true)) {
            throw new Failure('invalid_profile');
        }
        $loader = trim($data['loader'] ?? '');

        return Profile::updateOrCreate(['egg_id' => $egg->id], [
            'name' => Input::text($data['name'], 100), 'software' => $software,
            'images' => [$image], 'jar_path' => Input::path($data['jar_path']),
            'version_variable' => $variable ?: null, 'loader' => $loader === '' ? null : Input::id($loader),
            'content_type' => $type, 'enabled' => (bool) ($data['enabled'] ?? false),
        ]);
    }
}
