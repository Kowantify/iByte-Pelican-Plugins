<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use IByte\MinecraftManager\Support\Failure;

final class SafetyGate
{
    public const BLOCKER = 'native_fence_unavailable';

    public function assertCanCommit(): never
    {
        // Deliberately unconditional. No browser value, config key, admin checkbox,
        // server-writable file or successful mock can enable live mutation.
        throw new Failure(self::BLOCKER);
    }
}
