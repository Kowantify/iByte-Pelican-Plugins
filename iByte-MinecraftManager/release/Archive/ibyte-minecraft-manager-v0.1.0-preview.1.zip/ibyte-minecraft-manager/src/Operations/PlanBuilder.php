<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use IByte\MinecraftManager\Support\Failure;

final class PlanBuilder
{
    public function build(array $release, array $context): array
    {
        $blockers = [SafetyGate::BLOCKER];
        if (($release['environment'] ?? '') === 'unsupported') {
            throw new Failure('client_only');
        }
        if (!in_array($release['environment'] ?? '', ['server', 'required', 'optional'], true)) {
            $blockers[] = 'environment_unknown';
        }
        if (($release['channel'] ?? '') !== 'release' && !($context['experimental'] ?? false)) {
            throw new Failure('experimental_disabled');
        }
        if (($context['kind'] ?? '') !== 'software') {
            if (($release['project_type'] ?? '') !== ($context['type'] ?? '')) {
                throw new Failure('content_type_mismatch');
            }
            if (empty($context['version']) || !in_array($context['version'], $release['game_versions'] ?? [], true)) {
                $blockers[] = 'game_version_unknown_or_incompatible';
            }
            if (empty($context['loader']) || !in_array($context['loader'], $release['loaders'] ?? [], true)) {
                $blockers[] = 'loader_unknown_or_incompatible';
            }
        }
        if (!empty($release['dependencies'])) {
            $blockers[] = 'dependency_plan_required';
        }
        if (($context['kind'] ?? '') === 'pack') {
            $blockers[] = 'pack_manifest_review_required';
        }
        foreach ($release['files'] ?? [] as $file) {
            if (!is_int($file['size'] ?? null) || $file['size'] <= 0 || empty($file['hashes']['sha512']) && empty($file['hashes']['sha256'])) {
                $blockers[] = 'strong_integrity_required';
            }
        }
        if (($context['kind'] ?? '') === 'software') {
            $blockers[] = 'runtime_handler_not_verified';
            $blockers[] = 'java_image_not_verified';
        }

        return [
            'release' => $release, 'blockers' => array_values(array_unique($blockers)),
            'current' => $context['current'] ?? [],
            'proposed' => ['version' => $release['version'], 'image' => 'unchanged; no approved runtime change',
                'startup' => 'unchanged; runtime installation is gated'],
            'preserve' => ['worlds', 'configs', 'player lists', 'allocations', 'resource limits', 'native backups'],
            'changes' => [], 'executable' => false,
        ];
    }

    public static function digest(array $plan): string
    {
        return hash('sha256', json_encode($plan, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }
}
