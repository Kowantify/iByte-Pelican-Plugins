<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use App\Models\Server;
use App\Models\User;
use IByte\MinecraftManager\Catalog\Catalog;
use IByte\MinecraftManager\Catalog\McJars;
use IByte\MinecraftManager\Models\Operation;
use IByte\MinecraftManager\Support\Access;
use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\Input;
use IByte\MinecraftManager\Support\Settings;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class ReviewService
{
    public function __construct(private readonly Access $access, private readonly Catalog $catalog,
        private readonly McJars $software, private readonly Settings $settings) {}

    public function create(User $actor, Server $server, array $selection): Operation
    {
        $profile = $this->access->authorize($actor, $server, 'plan');
        if (!in_array($selection['kind'] ?? '', ['software', 'package', 'pack'], true)) {
            throw new Failure('invalid_selection');
        }
        $selection = array_intersect_key($selection, array_flip(['kind', 'provider', 'project', 'release', 'version', 'type', 'experimental']));
        foreach (['provider', 'project', 'release'] as $field) {
            $selection[$field] = Input::id($selection[$field] ?? '');
        }
        $selection['version'] = empty($selection['version']) ? '' : Input::id($selection['version']);
        $selection['loader'] = $profile->loader ?? '';
        $selection['experimental'] = (bool) ($selection['experimental'] ?? false) && ($this->settings->values()['experimental'] ?? false);
        if ($selection['kind'] === 'software') {
            if ($selection['provider'] !== 'mcjars' || !$this->settings->providerEnabled('mcjars')) {
                throw new Failure('provider_disabled');
            }
            $release = $this->software->exact($selection['project'], $selection['version'], $selection['release']);
        } else {
            $expectedType = $selection['kind'] === 'pack' ? 'modpack' : ($profile->content_type === 'proxy' ? 'plugin' : $profile->content_type);
            if (($selection['type'] ?? '') !== $expectedType || $expectedType === 'none') {
                throw new Failure('content_type_mismatch');
            }
            $release = $this->catalog->exact($selection['provider'], $selection['project'], $selection['release']);
        }
        $selection['fingerprint'] = Access::fingerprint($server, $profile);
        $selection['policy_digest'] = hash('sha256', json_encode($this->settings->values(), JSON_THROW_ON_ERROR));
        $selection['current'] = ['software' => $profile->software, 'version' => 'unknown', 'image' => $server->image];
        $plan = (new PlanBuilder)->build($release, $selection);
        $digest = PlanBuilder::digest($plan);
        $key = hash('sha256', json_encode([$actor->id, $server->uuid, $selection, $digest, intdiv(time(), 600)], JSON_THROW_ON_ERROR));

        return Operation::firstOrCreate(['idempotency' => $key], [
            'id' => (string) Str::uuid(), 'server_id' => $server->id, 'server_uuid' => $server->uuid,
            'node_id' => $server->node_id, 'actor_id' => $actor->id, 'kind' => $selection['kind'],
            'provider' => $selection['provider'], 'status' => Status::Planned->value, 'step' => 'review',
            'selection' => $selection, 'plan' => $plan, 'digest' => $digest, 'expires_at' => now()->addMinutes(10),
        ]);
    }

    public function operation(User $actor, Server $server, string $id): Operation
    {
        $this->access->authorize($actor, $server, 'plan');

        return Operation::where('id', $id)->where('server_id', $server->id)->where('server_uuid', $server->uuid)->firstOrFail();
    }

    public function queue(User $actor, Server $server, string $id): void
    {
        $operation = $this->operation($actor, $server, $id);
        abort_unless($operation->actor_id === $actor->id, 403);
        DB::transaction(function () use ($operation, $server): void {
            $row = Operation::whereKey($operation->id)->lockForUpdate()->firstOrFail();
            if ($row->status !== Status::Planned->value || $row->expires_at->isPast()) {
                throw new Failure('plan_expired_or_used');
            }
            if (Operation::where('server_slot', $server->id)->exists()) {
                throw new Failure('operation_in_progress');
            }
            $row->update(['status' => Status::Queued->value, 'step' => 'queued', 'server_slot' => $server->id]);
            CheckReview::dispatch($row->id)->afterCommit();
        });
    }

    public function cancel(User $actor, Server $server, string $id): void
    {
        $operation = $this->operation($actor, $server, $id);
        abort_unless($operation->actor_id === $actor->id, 403);
        $changed = Operation::whereKey($id)->whereIn('status', [Status::Planned->value, Status::Queued->value])
            ->update(['status' => Status::Cancelled->value, 'step' => 'cancelled', 'server_slot' => null, 'finished_at' => now()]);
        if (!$changed) {
            throw new Failure('cancel_phase_not_supported');
        }
    }

    public function acknowledge(User $actor, Server $server, string $id): void
    {
        $operation = $this->operation($actor, $server, $id);
        abort_unless($operation->actor_id === $actor->id, 403);
        $operation->update(['acknowledged_at' => $operation->acknowledged_at ?? now()]);
    }
}
