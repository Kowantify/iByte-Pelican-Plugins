<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Filament\Admin;

use App\Models\Egg;
use BackedEnum;
use Filament\Pages\Page;
use IByte\MinecraftManager\Catalog\McJars;
use IByte\MinecraftManager\Models\Operation;
use IByte\MinecraftManager\Models\Profile;
use IByte\MinecraftManager\Software\ProfileWizard;
use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\SchemaInstaller;
use IByte\MinecraftManager\Support\Settings;
use IByte\MinecraftManager\Support\ViewCache;
use Livewire\Attributes\Locked;
use Throwable;

final class MinecraftManager extends Page
{
    protected static string|BackedEnum|null $navigationIcon = 'tabler-brand-minecraft';
    protected static ?string $slug = 'minecraft-manager';
    protected string $view = 'ibyte-minecraft-manager::admin';
    #[Locked] public string $area = 'overview';
    #[Locked] public array $types = [];
    #[Locked] public ?string $error = null;
    #[Locked] public ?string $message = null;
    public bool $enabled = false;
    public bool $experimental = false;
    public string $apiKey = '';
    public array $providers = ['mcjars', 'modrinth', 'curseforge'];
    public array $mapping = ['name' => '', 'egg_id' => '', 'software' => '', 'image' => '', 'jar_path' => 'server.jar',
        'version_variable' => '', 'loader' => '', 'content_type' => 'none', 'enabled' => true];

    public static function getNavigationLabel(): string { return trans('ibyte-minecraft-manager::messages.title'); }
    public function getTitle(): string { return self::getNavigationLabel(); }
    public static function canAccess(): bool { return auth()->user()?->isRootAdmin() ?? false; }
    private function guard(): void { abort_unless(self::canAccess(), 403); }

    public function mount(): void
    {
        $this->guard();
        $values = app(Settings::class)->values();
        $this->enabled = (bool) ($values['enabled'] ?? false);
        $this->experimental = (bool) ($values['experimental'] ?? false);
        $this->providers = $values['providers'] ?? ['mcjars', 'modrinth', 'curseforge'];
    }

    private function run(callable $callback): void
    {
        $this->guard();
        $this->error = $this->message = null;
        try { $callback(); $this->message = 'saved'; }
        catch (Failure $error) { $this->error = $error->reason; }
        catch (Throwable) { $this->error = 'request_failed'; }
    }

    public function switchArea(string $area): void
    {
        $this->guard();
        abort_unless(in_array($area, ['overview', 'settings', 'operations'], true), 422);
        $this->apiKey = '';
        $this->area = $area;
        $this->message = $this->error = null;
    }

    public function savePolicy(): void
    {
        $this->run(function (): void {
            $this->validate(['providers' => 'array|max:3', 'providers.*' => 'in:mcjars,modrinth,curseforge']);
            app(Settings::class)->save(['enabled' => $this->enabled, 'experimental' => $this->experimental, 'providers' => $this->providers]);
        });
    }

    public function replaceKey(): void
    {
        $this->guard();
        try { $this->run(fn () => app(Settings::class)->replaceCredential('curseforge', $this->apiKey)); }
        finally { $this->apiKey = ''; }
    }

    public function removeKey(): void { $this->run(fn () => app(Settings::class)->replaceCredential('curseforge', null)); }

    public function discover(): void
    {
        $this->run(fn () => $this->types = app(McJars::class)->types());
    }

    public function saveMapping(): void
    {
        $this->guard();
        $this->validate([
            'mapping.name' => 'required|string|max:100', 'mapping.egg_id' => 'required|integer|exists:eggs,id',
            'mapping.software' => 'required|string|max:128', 'mapping.image' => 'required|string|max:255',
            'mapping.jar_path' => 'required|string|max:240', 'mapping.loader' => 'nullable|string|max:100',
            'mapping.version_variable' => 'nullable|string|max:100', 'mapping.content_type' => 'required|in:none,mod,plugin,proxy',
            'mapping.enabled' => 'boolean',
        ]);
        $this->run(fn () => app(ProfileWizard::class)->save($this->mapping, app(McJars::class)));
    }

    public function toggleProfile(int $id): void
    {
        $this->run(function () use ($id): void {
            $profile = Profile::findOrFail($id);
            $profile->update(['enabled' => !$profile->enabled]);
        });
    }

    public function repairSchema(): void { $this->run(fn () => SchemaInstaller::install()); }

    public function reconcileReview(string $id): void
    {
        $this->run(function () use ($id): void {
            // This preview never mutates a server. Only stale read-only checks may be released.
            $updated = Operation::whereKey($id)->whereIn('status', ['queued', 'preflight'])
                ->where('updated_at', '<', now()->subMinutes(5))->update([
                    'status' => 'failed', 'step' => 'reconciled-read-only-review', 'error_code' => 'worker_interrupted',
                    'server_slot' => null, 'finished_at' => now(),
                ]);
            if (!$updated) { throw new Failure('reconciliation_not_available'); }
        });
    }

    protected function getViewData(): array
    {
        $this->guard();
        ViewCache::refresh(app('blade.compiler'));
        $settings = app(Settings::class);

        return [
            'installed' => $settings->installed(), 'keySet' => $settings->credential('curseforge') !== null,
            'eggs' => Egg::orderBy('name')->get(['id', 'name', 'docker_images']),
            'profiles' => $settings->installed() ? Profile::orderBy('name')->get() : collect(),
            'operations' => $settings->installed() ? Operation::latest()->limit(50)->get() : collect(),
        ];
    }
}
