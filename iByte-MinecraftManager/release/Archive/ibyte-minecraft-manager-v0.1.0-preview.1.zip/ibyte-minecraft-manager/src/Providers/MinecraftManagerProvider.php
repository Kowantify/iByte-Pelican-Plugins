<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Providers;

use App\Models\Subuser;
use IByte\MinecraftManager\Catalog\Catalog;
use IByte\MinecraftManager\Catalog\JsonTransport;
use IByte\MinecraftManager\Support\SafeHttp;
use Illuminate\Support\ServiceProvider;

final class MinecraftManagerProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(JsonTransport::class, SafeHttp::class);
        $this->app->bind(Catalog::class);
        Subuser::registerCustomPermissions('minecraft-manager', [
            'browse', 'plan', 'packages', 'software', 'packs', 'schedule', 'recover',
        ], 'ibyte-minecraft-manager::permissions', 'tabler-brand-minecraft', false);
    }

}
