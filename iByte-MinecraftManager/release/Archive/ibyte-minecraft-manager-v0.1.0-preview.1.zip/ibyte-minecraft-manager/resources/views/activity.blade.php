<x-filament::section>
    <x-slot name="heading">{{ __('ibyte-minecraft-manager::messages.activity') }}</x-slot>
    <div wire:poll.8s role="status" aria-live="polite">
        @forelse ($operations as $operation)
            <div class="space-y-2" wire:key="operation-{{ $operation->id }}">
                <p>{{ $operation->plan['release']['title'] ?? $operation->kind }} · {{ __('ibyte-minecraft-manager::messages.statuses.'.$operation->status) }}</p>
                <p>{{ $operation->id }} · {{ $operation->provider }} · {{ $operation->created_at->toIso8601String() }}</p>
                @if ($admin)<p>{{ __('ibyte-minecraft-manager::messages.server') }} #{{ $operation->server_id }} · {{ __('ibyte-minecraft-manager::messages.actor') }} #{{ $operation->actor_id }}</p>@endif
                @if ($operation->error_code)<p>{{ __('ibyte-minecraft-manager::messages.errors.'.$operation->error_code) }}</p>@endif
                @if (!$admin && $operation->actor_id === auth()->id() && in_array($operation->status, ['planned', 'queued'], true))
                    <x-filament::button color="gray" wire:click="cancelReview('{{ $operation->id }}')">{{ __('ibyte-minecraft-manager::messages.cancel') }}</x-filament::button>
                @endif
                @if (!$admin && $operation->actor_id === auth()->id() && $operation->error_code && !$operation->acknowledged_at)
                    <x-filament::button color="gray" wire:click="acknowledge('{{ $operation->id }}')">{{ __('ibyte-minecraft-manager::messages.acknowledge') }}</x-filament::button>
                @endif
                @if ($admin && in_array($operation->status, ['queued', 'preflight'], true) && $operation->updated_at->lt(now()->subMinutes(5)))
                    <x-filament::button color="gray" wire:click="reconcileReview('{{ $operation->id }}')">{{ __('ibyte-minecraft-manager::messages.reconcile_review') }}</x-filament::button>
                @endif
            </div>
        @empty
            <p>{{ __('ibyte-minecraft-manager::messages.activity_empty') }}</p>
        @endforelse
    </div>
</x-filament::section>
