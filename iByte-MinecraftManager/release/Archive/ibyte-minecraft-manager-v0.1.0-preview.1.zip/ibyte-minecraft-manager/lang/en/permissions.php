<?php

return [
    'name' => 'Minecraft Manager',
    'description' => 'Browse Minecraft catalogs and review changes for this server.',
    'browse' => 'Browse software and content catalogs', 'plan' => 'Create and check exact release reviews',
    'packages' => 'Modify packages (gated in this preview)', 'software' => 'Change server software (gated)',
    'packs' => 'Replace modpacks (gated)', 'schedule' => 'Schedule changes (gated)', 'recover' => 'Restore a recovery point (gated)',
];
