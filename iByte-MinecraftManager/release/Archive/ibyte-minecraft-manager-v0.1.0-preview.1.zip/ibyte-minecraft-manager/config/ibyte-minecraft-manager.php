<?php

return [
    'version' => '0.1.0-preview.1',
    'catalog_ttl' => 300,
    'max_json_bytes' => 4 * 1024 * 1024,
    'http_timeout' => 15,
    'max_archive_entries' => 10000,
    'max_expanded_bytes' => 2 * 1024 * 1024 * 1024,
    // No configuration switch may bypass the missing native maintenance fence.
];
