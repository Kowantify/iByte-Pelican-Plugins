# iByte Minecraft Manager 0.1.0-preview.1

Native Pelican **catalog and exact-release review preview**. This is not a working Minecraft installer. Server software/content/pack changes, updates, removal, startup changes and recovery execution remain disabled until safe node maintenance and recovery are verified. No administrator setting bypasses this gate.

## Setup

1. Use a disposable Panel first. Import the ZIP in Admin → Plugins, install and wait for Pelican's native background queue to finish. Reload existing queue workers through your normal service procedure after installation/update.
2. Open Admin → Minecraft Manager → Settings as a root administrator. Discover software types, select an installed egg and one of its images, supply its loader/content mapping and save. Enable the mapping and global policy. Servers with other eggs or images stay hidden.
3. Set the CurseForge API key privately in the password field. It is stored encrypted using the Panel application key, never returned to users. No environment edit or config-cache rebuild is needed.
4. Owners can browse mapped servers. Use native subuser permissions to grant `minecraft-manager.browse` and optionally `minecraft-manager.plan`.

## Use

The single Minecraft Manager server entry contains Overview, Server Software, Mods & Plugins, Modpacks and Activity. Browse, select exact releases and review metadata/blockers. Readiness checks run in the native queue and remain blocked while installation is gated. They do not download or alter server files. An installed-file scan needs native file-read permission and reachable Wings; unverified filenames remain unknown.

MCJars, Modrinth and authorized CurseForge metadata are implemented. No universal software/runtime compatibility, complete pack installation, other-provider parity, automatic updates or guaranteed rollback is claimed.

## Updating and rollback

Disable global policy and let read-only checks finish or cancel queued reviews. Import the next compatible immutable ZIP over this plugin, run the native installation/update action, and reload workers. Keep the previous ZIP for code rollback using the same procedure. If tables are missing, root administrators can use Repair missing schema on the plugin admin page.

Disable/uninstall retains profiles, encrypted credentials and activity. It never removes game files, worlds or native backups. No game rollback action is offered because this preview never changes game state. Keep the Panel application key safe to retain access to encrypted credentials.

## Compatibility evidence

Native tests: Panel canary source `a3b415fe4cdb8670ecad782f1d54020f166ab725`, PHP 8.5.11, Laravel 13.35.0, Filament 5.10.1, Livewire 4.4.7 and SQLite on Windows. The disposable fixture was security-updated to Symfony HTTP Foundation 8.1.9 after an advisory was found in upstream's lockfile. Operators must maintain their own Panel dependencies; this plugin does not replace them.

ZIP import/install/reimport/uninstall, permissions, Livewire, fresh database queue and Edge browser behavior were exercised. Optional native installer asset-build subprocesses were mocked unavailable; actual native assets were built separately for browser testing. This plugin adds no frontend dependencies or build requirement. Real Linux/Wings/container installation, game startup, backup recovery and commit concurrency are not tested or enabled. No Restic dependency, custom node addon, Blueprint requirement or Panel core edits.
