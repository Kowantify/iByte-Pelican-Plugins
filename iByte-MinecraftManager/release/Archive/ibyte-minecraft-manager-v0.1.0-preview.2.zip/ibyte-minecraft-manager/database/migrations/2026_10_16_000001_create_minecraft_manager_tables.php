<?php

use IByte\MinecraftManager\Support\SchemaInstaller;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
    {
        SchemaInstaller::install();
    }

    public function down(): void
    {
        // Native plugin uninstall rolls migrations back. Retain history, profiles,
        // encrypted credentials and inventory until a separately reviewed cleanup.
    }
};
