<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Providers;

use App\Models\Subuser;
use IByte\MinecraftManager\Catalog\Catalog;
use IByte\MinecraftManager\Catalog\JsonTransport;
use IByte\MinecraftManager\Support\SafeHttp;
use Illuminate\Support\ServiceProvider;

final class MinecraftManagerProvider extends ServiceProvider
{
    public function boot(): void
    {
        // Separate queue: native short retry reservations must never overlap an install.
        $base = config('queue.connections.'.config('queue.default'));
        if (is_array($base) && in_array($base['driver'] ?? '', ['redis', 'database'], true)) {
            config(['queue.connections.minecraft-manager' => array_replace($base, ['queue' => 'minecraft-manager', 'retry_after' => 1860])]);
        }
        if ($this->app->runningInConsole()) { $this->commands([\IByte\MinecraftManager\Console\WorkInstalls::class, \IByte\MinecraftManager\Console\ReconcileInstall::class]); }
    }

    public function register(): void
    {
        $this->app->bind(JsonTransport::class, SafeHttp::class);
        $this->app->bind(Catalog::class);
        Subuser::registerCustomPermissions('minecraft-manager', [
            'browse', 'plan', 'packages', 'software', 'packs', 'schedule', 'recover',
        ], 'ibyte-minecraft-manager::permissions', 'tabler-brand-minecraft', false);
    }

}
