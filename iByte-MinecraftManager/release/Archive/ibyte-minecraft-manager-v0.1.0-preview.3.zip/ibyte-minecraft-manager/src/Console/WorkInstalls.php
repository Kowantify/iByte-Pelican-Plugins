<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Console;

use Illuminate\Console\Command;

final class WorkInstalls extends Command
{
    protected $signature = 'minecraft-manager:work {--once} {--stop-when-empty}';
    protected $description = 'Run Minecraft Manager installs with an isolated long-running queue reservation';

    public function handle(): int
    {
        return $this->call('queue:work', ['connection' => 'minecraft-manager', '--queue' => 'minecraft-manager',
            '--timeout' => 1800, '--tries' => 1, '--sleep' => 3, '--once' => $this->option('once'), '--stop-when-empty' => $this->option('stop-when-empty')]);
    }
}
