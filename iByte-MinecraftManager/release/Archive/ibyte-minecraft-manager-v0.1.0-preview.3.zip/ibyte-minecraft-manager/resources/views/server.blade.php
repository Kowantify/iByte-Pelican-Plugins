<x-filament-panels::page>
    <x-filament::section>
        <x-slot name="heading">{{ __('ibyte-minecraft-manager::messages.welcome') }}</x-slot>
        <p>{{ __('ibyte-minecraft-manager::messages.preview_notice') }}</p>
    </x-filament::section>

    <nav aria-label="{{ __('ibyte-minecraft-manager::messages.sections') }}" class="flex flex-wrap gap-2">
        @foreach (['overview', 'software', 'packages', 'packs', 'activity'] as $item)
            <x-filament::button wire:click="switchArea('{{ $item }}')" :color="$area === $item ? 'primary' : 'gray'" :aria-current="$area === $item ? 'page' : null">
                {{ __('ibyte-minecraft-manager::messages.'.$item) }}
            </x-filament::button>
        @endforeach
    </nav>

    @if ($error)
        <div role="alert" tabindex="-1">{{ __('ibyte-minecraft-manager::messages.errors.'.$error) }}</div>
    @endif
    <div wire:loading role="status" aria-live="polite">{{ __('ibyte-minecraft-manager::messages.loading') }}</div>

    @if ($area === 'overview')
        <x-filament::section>
            <x-slot name="heading">{{ __('ibyte-minecraft-manager::messages.current_setup') }}</x-slot>
            <dl class="grid gap-4 sm:grid-cols-2">
                <div><dt>{{ __('ibyte-minecraft-manager::messages.profile') }}</dt><dd>{{ $profile->name }} · {{ $profile->software }}</dd></div>
                <div><dt>{{ __('ibyte-minecraft-manager::messages.minecraft_version') }}</dt><dd>{{ $runtime['version'] === 'unknown' ? __('ibyte-minecraft-manager::messages.unknown') : $runtime['version'] }}</dd></div>
                <div><dt>{{ __('ibyte-minecraft-manager::messages.loader') }}</dt><dd>{{ $runtime['loader'] ?: __('ibyte-minecraft-manager::messages.unknown') }}</dd></div>
                <div><dt>{{ __('ibyte-minecraft-manager::messages.java') }}</dt><dd>{{ __('ibyte-minecraft-manager::messages.java_unknown') }}</dd></div>
            </dl>
            <p>{{ __('ibyte-minecraft-manager::messages.profile_hint') }}</p>
        </x-filament::section>
        <x-filament::button wire:click="switchArea('software')">{{ __('ibyte-minecraft-manager::messages.explore_software') }}</x-filament::button>
    @elseif ($area === 'software')
        <x-filament::section>
            <x-slot name="heading">{{ __('ibyte-minecraft-manager::messages.software') }}</x-slot>
            <p>{{ __('ibyte-minecraft-manager::messages.software_hint') }}</p>
            <label><input type="checkbox" wire:model.live="experimental" /> {{ __('ibyte-minecraft-manager::messages.experimental') }}</label>
            <x-filament::button wire:click="browseSoftware" wire:loading.attr="disabled">{{ __('ibyte-minecraft-manager::messages.load_catalog') }}</x-filament::button>
            <div class="grid gap-4 sm:grid-cols-2">
                @foreach ($types as $type)
                    @if ($experimental || (!$type['experimental'] && !$type['deprecated']))
                        <div wire:key="type-{{ $type['id'] }}">
                            <h3>{{ $type['title'] }}</h3><p>{{ $type['description'] }}</p>
                            <p>{{ __('ibyte-minecraft-manager::messages.review_only') }}</p>
                            <x-filament::button color="gray" wire:click="chooseSoftware({{ \Illuminate\Support\Js::from($type['id']) }})">{{ __('ibyte-minecraft-manager::messages.browse_versions') }}</x-filament::button>
                        </div>
                    @endif
                @endforeach
            </div>
            @if ($software)
                <h3>{{ $software }} · {{ __('ibyte-minecraft-manager::messages.versions') }}</h3>
                <form wire:submit="softwareVersions(1)" class="flex flex-wrap gap-2">
                    <x-filament::input.wrapper><x-filament::input wire:model="query" :aria-label="__('ibyte-minecraft-manager::messages.search_versions')" maxlength="100" /></x-filament::input.wrapper>
                    <x-filament::button type="submit">{{ __('ibyte-minecraft-manager::messages.search') }}</x-filament::button>
                </form>
                @foreach ($versions as $version)
                    @if ($experimental || ($version['type'] ?? '') === 'RELEASE')
                        <x-filament::button color="gray" wire:click="chooseVersion({{ \Illuminate\Support\Js::from($version['id']) }})">{{ $version['id'] }} · {{ $version['type'] ?? '' }}</x-filament::button>
                    @endif
                @endforeach
                <div class="flex gap-2">
                    <x-filament::button color="gray" wire:click="softwareVersions({{ max(1, $page - 1) }})">{{ __('ibyte-minecraft-manager::messages.previous') }}</x-filament::button>
                    <x-filament::button color="gray" wire:click="softwareVersions({{ $page + 1 }})">{{ __('ibyte-minecraft-manager::messages.next') }}</x-filament::button>
                </div>
            @endif
            @foreach ($builds as $build)
                @if ($experimental || !($build['experimental'] ?? true))
                    <div wire:key="build-{{ $build['uuid'] }}" class="flex flex-wrap items-center gap-2">
                        <span>{{ $build['name'] }} · {{ $build['uuid'] }}</span>
                        @can('minecraft-manager.plan', $server)
                            <x-filament::button wire:click="review({{ \Illuminate\Support\Js::from($build['uuid']) }})">{{ __('ibyte-minecraft-manager::messages.review') }}</x-filament::button>
                        @endcan
                    </div>
                @endif
            @endforeach
            @if ($softwareVersion)
                <x-filament::button color="gray" wire:click="softwareBuilds({{ $buildPage + 1 }})">{{ __('ibyte-minecraft-manager::messages.next_builds') }}</x-filament::button>
            @endif
        </x-filament::section>
    @elseif ($area === 'packages' || $area === 'packs')
        <x-filament::section>
            <x-slot name="heading">{{ __('ibyte-minecraft-manager::messages.'.$area) }}</x-slot>
            <p>{{ __('ibyte-minecraft-manager::messages.content_hint') }}</p>
            <form wire:submit="search(1)" class="grid gap-4 sm:grid-cols-2">
                <label>{{ __('ibyte-minecraft-manager::messages.source') }}
                    <x-filament::input.wrapper><x-filament::input.select wire:model="provider">
                        <option value="modrinth">Modrinth</option><option value="curseforge">CurseForge</option>
                    </x-filament::input.select></x-filament::input.wrapper>
                </label>
                <label>{{ __('ibyte-minecraft-manager::messages.search') }}
                    <x-filament::input.wrapper><x-filament::input wire:model="query" maxlength="100" /></x-filament::input.wrapper>
                </label>
                <label>{{ __('ibyte-minecraft-manager::messages.minecraft_version') }}
                    <x-filament::input.wrapper><x-filament::input wire:model="gameVersion" maxlength="128" placeholder="26.1" /></x-filament::input.wrapper>
                </label>
                <label><input type="checkbox" wire:model="experimental" /> {{ __('ibyte-minecraft-manager::messages.experimental') }}</label>
                <x-filament::button type="submit" wire:loading.attr="disabled">{{ __('ibyte-minecraft-manager::messages.search') }}</x-filament::button>
            </form>
            <p>{{ __('ibyte-minecraft-manager::messages.results_count', ['count' => $total]) }}</p>
            <div class="grid gap-4 sm:grid-cols-2">
                @forelse ($results as $result)
                    <div wire:key="project-{{ $result['id'] }}">
                        <h3>{{ $result['title'] }}</h3><p>{{ $result['description'] }}</p>
                        <p>{{ __('ibyte-minecraft-manager::messages.compatibility_unknown') }}</p>
                        <x-filament::button color="gray" wire:click="inspectProject({{ \Illuminate\Support\Js::from($result['id']) }})">{{ __('ibyte-minecraft-manager::messages.inspect_releases') }}</x-filament::button>
                    </div>
                @empty
                    <p>{{ __('ibyte-minecraft-manager::messages.catalog_empty') }}</p>
                @endforelse
            </div>
            <div class="flex gap-2">
                <x-filament::button color="gray" wire:click="search({{ max(1, $page - 1) }})">{{ __('ibyte-minecraft-manager::messages.previous') }}</x-filament::button>
                <x-filament::button color="gray" wire:click="search({{ $page + 1 }})" :disabled="$page * 20 >= $total">{{ __('ibyte-minecraft-manager::messages.next') }}</x-filament::button>
            </div>
            @if ($project)
                <h3>{{ __('ibyte-minecraft-manager::messages.exact_releases') }}</h3>
                @forelse ($releases as $release)
                    <div wire:key="release-{{ $release['id'] }}" class="flex flex-wrap items-center gap-2">
                        <span>{{ $release['title'] }} · {{ $release['channel'] }}</span>
                        @can('minecraft-manager.plan', $server)
                            <x-filament::button wire:click="review({{ \Illuminate\Support\Js::from($release['id']) }})">{{ __('ibyte-minecraft-manager::messages.review') }}</x-filament::button>
                        @endcan
                    </div>
                @empty
                    <p>{{ __('ibyte-minecraft-manager::messages.no_compatible_release') }}</p>
                @endforelse
                @if ($provider === 'curseforge')
                    <x-filament::button color="gray" wire:click="moreReleases({{ $releasePage + 1 }})">{{ __('ibyte-minecraft-manager::messages.next_releases') }}</x-filament::button>
                @endif
            @endif
        </x-filament::section>
        @if ($area === 'packages')
            <x-filament::section>
                <x-slot name="heading">{{ __('ibyte-minecraft-manager::messages.installed') }}</x-slot>
                <p>{{ __('ibyte-minecraft-manager::messages.inventory_hint') }}</p>
                @can('file.read', $server)
                    <x-filament::button color="gray" wire:click="scan" wire:loading.attr="disabled">{{ __('ibyte-minecraft-manager::messages.rescan') }}</x-filament::button>
                @endcan
                @foreach ($inventory as $file)
                    <p>{{ $file['name'] }} · {{ number_format($file['size']) }} {{ __('ibyte-minecraft-manager::messages.bytes') }} · {{ __('ibyte-minecraft-manager::messages.unknown') }}</p>
                @endforeach
            </x-filament::section>
        @endif
    @elseif ($area === 'activity')
        @include('ibyte-minecraft-manager::activity', ['admin' => false])
    @endif

    @if ($review)
        <x-filament::section>
            <x-slot name="heading">{{ __('ibyte-minecraft-manager::messages.release_review') }}</x-slot>
            <p>{{ $review->plan['release']['title'] }} · {{ $review->plan['release']['id'] }} · {{ $review->provider }}</p>
            <p>{{ __('ibyte-minecraft-manager::messages.review_no_changes') }}</p>
            <p>{{ __('ibyte-minecraft-manager::messages.current_setup') }}: {{ $review->plan['current']['software'] }} · {{ $review->plan['current']['version'] }}</p>
            <p>{{ __('ibyte-minecraft-manager::messages.proposed_version') }}: {{ $review->plan['proposed']['version'] }}</p>
            @foreach ($review->plan['release']['files'] ?? [] as $file)
                <p>{{ $file['name'] }} · {{ number_format($file['size'] ?? 0) }} {{ __('ibyte-minecraft-manager::messages.bytes') }}</p>
            @endforeach
            <ul class="list-disc space-y-2">
                @foreach ($review->plan['blockers'] as $blocker)
                    <li>{{ __('ibyte-minecraft-manager::messages.errors.'.$blocker) }}</li>
                @endforeach
                @foreach ($review->plan['warnings'] ?? [] as $warning)
                    <li>{{ __('ibyte-minecraft-manager::messages.errors.'.$warning) }}</li>
                @endforeach
            </ul>
            @if ($review->status === 'planned' && $review->actor_id === auth()->id())
                @if ($review->plan['executable'])
                    <x-filament::button wire:click="install('{{ $review->id }}')" wire:confirm="Stop this server before installing. Install this exact release and required dependencies? Existing configurations and worlds are preserved. Replaced files are backed up. Runtime installs update the Java image and startup command. The server will remain stopped." wire:loading.attr="disabled">Install selected release</x-filament::button>
                @endif
                <x-filament::button wire:click="checkReadiness('{{ $review->id }}')" wire:loading.attr="disabled">{{ __('ibyte-minecraft-manager::messages.check_readiness') }}</x-filament::button>
            @endif
            <p>{{ __('ibyte-minecraft-manager::messages.expires', ['time' => $review->expires_at->toIso8601String()]) }}</p>
        </x-filament::section>
    @endif
</x-filament-panels::page>
