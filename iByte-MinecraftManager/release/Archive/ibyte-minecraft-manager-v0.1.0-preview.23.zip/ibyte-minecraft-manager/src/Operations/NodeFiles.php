<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use App\Models\Server;
use App\Repositories\Daemon\DaemonFileRepository;
use App\Repositories\Daemon\DaemonServerRepository;
use GuzzleHttp\Psr7\Utils;
use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\Input;
use IByte\MinecraftManager\Support\ArtifactDownloader;
use IByte\MinecraftManager\Support\UrlPolicy;

class NodeFiles
{
    private array $directories = [];
    private ?array $creationListings = null;
    public function __construct(protected Server $server) {}

    protected function files(): DaemonFileRepository { return app(DaemonFileRepository::class)->setServer($this->server); }

    /** Completion-aware native pulls. A moving window refills without polling sleeps. */
    public function pullDirect(array $downloads, callable $progress): void
    {
        $done=0; $total=count($downloads); $failure=null;
        $this->mkdirMany(array_values(array_unique(array_filter(array_map(static fn($item)=>dirname($item['path']),$downloads),static fn($dir)=>$dir!=='.'))));
        $handler=new \GuzzleHttp\Handler\CurlMultiHandler;
        $requests=(function()use($downloads,$progress,$handler,&$failure,&$done,$total){
            foreach($downloads as $item){
                if($failure){break;}
                try{
                    Input::nodePath($item['path']); UrlPolicy::host($item['url'],ArtifactDownloader::HOSTS);
                    $progress(['phase'=>'download','files'=>$done,'total'=>$total,'file'=>$item['name']??basename($item['path'])]);
                    $request=$this->files()->getHttpClient()->setHandler($handler)->timeout(300)->withOptions([
                        // Do not abort foreground HTTP on cancellation: Wings would keep writing.
                        // Finish the current window, then stop; only temporary paths are affected.
                        'progress'=>static function()use($progress,&$failure,&$done,$total){
                            if($failure){return;}
                            try{$progress(['phase'=>'download','files'=>$done,'total'=>$total,'file'=>'']);}catch(\Throwable $error){$failure=$error;}
                        },
                    ])->async()->post('/api/servers/'.$this->server->uuid.'/files/pull',[
                        'url'=>$item['url'],'root'=>'/'.(dirname($item['path'])==='.'?'':dirname($item['path'])),
                        'file_name'=>basename($item['path']),'foreground'=>true,
                    ]);
                    yield $item['path']=>method_exists($request,'buildPromise')?$request->buildPromise():$request;
                }catch(\Throwable $error){$failure??=$error;break;}
            }
        })();
        $byPath=array_column($downloads,null,'path');
        $pool=new \GuzzleHttp\Promise\EachPromise($requests,[
            'concurrency'=>3,
            'fulfilled'=>static function($response,$path)use(&$failure,&$done,$total,$progress,$byPath):void{
                try{
                    $response->throw();
                    if($response->status()!==200){throw new Failure('artifact_download_failed');}
                    $entry=$response->json();$item=$byPath[$path];
                    if(!is_array($entry)||!($entry['file']??false)||($entry['symlink']??false)||!isset($entry['size'])||isset($item['size'])&&(int)$entry['size']!==$item['size']){throw new Failure('artifact_download_failed',['file'=>$item['name']??basename($path)]);}
                    if(!$failure){$progress(['phase'=>'download','files'=>++$done,'total'=>$total,'file'=>$item['name']??basename($path)]);}
                }catch(\Throwable $error){$failure??=$error;}
            },
            'rejected'=>static function($error)use(&$failure):void{$failure??=$error instanceof \Throwable?$error:new Failure('artifact_download_failed');},
        ]);
        $pool->promise()->wait();
        if($failure){throw $failure;}
    }

    /** List extracted metadata only; never read a JAR/archive body through the Panel. */
    public function tree(string $root, callable $guard): array
    {
        Input::nodePath($root);$pending=[['',0]];$result=[];$seen=[];$count=0;$bytes=0;
        while($pending){
            [$relative,$depth]=array_pop($pending);if($depth>16){throw new Failure('unsafe_path');}$guard();
            foreach($this->files()->getDirectory('/'.$root.($relative===''?'':'/'.$relative)) as $entry){
                if(++$count>10000){throw new Failure('archive_entry_limit');}
                $name=Input::filename($entry['name']??'');$path=($relative===''?'':$relative.'/').$name;Input::path($path);
                $key=mb_strtolower($path,'UTF-8');if(isset($seen[$key])){throw new Failure('archive_duplicate');}$seen[$key]=true;
                if($entry['symlink']??false){throw new Failure('archive_special_file');}
                if($entry['directory']??false){$pending[]=[$path,$depth+1];continue;}
                if(!($entry['file']??false)||!is_numeric($entry['size']??null)||(int)$entry['size']<0){throw new Failure('archive_special_file');}
                $bytes+=(int)$entry['size'];if($bytes>2147483648){throw new Failure('pack_size_limit');}
                $result[$path]=$entry;
            }
        }
        return $result;
    }

    public function checkSizes(array $files): void
    {
        $entries=$this->entries(array_keys($files));
        foreach($files as $path=>$file){$entry=$entries[$path]??null;
            if(!$entry||!($entry['file']??false)||($entry['symlink']??false)||(int)$entry['size']!==$file['size']){throw new Failure('size_mismatch',['file'=>$path]);}
        }
    }

    public function assertStopped(): void
    {
        $fresh = $this->server->fresh();
        if (!$fresh || $fresh->uuid !== $this->server->uuid || $fresh->node_id !== $this->server->node_id || $fresh->status !== null || $fresh->transfer) {
            throw new Failure('server_state_changed');
        }
        $state = app(DaemonServerRepository::class)->setServer($fresh)->getDetails(5)['state'] ?? 'unknown';
        if ($state !== 'offline') { throw new Failure($state === 'missing' ? 'node_unavailable' : 'server_must_be_stopped'); }
    }

    public function mkdir(string $path): void
    {
        $root = '/';
        foreach (explode('/', Input::nodePath($path)) as $part) {
            $target = ltrim(rtrim($root, '/').'/'.$part, '/');
            if (isset($this->directories[$target])) { $root = '/'.$target; continue; }
            $entries = $this->creationListings === null ? $this->files()->getDirectory($root)
                : ($this->creationListings[$root] ??= $this->files()->getDirectory($root));
            $entry = collect($entries)->firstWhere('name', $part);
            // Repository listings are raw Wings Stat JSON, not Panel File models.
            if ($entry && (!($entry['directory'] ?? false) || ($entry['file'] ?? true) || ($entry['symlink'] ?? false))) {
                throw new Failure('node_path_collision', ['file' => rtrim($root, '/').'/'.$part]);
            }
            if (!$entry) { $this->files()->createDirectory($part, $root)->throw(); }
            if ($this->creationListings !== null) { $this->creationListings[$root][] = ['name'=>$part,'directory'=>true,'file'=>false,'symlink'=>false]; }
            $this->directories[$target] = true;
            $root = rtrim($root, '/') . '/' . $part;
        }
    }

    /** Share sibling listings only within this directory-creation phase. */
    public function mkdirMany(array $paths): void
    {
        $this->creationListings = [];
        try { foreach ($paths as $path) { $this->mkdir($path); } }
        finally { $this->creationListings = null; }
    }

    /** Wings owns every payload download. Only this operation's identifiers are cancelled. */
    public function pullMany(array $downloads, callable $progress): void
    {
        $pending = $downloads; $active = []; $done = 0; $total = count($downloads);
        $deadline = microtime(true) + 1200; $lastChange = microtime(true); $previous = null;
        try {
            while ($pending || $active) {
                if (microtime(true) > $deadline || microtime(true) - $lastChange > 300) { throw new Failure('artifact_download_failed'); }
                $running = $this->files()->getHttpClient()->get('/api/servers/'.$this->server->uuid.'/files/pull')->throw()->json('downloads') ?? [];
                $states = [];
                foreach ($running as $state) { $states[$state['Identifier']] = max(0, min(1, (float) $state['Progress'])); }
                $finished = array_filter($active, static fn ($id) => !array_key_exists($id, $states), ARRAY_FILTER_USE_KEY);
                // A single fresh listing per parent covers every completion in this poll.
                $listings = [];
                foreach ($finished as $id => $item) {
                    // Disappearance alone also means failure in Wings. Verify size now;
                    // publisher checksums are checked before the file can be promoted.
                    $parent = '/'.dirname($item['path']);
                    $listings[$parent] ??= collect($this->files()->getDirectory($parent))->keyBy('name')->all();
                    $entry = $listings[$parent][basename($item['path'])] ?? null;
                    if (!$entry || !($entry['file'] ?? false) || ($entry['symlink'] ?? false)
                        || isset($item['size']) && (int) $entry['size'] !== $item['size']) {
                        throw new Failure('artifact_download_failed', ['file'=>$item['name'] ?? basename($item['path'])]);
                    }
                    unset($active[$id]); ++$done; $lastChange = microtime(true);
                }
                while ($pending && count($active) < 3 && count($states) < 3) {
                    $item = reset($pending);
                    UrlPolicy::host($item['url'], ArtifactDownloader::HOSTS);
                    Input::nodePath($item['path']); if (dirname($item['path']) !== '.') { $this->mkdir(dirname($item['path'])); }
                    $response = $this->files()->pull($item['url'], '/'.dirname($item['path']), ['filename'=>basename($item['path']), 'foreground'=>false]);
                    if ($response->status() === 400 && str_contains($response->body(), '3 simultaneous')) { break; }
                    $id = $response->throw()->json('identifier');
                    if (!is_string($id) || !preg_match('/\A[0-9a-f-]{36}\z/D', $id)) { throw new Failure('node_unavailable'); }
                    array_shift($pending); $active[$id] = $item; $states[$id] = 0; $lastChange = microtime(true);
                }
                $fractions = 0; $names = [];
                foreach ($active as $id => $item) { $fractions += $states[$id] ?? 0; $names[] = $item['name'] ?? basename($item['path']); }
                $state = ['phase'=>'download', 'files'=>$done, 'total'=>$total, 'fraction'=>($done+$fractions)/max(1,$total), 'file'=>implode(', ', $names)];
                $signature = json_encode([$done, $states]);
                if ($signature !== $previous) { $lastChange = microtime(true); $previous = $signature; }
                $progress($state);
                if ($pending || $active) { usleep(250000); }
            }
        } finally {
            foreach ($active as $id => $item) {
                try { $this->files()->getHttpClient()->delete('/api/servers/'.$this->server->uuid.'/files/pull/'.$id)->throw(); } catch (\Throwable $error) { report($error); }
            }
        }
    }

    /** One bounded read verifies the publisher hash and supplies our SHA-256 journal. */
    public function verifiedRead(string $path, ?int $size, array $hashes = [], ?string $destination = null): array
    {
        Input::nodePath($path); $algorithm = null;
        foreach (['sha512'=>128, 'sha256'=>64, 'sha1'=>40] as $name=>$length) {
            if (!isset($hashes[$name])) { continue; }
            if (!is_string($hashes[$name]) || !preg_match('/\A[0-9a-f]{'.$length.'}\z/Di', $hashes[$name])) { throw new Failure('invalid_hash'); }
            $algorithm = $name; break;
        }
        if ($hashes && !$algorithm) { throw new Failure('weak_integrity_policy'); }
        if ($size !== null && ($size < 1 || $size > 536870912)) { throw new Failure('artifact_size_limit'); }
        $response = $this->files()->getHttpClient()->timeout(300)->withOptions(['stream'=>true])
            ->get('/api/servers/'.$this->server->uuid.'/files/contents', ['file'=>'/'.$path, 'download'=>'1'])->throw();
        $body = $response->toPsrResponse()->getBody(); $sha = hash_init('sha256'); $source = $algorithm ? hash_init($algorithm) : null; $bytes = 0;
        $write = $destination !== null ? fopen($destination, 'wb') : null;
        if ($write === false) { $body->close(); throw new Failure('staging_unwritable'); }
        try {
            while (!$body->eof()) {
                $chunk = $body->read(65536); $bytes += strlen($chunk);
                if ($bytes > ($size ?? 536870912)) { throw new Failure('artifact_size_limit'); }
                hash_update($sha, $chunk); if ($source) { hash_update($source, $chunk); }
                if ($write && fwrite($write, $chunk) !== strlen($chunk)) { throw new Failure('staging_unwritable'); }
            }
        } finally { $body->close(); if (is_resource($write)) { fclose($write); } }
        if ($size !== null && $bytes !== $size || $response->header('Content-Length') !== '' && (int) $response->header('Content-Length') !== $bytes) { throw new Failure('size_mismatch'); }
        if ($source && !hash_equals(strtolower($hashes[$algorithm]), hash_final($source))) { throw new Failure('hash_mismatch'); }
        return ['size'=>$bytes, 'sha256'=>hash_final($sha)];
    }

    /** Bounded initial publisher verification. Settle each batch before cleanup/recovery.
     * The completion callback may inspect the optional local copy before it is removed.
     */
    public function verifiedReadMany(array $reads, callable $completed, callable $heartbeat): void
    {
        $handler = new \GuzzleHttp\Handler\CurlMultiHandler;
        foreach (array_chunk($reads, 4, true) as $batch) {
            $streams = []; $promises = []; $copies = [];
            try {
                foreach ($batch as $path=>$item) {
                    Input::nodePath($path);
                    $algorithm = null;
                    foreach (['sha512'=>128,'sha256'=>64,'sha1'=>40] as $name=>$length) {
                        if (!isset($item['hashes'][$name])) { continue; }
                        if (!is_string($item['hashes'][$name]) || !preg_match('/\A[0-9a-f]{'.$length.'}\z/Di', $item['hashes'][$name])) { throw new Failure('invalid_hash'); }
                        $algorithm = $name; break;
                    }
                    if (!empty($item['hashes']) && !$algorithm) { throw new Failure('weak_integrity_policy'); }
                    $limit = $item['size'] ?? 536870912;
                    if (!is_int($limit) || $limit < 1 || $limit > 536870912) { throw new Failure('artifact_size_limit'); }
                    $heartbeat();
                    $copy = $item['destination'] ?? null;
                    $stream = $copy !== null ? fopen($copy, 'x+b') : fopen('php://temp/maxmemory:1048576', 'w+b');
                    if ($stream === false) { throw new Failure('staging_unwritable'); }
                    $streams[$path] = $stream;
                    if ($copy !== null) { $copies[] = $copy; }
                    $request = $this->files()->getHttpClient()->setHandler($handler)->timeout(300)
                        ->withHeaders(['Accept-Encoding'=>'identity'])->withOptions([
                            'stream'=>false,'sink'=>$stream,
                            'on_headers'=>static function (\Psr\Http\Message\ResponseInterface $response) use ($limit,$item): void {
                                if ($response->getStatusCode()!==200) { return; }
                                $length=$response->getHeaderLine('Content-Length');
                                if ($length!=='' && (!ctype_digit($length) || (int)$length>$limit || isset($item['size']) && (int)$length!==$item['size'])) { throw new Failure('size_mismatch'); }
                            },
                            'progress'=>static function ($total,$bytes) use ($limit,$heartbeat): void {
                                if ($bytes>$limit) { throw new Failure('artifact_size_limit'); }
                                $heartbeat();
                            },
                        ])->async()->get('/api/servers/'.$this->server->uuid.'/files/contents', ['file'=>'/'.$path,'download'=>'1']);
                    if (method_exists($request,'buildPromise')) { $request=$request->buildPromise(); }
                    $promises[$path]=$request->then(static function ($response) use ($stream,$path,$item,$algorithm,$limit,$completed): void {
                        $response->throw(); rewind($stream); $sha=hash_init('sha256'); $source=$algorithm ? hash_init($algorithm) : null; $bytes=0;
                        while (!feof($stream)) {
                            $chunk=fread($stream,65536);
                            if ($chunk===false) { throw new Failure('staging_unwritable'); }
                            $bytes+=strlen($chunk); if ($bytes>$limit) { throw new Failure('artifact_size_limit'); }
                            hash_update($sha,$chunk); if ($source) { hash_update($source,$chunk); }
                        }
                        $length=$response->header('Content-Length');
                        if (isset($item['size']) && $bytes!==$item['size'] || $length!=='' && $bytes!==(int)$length) { throw new Failure('size_mismatch'); }
                        if ($source && !hash_equals(strtolower($item['hashes'][$algorithm]),hash_final($source))) { throw new Failure('hash_mismatch'); }
                        // Flush inspection copies before the caller opens them, including on Windows.
                        fflush($stream);
                        $completed($path,['size'=>$bytes,'sha256'=>hash_final($sha)]);
                    });
                }
                $results=\GuzzleHttp\Promise\Utils::settle($promises)->wait();
                foreach ($results as $result) { if ($result['state']==='rejected') { throw $result['reason']; } }
            } finally {
                if ($promises) { \GuzzleHttp\Promise\Utils::settle($promises)->wait(); }
                foreach ($streams as $stream) { if (is_resource($stream)) { fclose($stream); } }
                foreach ($copies as $copy) { if (is_file($copy)) { unlink($copy); } }
            }
        }
    }

    public function extract(string $archive, string $directory): void
    {
        if ($directory === '.') {
            Input::nodePath($archive);
            $this->files()->decompressFile('/', $archive)->throw();
            return;
        }
        Input::nodePath($directory); $this->mkdir($directory);
        $name = '.imm-'.bin2hex(random_bytes(16)).'.zip';
        $target = $directory.'/'.$name; $this->move($archive, $target);
        $this->files()->decompressFile('/'.$directory, $name)->throw();
        $this->remove($target);
    }

    public function exists(string $path): bool
    {
        Input::nodePath($path);
        try { return collect($this->files()->getDirectory('/' . (dirname($path) === '.' ? '' : dirname($path))))->contains('name', basename($path)); }
        catch (\Illuminate\Http\Client\RequestException $error) { if ($error->response->status() === 404) { return false; } throw $error; }
    }

    /** Snapshot metadata once per parent; never cache bytes or checksum results. */
    public function entries(array $paths): array
    {
        $wanted = []; $result = []; $requested=array_fill_keys($paths,true); $missing=[];
        foreach ($paths as $path) {
            Input::nodePath($path);
            for ($target=$path; $target!=='.'; $target=dirname($target)) { $wanted[dirname($target)][basename($target)]=$target; }
        }
        uksort($wanted,static fn($a,$b)=>(($a==='.'?-1:substr_count($a,'/'))<=>($b==='.'?-1:substr_count($b,'/'))));
        foreach ($wanted as $parent=>$names) {
            if (isset($missing[$parent])) { foreach ($names as $path) { $missing[$path]=true; } continue; }
            try { $rows = $this->files()->getDirectory('/'.($parent === '.' ? '' : $parent)); }
            catch (\Illuminate\Http\Client\RequestException $error) { if ($error->response->status() === 404) { continue; } throw $error; }
            foreach ($rows as $row) {
                if (!is_array($row) || !isset($row['name']) || !is_string($row['name'])) { throw new Failure('node_unavailable'); }
                if (isset($names[$row['name']])) {
                    $path=$names[$row['name']];
                    if (isset($wanted[$path]) && (!($row['directory']??false) || ($row['symlink']??false))) { throw new Failure('node_path_collision',['file'=>$path]); }
                    if (isset($requested[$path])) { $result[$path]=$row; }
                    unset($names[$row['name']]);
                }
            }
            foreach ($names as $path) { $missing[$path]=true; }
        }
        return $result;
    }

    public function hashOrNull(string $path): ?string
    {
        try { return $this->hash($path); }
        catch (\Illuminate\Http\Client\RequestException $error) { if ($error->response->status() === 404) { return null; } throw $error; }
    }

    /** Verify every final byte, with at most four native reads in flight.
     * Bounded temporary streams spill after 1 MiB; nothing is saved in the volume.
     * Settle the whole current batch before cleanup/rollback, even after an error.
     */
    public function verifyMany(array $journal, callable $progress): void
    {
        $writes=[]; $removed=[]; $checked=0; $total=count($journal);
        foreach ($journal as $path=>$item) {
            Input::nodePath($path);
            if ($item['new']===null) { $removed[]=$path; continue; }
            if (!is_string($item['new']) || !preg_match('/\A[0-9a-f]{64}\z/D',$item['new'])) { throw new Failure('invalid_hash'); }
            $writes[$path]=$item;
        }
        $present=$this->entries($removed);
        foreach ($removed as $path) {
            if (isset($present[$path])) { throw new Failure('node_hash_mismatch',['file'=>$path]); }
            $progress(++$checked,$total,$path);
        }
        $handler=new \GuzzleHttp\Handler\CurlMultiHandler;
        foreach (array_chunk($writes,4,true) as $batch) {
            $streams=[]; $promises=[];
            try {
                foreach ($batch as $path=>$item) {
                    $stream=fopen('php://temp/maxmemory:1048576','w+b');
                    if ($stream===false) { throw new Failure('staging_unwritable'); }
                    $streams[$path]=$stream;
                    $limit=$item['size']??536870912;
                    if (!is_int($limit) || $limit<0 || $limit>536870912) { throw new Failure('artifact_size_limit'); }
                    $request=$this->files()->getHttpClient()->setHandler($handler)->timeout(300)
                        ->withHeaders(['Accept-Encoding'=>'identity'])->withOptions([
                            'stream'=>false,'sink'=>$stream,
                            'on_headers'=>static function (\Psr\Http\Message\ResponseInterface $response) use ($limit,$item): void {
                                if ($response->getStatusCode()!==200) { return; }
                                $length=$response->getHeaderLine('Content-Length');
                                if ($length!=='' && (!ctype_digit($length) || (int)$length>$limit || isset($item['size']) && (int)$length!==$item['size'])) { throw new Failure('size_mismatch'); }
                            },
                            'progress'=>static function ($totalBytes,$downloaded) use ($limit): void { if ($downloaded>$limit) { throw new Failure('artifact_size_limit'); } },
                        ])->async()->get('/api/servers/'.$this->server->uuid.'/files/contents',['file'=>'/'.$path,'download'=>'1']);
                    // Laravel 13 defers async requests; older native clients return a built promise.
                    if (method_exists($request,'buildPromise')) { $request=$request->buildPromise(); }
                    $promises[$path]=$request->then(static function ($response) use ($stream,$item,$path,$limit,$progress,&$checked,$total): void {
                        $response->throw(); rewind($stream); $hash=hash_init('sha256'); $bytes=0;
                        while (!feof($stream)) {
                            $chunk=fread($stream,65536);
                            if ($chunk===false) { throw new Failure('staging_unwritable'); }
                            $bytes+=strlen($chunk); if ($bytes>$limit) { throw new Failure('artifact_size_limit'); }
                            hash_update($hash,$chunk);
                        }
                        $length=$response->header('Content-Length');
                        if (isset($item['size']) && $bytes!==$item['size'] || $length!=='' && $bytes!==(int)$length) { throw new Failure('size_mismatch'); }
                        if (!hash_equals($item['new'],hash_final($hash))) { throw new Failure('node_hash_mismatch',['file'=>$path]); }
                        $progress(++$checked,$total,$path);
                    });
                }
                $results=\GuzzleHttp\Promise\Utils::settle($promises)->wait();
                foreach ($results as $result) { if ($result['state']==='rejected') { throw $result['reason']; } }
            } finally {
                // Also covers an exception while constructing a later request in the batch.
                if ($promises) { \GuzzleHttp\Promise\Utils::settle($promises)->wait(); }
                foreach ($streams as $stream) { if (is_resource($stream)) { fclose($stream); } }
            }
        }
    }

    public function upload(string $path, string $local): void
    {
        Input::nodePath($path);
        if (dirname($path) !== '.') { $this->mkdir(dirname($path)); }
        $handle = fopen($local, 'rb');
        if ($handle === false) { throw new Failure('staging_unwritable'); }
        try {
            $this->files()->getHttpClient()->timeout(300)->withQueryParameters(['file' => '/' . $path])
                ->withBody(Utils::streamFor($handle), 'application/octet-stream')
                ->post('/api/servers/' . $this->server->uuid . '/files/write')->throw();
        } finally { if (is_resource($handle)) { fclose($handle); } }
    }

    public function assertRegular(string $path): void
    {
        Input::nodePath($path);
        if (dirname($path) !== '.') { $this->mkdir(dirname($path)); }
        $entry = collect($this->files()->getDirectory('/'.(dirname($path) === '.' ? '' : dirname($path))))->firstWhere('name', basename($path));
        if (!$entry || !($entry['file'] ?? false) || ($entry['symlink'] ?? false)) { throw new Failure('node_path_collision', ['file'=>$path]); }
    }

    public function removeEmptyDirectory(string $path): void
    {
        if (!$this->exists($path)) { return; }
        $entry = collect($this->files()->getDirectory('/'.(dirname($path) === '.' ? '' : dirname($path))))->firstWhere('name', basename($path));
        if (!$entry || !($entry['directory'] ?? false) || ($entry['symlink'] ?? false)) { return; }
        if ($this->files()->getDirectory('/'.$path) === []) { $this->remove($path); unset($this->directories[$path]); }
    }

    public function pruneEmptyTree(string $path, int $depth = 0): void
    {
        if ($depth > 32 || !$this->exists($path)) { return; }
        $entry = collect($this->files()->getDirectory('/'.(dirname($path) === '.' ? '' : dirname($path))))->firstWhere('name', basename($path));
        if (!$entry || !($entry['directory'] ?? false) || ($entry['symlink'] ?? false)) { return; }
        foreach ($this->files()->getDirectory('/'.$path) as $child) {
            if (($child['directory'] ?? false) && !($child['symlink'] ?? false)) { $this->pruneEmptyTree($path.'/'.$child['name'], $depth+1); }
        }
        $this->removeEmptyDirectory($path);
    }

    public function hash(string $path, int $limit = 536870912): string
    {
        Input::nodePath($path);
        $response = $this->files()->getHttpClient()->timeout(300)->withOptions(['stream' => true])
            ->get('/api/servers/' . $this->server->uuid . '/files/contents', ['file' => '/'.$path, 'download' => '1'])->throw();
        $body = $response->toPsrResponse()->getBody(); $hash = hash_init('sha256'); $bytes = 0;
        try {
            while (!$body->eof()) {
                $chunk = $body->read(65536); $bytes += strlen($chunk);
                if ($bytes > $limit) { throw new Failure('artifact_size_limit'); }
                hash_update($hash, $chunk);
            }
            $length = $response->header('Content-Length');
            if ($length !== '' && $bytes !== (int) $length) { throw new Failure('size_mismatch'); }
        } finally { $body->close(); }
        return hash_final($hash);
    }

    public function text(string $path, int $limit = 1048576): string
    {
        if (!$this->exists($path)) { return ''; }
        $response = $this->files()->getHttpClient()->timeout(20)->withOptions(['stream' => true])
            ->get('/api/servers/'.$this->server->uuid.'/files/contents', ['file' => '/'.Input::nodePath($path)])->throw();
        $body = $response->toPsrResponse()->getBody();
        try { $text = $body->read($limit + 1); if (strlen($text) > $limit) { throw new Failure('artifact_size_limit'); } return $text; }
        finally { $body->close(); }
    }

    public function move(string $from, string $to): void
    {
        Input::nodePath($from); Input::nodePath($to);
        if (dirname($to) !== '.') { $this->mkdir(dirname($to)); }
        $this->files()->renameFiles('/', [['from' => $from, 'to' => $to]])->throw();
    }

    /** Native Wings accepts independent renames in one request. Never chain moves. */
    public function moveMany(array $moves): void
    {
        foreach (array_chunk($moves,100) as $chunk) {
            $targets=[];
            foreach ($chunk as $move) { Input::nodePath($move['from']); Input::nodePath($move['to']); $targets[]=dirname($move['to']); }
            $this->mkdirMany(array_values(array_filter(array_unique($targets),static fn($path)=>$path!=='.')));
            $this->files()->renameFiles('/',$chunk)->throw();
        }
    }

    public function removeMany(array $paths): void
    {
        foreach (array_chunk($paths,100) as $chunk) { foreach ($chunk as $path) { Input::nodePath($path); } $this->files()->deleteFiles('/',$chunk)->throw(); }
    }

    public function remove(string $path): void { $this->files()->deleteFiles('/', [Input::nodePath($path)])->throw(); }
}
