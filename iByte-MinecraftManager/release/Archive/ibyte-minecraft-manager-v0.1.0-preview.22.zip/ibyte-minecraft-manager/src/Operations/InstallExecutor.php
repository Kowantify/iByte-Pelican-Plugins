<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use App\Models\Server;
use App\Models\User;
use App\Repositories\Daemon\DaemonServerRepository;
use App\Services\Servers\StartupModificationService;
use IByte\MinecraftManager\Models\Operation;
use IByte\MinecraftManager\Models\Profile;
use IByte\MinecraftManager\Models\Setting;
use IByte\MinecraftManager\Support\Access;
use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\RuntimeVariables;
use Illuminate\Support\Facades\Context;
use Throwable;

final class InstallExecutor
{
    public function __construct(private readonly InstallPreparer $preparer, private readonly Access $access) {}

    public function authorize(Operation $op): array
    {
        $server = Server::find($op->server_id); $actor = User::find($op->actor_id);
        if (!$this->access->pluginEnabled() || !$server || !$actor || $server->uuid !== $op->server_uuid || $server->node_id !== $op->node_id) { throw new Failure('source_identity_or_plugin_changed'); }
        // Recheck ownership at phase boundaries and periodically during long loops.
        $current = Operation::select(['id', 'server_slot', 'status'])->findOrFail($op->id);
        if ($current->status==='cancelling') { throw new Failure('install_cancelled'); }
        if ($op->status !== 'planned' && ($current->server_slot !== $server->id || !in_array($current->status, ['queued', 'preflight', 'downloading', 'verifying', 'applying'], true))) { throw new Failure('operation_ownership_lost'); }
        $action = ['software' => 'software', 'package' => 'packages', 'pack' => 'packs'][$op->kind];
        $profile = $this->access->authorize($actor, $server, $action);
        if (!hash_equals($op->selection['fingerprint'], Access::fingerprint($server, $profile))
            || !hash_equals($op->selection['policy_digest'], hash('sha256', json_encode(app(\IByte\MinecraftManager\Support\Settings::class)->values(), JSON_THROW_ON_ERROR)))) { throw new Failure('stale_plan'); }
        foreach (['file.read', 'file.read-content', 'file.create', 'file.update', 'file.delete', ...($op->kind !== 'package' ? ['startup.update'] : [])] as $permission) {
            Context::forget("users.{$actor->id}.servers.{$server->id}.$permission");
            abort_unless($actor->can($permission, $server), 403);
        }
        return [$server, $actor, $profile];
    }

    private function runtimeSettings(Server $server, User $actor, Profile $profile, array $runtime): array
    {
        $image = null; $java = (int) $runtime['java'];
        foreach (array_unique([$server->image, ...array_values($server->egg->docker_images ?? [])]) as $candidate) {
            if (preg_match('~(?:java[_:-]?)(\d+)(?:\D|$)~i', $candidate, $match) && (int) $match[1] === $java) { $image = $candidate; break; }
        }
        if (!$image) { throw new Failure('java_image_not_approved'); }
        if ($image !== $server->image) {
            Context::forget("users.{$actor->id}.servers.{$server->id}.startup.docker-image");
            abort_unless($actor->can('startup.docker-image', $server), 403);
        }
        $environment = RuntimeVariables::updates($server, $runtime);
        try { app(\App\Services\Servers\VariableValidatorService::class)->setUserLevel(User::USER_LEVEL_ADMIN)->handle($server->egg_id, array_replace(RuntimeVariables::environment($server), $environment)); }
        catch (\Illuminate\Validation\ValidationException $error) { throw new Failure('runtime_variables_invalid', ['variables'=>array_keys($error->errors())]); }
        return ['startup' => RuntimeVariables::startup($server, $runtime), 'docker_image' => $image,
            'skip_scripts' => $server->skip_scripts, 'environment'=>$environment];
    }

    public function run(Operation $op, array $release): void
    {
        [$server, $actor, $profile] = $this->authorize($op);
        $node = app(NodeFiles::class, ['server' => $server]); $node->assertStopped();
        if ($op->kind === 'software') { $this->runtimeSettings($server, $actor, $profile, ['software' => $release['project'], 'java' => $release['java'], 'launcher' => 'server.jar', 'version'=>$release['version'], 'build_version'=>$release['build_version'] ?? '']); }
        $work = storage_path('app/minecraft-manager/'.$op->id);
        if (!is_dir($work) && !mkdir($work, 0700, true)) { throw new Failure('staging_unwritable'); }
        $journal = []; $startupChanged = false; $settings = null;
        $oldStartup = ['startup' => $server->startup, 'docker_image' => $server->image, 'skip_scripts' => $server->skip_scripts, 'environment'=>RuntimeVariables::snapshot($server)];
        $workspace = new InstallWorkspace($node, $op);
        $plan = $op->plan; $plan['previous_startup'] = $oldStartup; $op->update(['plan'=>$plan]);
        $workspace->save();
        $clock = new ProgressClock;
        try {
            app(LegacyWorkspace::class)->migrate($node, $server);
            $op->update(['status' => 'downloading', 'step' => 'prepare']);
            $lastProgress = 0.0; $lastPhase = null;
            $progress = function (array $state) use ($op, $node, $clock, &$lastProgress, &$lastPhase): void {
                if ($lastPhase === $state['phase'] && microtime(true) - $lastProgress < 1 && ($state['files'] ?? 0) !== ($state['total'] ?? -1)) { return; }
                $lastPhase = $state['phase'];
                $lastProgress = microtime(true);
                $this->authorize($op); $node->assertStopped();
                $plan=$op->plan;$plan['progress']=$clock->snapshot($state);
                $status = $op->status;
                if (in_array($status,['downloading','verifying'],true)) {
                    $status = in_array($state['phase'],['verify','archive-check','extract','existing'],true) ? 'verifying' : 'downloading';
                }
                $op->update(['plan'=>$plan,'status'=>$status]);
            };
            $progress(['phase'=>'prepare','files'=>0]);
            $lastGuard = 0.0;
            $guard = function (bool $force = false) use ($op, $node, &$lastGuard): void {
                if (!$force && microtime(true)-$lastGuard < 2) { return; }
                $this->authorize($op); $node->assertStopped(); $lastGuard=microtime(true);
            };
            $prepared = $this->preparer->prepare($release, $op->selection, $profile, $work, $progress, new NodePreparation($node, $workspace, $progress),
                fn (array $runtime) => $this->runtimeSettings($server, $actor, $profile, $runtime));
            $preparedProjects = [];
            foreach ($prepared['files'] as $file) { $preparedProjects[($file['owner']['provider'] ?? '').':'.($file['owner']['project'] ?? '')] = true; }
            $settings = $prepared['runtime'] ? $this->runtimeSettings($server, $actor, $profile, $prepared['runtime']) : null;
            $op->update(['status' => 'verifying', 'step' => 'stage']); $total = 0;
            $progress(['phase'=>'existing','files'=>0,'total'=>count($prepared['files']),'file'=>'']);
            $inventory = \Illuminate\Support\Facades\DB::table('imm_inventory')->where('server_id', $server->id)->get();
            $guard(true);
            $existing = $node->entries(array_keys(array_filter($prepared['files'],static fn($file)=>empty($file['applied']))));
            $completed=0;
            foreach ($prepared['files'] as $path => $file) {
                ++$completed;
                $total += $file['size']; if ($total > 2147483648) { throw new Failure('pack_size_limit'); }
                $guard();
                $managed = $inventory->firstWhere('path', $path);
                $previous = $managed ? json_decode($managed->metadata, true) : [];
                if ($op->kind === 'package' && ($previous['owner']['kind'] ?? '') === 'pack') { throw new Failure('pack_owned_file'); }
                // Existing configuration and operator-owned root files are preserved.
                $root = explode('/', $path)[0];
                $configuration = in_array($root, ['config', 'defaultconfigs', 'kubejs', 'scripts', 'patchouli_books'], true)
                    || in_array($root, ['mods', 'plugins'], true) && !str_ends_with(strtolower($path), '.jar');
                $old = !empty($file['applied']) ? $workspace->original($path) : (isset($existing[$path]) ? $node->hash($path) : null);
                if ($configuration && $old !== null) { continue; }
                $journal[$path] = ['old' => $old, 'new' => $file['sha256'], 'stage' => $file['remote'], 'owner' => $file['owner'], 'applied'=>!empty($file['applied']), 'size'=>$file['size']];
                if ($completed % 25===0 || $completed===count($prepared['files'])) { $progress(['phase'=>'existing','files'=>$completed,'total'=>count($prepared['files']),'file'=>$path]); }
            }
            $progress(['phase'=>'existing','files'=>$completed,'total'=>count($prepared['files']),'file'=>$path]);
            foreach ($inventory as $managed) {
                $meta = json_decode($managed->metadata, true); $owner = $meta['owner'] ?? [];
                $retire = $op->kind === 'pack' && ($owner['kind'] ?? '') === 'pack'
                    || $prepared['runtime'] !== null && ($owner['kind'] ?? '') === 'software'
                    || $op->kind === 'package' && ($owner['kind'] ?? '') === 'package' && isset($preparedProjects[($owner['provider'] ?? '').':'.($owner['project'] ?? '')]);
                $path = $managed->path;
                $runtimeRoot = ($owner['kind'] ?? '') === 'software' && in_array($path, ['minecraft.jar','server.properties.fabric','fabric-server-launcher.properties','quilt-server-launcher.properties'], true);
                if (!$retire || isset($prepared['files'][$path]) || !in_array(explode('/', $path)[0], ['mods', 'plugins', 'libraries', 'versions'], true) && !$runtimeRoot || !$node->exists($path)) { continue; }
                if ($node->hash($path) !== ($meta['sha256'] ?? '')) { throw new Failure('managed_file_modified', ['file'=>$path]); }
                $journal[$path] = ['old' => $meta['sha256'], 'new' => null, 'stage' => null, 'owner' => $owner];
            }
            $writes = [];
            foreach ($journal as $path=>$item) {
                $writes[$path] = $item['new'];
                if ($item['stage'] && empty($item['applied'])) { $writes[$item['stage']] = null; }
            }
            $workspace->reserve($writes);
            foreach ($journal as $path=>$item) { if ($workspace->original($path) !== $item['old']) { throw new Failure('file_changed_during_install'); } }
            $plan = $op->fresh()->plan; $plan['installed_files'] = $journal;
            $plan['skipped'] = $prepared['skipped'] ?? [];
            $plan['source_resolutions'] = $prepared['source_resolutions'] ?? [];
            if ($settings) {
                $oldStartup['environment'] = array_intersect_key($oldStartup['environment'], $settings['environment']);
                $plan['previous_startup'] = $oldStartup;
                $plan['applied_startup'] = $settings;
            }
            $op->update(['plan' => $plan, 'status' => 'applying', 'step' => 'replace']);
            $applied = 0;
            $guard(true);
            $progress(['phase'=>'apply','files'=>0,'total'=>count($journal),'file'=>'']);
            $workspace->promoteMany($journal,$guard);
            $progress(['phase'=>'apply','files'=>count($journal),'total'=>count($journal),'file'=>'']);
            if ($settings) {
                [$fresh] = $this->authorize($op); $node->assertStopped();
                $changed = app(StartupModificationService::class)->setUserLevel(User::USER_LEVEL_ADMIN)->handle($fresh, RuntimeVariables::forNativeUpdate($fresh, $settings));
                $startupChanged = true;
                app(DaemonServerRepository::class)->setServer($changed)->sync();
            }
            $op->update(['status' => 'verifying-result', 'step' => 'verify']);
            $node->assertStopped();
            $plan=$op->plan; $plan['progress']=$clock->snapshot(['phase'=>'result','files'=>0,'total'=>count($journal),'file'=>'']); $op->update(['plan'=>$plan]);
            $lastVerificationProgress=0.0;
            $node->verifyMany($journal,function (int $checked,int $total,string $path) use ($op,$clock,&$lastVerificationProgress): void {
                if ($checked===$total || microtime(true)-$lastVerificationProgress>=0.5) {
                    if (Operation::whereKey($op->id)->value('status')==='cancelling') { throw new Failure('install_cancelled'); }
                    $lastVerificationProgress=microtime(true);
                    $plan = $op->plan; $plan['progress'] = $clock->snapshot(['phase'=>'result','files'=>$checked,'total'=>$total,'file'=>$path]);
                    $op->update(['plan'=>$plan]);
                }
            });
            // Runtime settings have now changed the original plan fingerprint.
            // Continue the verified-result display update without re-running pre-apply authorization.
            $plan = $op->plan; $plan['progress'] = $clock->snapshot(['phase'=>'cleanup','files'=>0]); $op->update(['plan'=>$plan]);
            $workspace->cleanup(false);
            if (Operation::whereKey($op->id)->value('status')==='cancelling') { throw new Failure('install_cancelled'); }
            if ($settings && !RuntimeVariables::matches($server->fresh(), $settings)) { throw new Failure('startup_changed_during_install'); }
            $plan = $op->plan; $plan['progress'] = $clock->snapshot(['phase'=>'record','files'=>0]); $op->update(['plan'=>$plan]);
            \Illuminate\Support\Facades\DB::transaction(function () use ($prepared, $server, $journal, $op, $settings, $clock): void {
                $current=Operation::whereKey($op->id)->lockForUpdate()->firstOrFail();
                if ($current->status==='cancelling') { throw new Failure('install_cancelled'); }
                if ($current->status!=='verifying-result' || $current->server_slot!==$server->id) { throw new Failure('operation_ownership_lost'); }
                if ($prepared['runtime']) { Setting::updateOrCreate(['key' => 'runtime-'.$server->id], ['value' => [...$prepared['runtime'], 'environment'=>$settings['environment'], 'source'=>'installed']]); }
                foreach ($journal as $path => $item) {
                    if ($item['new'] === null) { \Illuminate\Support\Facades\DB::table('imm_inventory')->where('server_id', $server->id)->where('path', $path)->delete(); continue; }
                    \Illuminate\Support\Facades\DB::table('imm_inventory')->updateOrInsert(['server_id' => $server->id, 'path' => $path],
                        ['metadata' => json_encode(['sha256' => $item['new'], 'owner' => $item['owner'], 'operation' => $op->id], JSON_THROW_ON_ERROR), 'created_at' => now(), 'updated_at' => now()]);
                }
                $plan=$op->plan; $plan['progress']=$clock->snapshot(['phase'=>'record','files'=>1,'total'=>1]);
                $op->update(['status' => 'succeeded', 'step' => 'installed', 'server_slot' => null, 'finished_at' => now(),'plan'=>$plan]);
            });
        } catch (Throwable $error) {
            if (!$error instanceof Failure) { report($error); }
            $safe = true;
            $cancelled=($error instanceof Failure && $error->reason==='install_cancelled') || $op->fresh()->status==='cancelling';
            // Persisted journal also permits manual recovery after worker termination.
            if (!empty($op->fresh()->plan['journal'])) {
                $plan=$op->fresh()->plan; $plan['progress']=$clock->snapshot(['phase'=>'rollback','files'=>0]);
                $op->update(['status' => 'rolling-back', 'step' => 'restore','plan'=>$plan]);
                try {
                    $node->assertStopped();
                    if ($startupChanged) {
                        $fresh = $server->fresh();
                        if (!RuntimeVariables::matches($fresh, $settings)) { throw new Failure('startup_changed_during_install'); }
                        $restored = app(StartupModificationService::class)->setUserLevel(User::USER_LEVEL_ADMIN)->handle($fresh, RuntimeVariables::forNativeUpdate($fresh, $oldStartup));
                        app(DaemonServerRepository::class)->setServer($restored)->sync();
                    }
                    $workspace->rollback();
                } catch (Throwable) { $safe = false; }
            }
            $reason = $error instanceof Failure ? $error->reason : ($error instanceof \Symfony\Component\HttpKernel\Exception\HttpException ? 'permission_denied' : 'installation_failed');
            $failurePlan = $op->fresh()->plan;
            $failurePlan['progress']=$clock->snapshot(['phase'=>$failurePlan['progress']['phase'] ?? 'prepare','files'=>$failurePlan['progress']['files'] ?? 0]);
            if ($error instanceof Failure && $error->context) { $failurePlan['failure'] = $error->context; }
            $op->update(['status' => $safe ? ($cancelled ? 'cancelled' : 'failed') : 'needs-reconciliation', 'step' => $safe ? 'restored-or-unchanged' : 'manual-recovery', 'error_code' => $cancelled ? 'install_cancelled' : $reason,
                'server_slot' => $safe ? null : $server->id, 'finished_at' => now(), 'plan' => $failurePlan]);
        } finally {
            if (in_array($op->fresh()->status, ['succeeded','failed','cancelled'], true)) {
                try { $workspace->cleanup(true); } catch (Throwable $cleanupError) { report($cleanupError); }
            }
            // Inspection work is private to the Panel. Interrupted recovery is retained separately.
            $this->clean($work);
        }
    }

    private function clean(string $path): void
    {
        if (!is_dir($path) || is_link($path)) { return; }
        foreach (new \FilesystemIterator($path) as $file) { if ($file->isDir() && !$file->isLink()) { $this->clean($file->getPathname()); } else { @unlink($file->getPathname()); } }
        @rmdir($path);
    }
}
