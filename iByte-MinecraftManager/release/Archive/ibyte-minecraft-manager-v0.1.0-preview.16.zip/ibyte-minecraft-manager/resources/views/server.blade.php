<x-filament-panels::page>
    @include('ibyte-minecraft-manager::styles')
    <div class="imm">
        <x-filament::tabs label="Minecraft Manager">
            @foreach (['overview','software','packages','packs'] as $item)
                <x-filament::tabs.item :active="$area === $item" wire:click="switchArea('{{ $item }}')">{{ __('ibyte-minecraft-manager::messages.'.$item) }}</x-filament::tabs.item>
            @endforeach
        </x-filament::tabs>
        @include('ibyte-minecraft-manager::activity',['admin'=>false])
        @if ($installQueue)
            <x-filament::section :heading="'Install queue ('.count($installQueue).')'" compact>
                <div class="imm-form">
                    <div class="imm-form imm-queue-items">@foreach ($installQueue as $key=>$item)
                        <div class="imm-row imm-between" wire:key="queued-{{ $key }}">
                            <div><strong>{{ $item['title'] }}</strong><p class="fi-section-header-description">{{ $item['release'] }}</p></div>
                            <x-filament::icon-button icon="tabler-x" color="gray" wire:click="removeQueued({{ \Illuminate\Support\Js::from($key) }})" :label="'Remove '.$item['title']" wire:loading.attr="disabled" />
                        </div>
                    @endforeach</div>
                    <div class="imm-row"><x-filament::button wire:click="installQueued" wire:loading.attr="disabled">Install</x-filament::button><x-filament::button color="gray" wire:click="clearQueue" wire:loading.attr="disabled">Clear</x-filament::button></div>
                </div>
            </x-filament::section>
        @endif

        @if ($error)<p role="alert">{{ __('ibyte-minecraft-manager::messages.errors.'.$error) }}</p>@endif
        <div class="imm-loading" wire:loading.delay role="status" aria-live="polite"><x-filament::loading-indicator /> <span>Loading…</span></div>
        @if ($area === 'overview')
            <x-filament::section heading="Server">
                @if (($runtime['source'] ?? '') === 'configured')<p class="fi-section-header-description">Using the Minecraft version and server type from Startup.</p>@endif
                <dl class="imm-summary">
                    <div><dt>{{ $runtime['content_type'] === 'proxy' ? 'Proxy version' : 'Minecraft version' }}</dt><dd>{{ $runtime['version'] === 'unknown' ? __('ibyte-minecraft-manager::messages.unknown') : $runtime['version'] }}</dd></div>
                    <div><dt>Loader / platform</dt><dd>{{ $runtime['loader'] ?: 'Unknown' }}</dd></div>
                    <div><dt>Enabled egg</dt><dd>{{ $profile->name }}</dd></div>
                </dl>
                <div class="imm-row"><x-filament::button wire:click="switchArea('software')">Server software</x-filament::button><x-filament::button color="gray" wire:click="switchArea('packages')">Mods &amp; Plugins</x-filament::button><x-filament::button color="gray" wire:click="switchArea('packs')">Modpacks</x-filament::button></div>
            </x-filament::section>
        @elseif ($area === 'software')
            <x-filament::section heading="Server software" description="Select software, Minecraft version and build. The installed launcher is server.jar.">
                <div class="imm-software-form">{{ $this->softwareForm }}</div>
                <div class="imm-row">
                    @can('minecraft-manager.plan',$server)<x-filament::button wire:click="installSelectedBuild" wire:loading.attr="disabled" :disabled="!$selectedBuild">Install</x-filament::button>@endcan
                    <x-filament::button color="gray" wire:click="browseSoftware">Refresh</x-filament::button>
                    @if ($software)<x-filament::button color="gray" wire:click="softwareVersions({{ $page+1 }})">More versions</x-filament::button>@endif
                    @if ($softwareVersion)<x-filament::button color="gray" wire:click="softwareBuilds({{ $buildPage+1 }})">More builds</x-filament::button>@endif
                </div>
            </x-filament::section>
        @elseif (in_array($area,['packages','packs'],true))
            <x-filament::section :heading="$area === 'packs' ? 'Modpacks' : 'Mods & Plugins'">
                @if ($area === 'packs')<p class="fi-section-header-description">The Minecraft version and loader required by the pack are installed automatically.</p>@endif
                <form wire:submit="search(1)" class="imm-form">{{ $this->catalogForm }}<div><x-filament::button type="submit" wire:loading.attr="disabled">Search</x-filament::button></div></form>
                <div class="imm-row">
                    @if ($gameVersion)<x-filament::button color="gray" size="xs" icon="tabler-x" icon-position="after" wire:click="clearFilter('version')" aria-label="Clear Minecraft version filter">Minecraft {{ $gameVersion }}</x-filament::button>@endif
                    @if ($loaderFilter)<x-filament::button color="gray" size="xs" icon="tabler-x" icon-position="after" wire:click="clearFilter('loader')" aria-label="Clear loader or platform filter">{{ implode(' / ', array_map('ucfirst', \IByte\MinecraftManager\Support\Compatibility::platforms($loaderFilter, $area === 'packs' ? 'modpack' : $packageType))) }}</x-filament::button>@endif
                    @if ($gameVersion || $loaderFilter)<x-filament::button color="gray" size="sm" wire:click="clearFilters">Clear filters</x-filament::button>@endif
                    @if ($area === 'packages' && $runtime['version'] !== 'unknown')<x-filament::button color="gray" size="sm" wire:click="useRuntimeFilters">Use server filters</x-filament::button>@endif
                </div>
            </x-filament::section>
            <div class="imm-row imm-between"><span>{{ number_format($total) }} projects</span><x-filament::badge color="gray">Page {{ $page }}</x-filament::badge></div>
            @php($quickContext = $this->quickContext())
            <div class="imm-catalog-list" wire:key="catalog-results">
                @forelse ($results as $result)
                    <article wire:key="project-{{ $provider }}-{{ $result['id'] }}">
                        <x-filament::section compact class="imm-project">
                            <div class="imm-catalog-copy"><div class="imm-project-heading">
                                @if (!empty($result['icon']))<img class="imm-thumbnail" src="{{ $result['icon'] }}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" x-data="{failed:false}" x-show="!failed" x-on:error="failed=true">@endif
                                <div><h3 class="fi-section-header-heading"><button type="button" wire:click="inspectProject({{ \Illuminate\Support\Js::from($result['id']) }})">{{ $result['title'] }}</button></h3>@if (!empty($result['author']))<p class="fi-section-header-description">{{ $result['author'] }}</p>@endif</div>
                            </div>
                            <p class="imm-description fi-section-header-description">{{ $result['description'] }}</p>
                            <div class="imm-row"><x-filament::badge color="gray">{{ \Illuminate\Support\Number::abbreviate($result['downloads']??0,1) }} downloads</x-filament::badge>@if (!empty($result['updated']))<span class="fi-section-header-description">Updated {{ substr($result['updated'],0,10) }}</span>@endif</div>
                            </div>
                            <livewire:imm-project-install :server-id="$server->id" :server-uuid="$server->uuid" :provider="$provider" :project="$result['id']" :context="$quickContext" :client-only="($result['environment'] ?? '') === 'unsupported'" :key="'quick-'.$provider.'-'.$result['id'].'-'.hash('sha256',json_encode($quickContext))" lazy />
                        </x-filament::section>
                    </article>
                @empty <p>No projects found.</p> @endforelse
            </div>
            <div class="imm-row imm-between"><x-filament::button color="gray" wire:click="search({{ max(1,$page-1) }})" :disabled="$page<=1">Previous</x-filament::button><span>Page {{ $page }}</span><x-filament::button color="gray" wire:click="search({{ $page+1 }})" :disabled="$page*20 >= $total">Next</x-filament::button></div>
            @if ($area === 'packages')<x-filament::section heading="Installed files" description="Read-only scan of the selected mods or plugins directory." collapsible collapsed>@can('file.read',$server)<x-filament::button color="gray" wire:click="scan">Rescan files</x-filament::button>@endcan @foreach ($inventory as $file)<p>{{ $file['name'] }} · {{ number_format($file['size']) }} bytes</p>@endforeach</x-filament::section>@endif
        @endif
        @if ($projectOpen && $project)
            @php($selectedProject = collect($results)->firstWhere('id',$project))
            <x-filament::modal id="imm-project" class="imm-project-modal" width="2xl" :heading="$selectedProject['title']??$project" x-init="$nextTick(() => open())" x-on:modal-closed.stop="$wire.closeProject()">
                <div class="imm-form">
                    @if ($error)<p role="alert">{{ __('ibyte-minecraft-manager::messages.errors.'.$error) }}</p>@endif
                    <p>{{ $selectedProject['description']??'' }}</p>
                    <label>Release<x-filament::input.wrapper><x-filament::input.select wire:model.live="selectedRelease"><option value="">Select release</option>@foreach ($releases as $release)<option value="{{ $release['id'] }}">{{ $release['title'] }} · {{ $release['channel'] }}</option>@endforeach</x-filament::input.select></x-filament::input.wrapper></label>
                    @if (!$releases)<p>No releases match the filters.</p>@endif
                    <div class="imm-fields"><label>Minecraft version<x-filament::input.wrapper><x-filament::input wire:model.live.debounce.350ms="installVersion" maxlength="128" placeholder="All versions" /></x-filament::input.wrapper></label><label>Loader / platform<x-filament::input.wrapper><x-filament::input wire:model.live.debounce.350ms="installLoader" maxlength="128" placeholder="All loaders / platforms" /></x-filament::input.wrapper></label></div>
                    @if ($releasePage > 1 || $releaseHasMore)<div class="imm-row imm-between"><x-filament::button color="gray" wire:click="moreReleases({{ max(1,$releasePage-1) }})" :disabled="$releasePage<=1">Previous</x-filament::button><span class="fi-section-header-description">Page {{ $releasePage }}</span><x-filament::button color="gray" wire:click="moreReleases({{ $releasePage+1 }})" :disabled="!$releaseHasMore">Next</x-filament::button></div>@endif
                    <div class="imm-row">@can('minecraft-manager.plan',$server)<x-filament::button wire:click="installSelectedRelease" wire:loading.attr="disabled" :disabled="!$selectedRelease">Install</x-filament::button>@if ($area === 'packages')<x-filament::button color="gray" wire:click="addSelectedRelease" wire:loading.attr="disabled" :disabled="!$selectedRelease">Add to queue</x-filament::button>@endif @endcan</div>
                </div>
            </x-filament::modal>
        @endif

    </div>
</x-filament-panels::page>
