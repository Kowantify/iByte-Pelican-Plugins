<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use App\Models\Server;
use App\Repositories\Daemon\DaemonFileRepository;
use App\Repositories\Daemon\DaemonServerRepository;
use GuzzleHttp\Psr7\Utils;
use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\Input;
use IByte\MinecraftManager\Support\ArtifactDownloader;
use IByte\MinecraftManager\Support\UrlPolicy;

class NodeFiles
{
    private array $directories = [];
    private ?array $creationListings = null;
    public function __construct(protected Server $server) {}

    protected function files(): DaemonFileRepository { return app(DaemonFileRepository::class)->setServer($this->server); }

    public function assertStopped(): void
    {
        $fresh = $this->server->fresh();
        if (!$fresh || $fresh->uuid !== $this->server->uuid || $fresh->node_id !== $this->server->node_id || $fresh->status !== null || $fresh->transfer) {
            throw new Failure('server_state_changed');
        }
        $state = app(DaemonServerRepository::class)->setServer($fresh)->getDetails(5)['state'] ?? 'unknown';
        if ($state !== 'offline') { throw new Failure($state === 'missing' ? 'node_unavailable' : 'server_must_be_stopped'); }
    }

    public function mkdir(string $path): void
    {
        $root = '/';
        foreach (explode('/', Input::nodePath($path)) as $part) {
            $target = ltrim(rtrim($root, '/').'/'.$part, '/');
            if (isset($this->directories[$target])) { $root = '/'.$target; continue; }
            $entries = $this->creationListings === null ? $this->files()->getDirectory($root)
                : ($this->creationListings[$root] ??= $this->files()->getDirectory($root));
            $entry = collect($entries)->firstWhere('name', $part);
            // Repository listings are raw Wings Stat JSON, not Panel File models.
            if ($entry && (!($entry['directory'] ?? false) || ($entry['file'] ?? true) || ($entry['symlink'] ?? false))) {
                throw new Failure('node_path_collision', ['file' => rtrim($root, '/').'/'.$part]);
            }
            if (!$entry) { $this->files()->createDirectory($part, $root)->throw(); }
            if ($this->creationListings !== null) { $this->creationListings[$root][] = ['name'=>$part,'directory'=>true,'file'=>false,'symlink'=>false]; }
            $this->directories[$target] = true;
            $root = rtrim($root, '/') . '/' . $part;
        }
    }

    /** Share sibling listings only within this directory-creation phase. */
    public function mkdirMany(array $paths): void
    {
        $this->creationListings = [];
        try { foreach ($paths as $path) { $this->mkdir($path); } }
        finally { $this->creationListings = null; }
    }

    /** Wings owns every payload download. Only this operation's identifiers are cancelled. */
    public function pullMany(array $downloads, callable $progress): void
    {
        $pending = $downloads; $active = []; $done = 0; $total = count($downloads);
        $deadline = microtime(true) + 1200; $lastChange = microtime(true); $previous = null;
        try {
            while ($pending || $active) {
                if (microtime(true) > $deadline || microtime(true) - $lastChange > 300) { throw new Failure('artifact_download_failed'); }
                $running = $this->files()->getHttpClient()->get('/api/servers/'.$this->server->uuid.'/files/pull')->throw()->json('downloads') ?? [];
                $states = [];
                foreach ($running as $state) { $states[$state['Identifier']] = max(0, min(1, (float) $state['Progress'])); }
                foreach ($active as $id => $item) {
                    if (!array_key_exists($id, $states)) {
                        // Disappearance alone also means failure in Wings. Verify size now;
                        // publisher checksums are checked before the file can be promoted.
                        $entry = collect($this->files()->getDirectory('/'.dirname($item['path'])))->firstWhere('name', basename($item['path']));
                        if (!$entry || !($entry['file'] ?? false) || ($entry['symlink'] ?? false)
                            || isset($item['size']) && (int) $entry['size'] !== $item['size']) {
                            throw new Failure('artifact_download_failed', ['file'=>$item['name'] ?? basename($item['path'])]);
                        }
                        unset($active[$id]); ++$done; $lastChange = microtime(true);
                    }
                }
                while ($pending && count($active) < 3 && count($states) < 3) {
                    $item = reset($pending);
                    UrlPolicy::host($item['url'], ArtifactDownloader::HOSTS);
                    Input::nodePath($item['path']); if (dirname($item['path']) !== '.') { $this->mkdir(dirname($item['path'])); }
                    $response = $this->files()->pull($item['url'], '/'.dirname($item['path']), ['filename'=>basename($item['path']), 'foreground'=>false]);
                    if ($response->status() === 400 && str_contains($response->body(), '3 simultaneous')) { break; }
                    $id = $response->throw()->json('identifier');
                    if (!is_string($id) || !preg_match('/\A[0-9a-f-]{36}\z/D', $id)) { throw new Failure('node_unavailable'); }
                    array_shift($pending); $active[$id] = $item; $states[$id] = 0; $lastChange = microtime(true);
                }
                $fractions = 0; $names = [];
                foreach ($active as $id => $item) { $fractions += $states[$id] ?? 0; $names[] = $item['name'] ?? basename($item['path']); }
                $state = ['phase'=>'download', 'files'=>$done, 'total'=>$total, 'fraction'=>($done+$fractions)/max(1,$total), 'file'=>implode(', ', $names)];
                $signature = json_encode([$done, $states]);
                if ($signature !== $previous) { $lastChange = microtime(true); $previous = $signature; }
                $progress($state);
                if ($pending || $active) { usleep(250000); }
            }
        } finally {
            foreach ($active as $id => $item) {
                try { $this->files()->getHttpClient()->delete('/api/servers/'.$this->server->uuid.'/files/pull/'.$id)->throw(); } catch (\Throwable $error) { report($error); }
            }
        }
    }

    /** One bounded read verifies the publisher hash and supplies our SHA-256 journal. */
    public function verifiedRead(string $path, ?int $size, array $hashes = [], ?string $destination = null): array
    {
        Input::nodePath($path); $algorithm = null;
        foreach (['sha512'=>128, 'sha256'=>64, 'sha1'=>40] as $name=>$length) {
            if (!isset($hashes[$name])) { continue; }
            if (!is_string($hashes[$name]) || !preg_match('/\A[0-9a-f]{'.$length.'}\z/Di', $hashes[$name])) { throw new Failure('invalid_hash'); }
            $algorithm = $name; break;
        }
        if ($hashes && !$algorithm) { throw new Failure('weak_integrity_policy'); }
        if ($size !== null && ($size < 1 || $size > 536870912)) { throw new Failure('artifact_size_limit'); }
        $response = $this->files()->getHttpClient()->timeout(300)->withOptions(['stream'=>true])
            ->get('/api/servers/'.$this->server->uuid.'/files/contents', ['file'=>'/'.$path, 'download'=>'1'])->throw();
        $body = $response->toPsrResponse()->getBody(); $sha = hash_init('sha256'); $source = $algorithm ? hash_init($algorithm) : null; $bytes = 0;
        $write = $destination !== null ? fopen($destination, 'wb') : null;
        if ($write === false) { $body->close(); throw new Failure('staging_unwritable'); }
        try {
            while (!$body->eof()) {
                $chunk = $body->read(65536); $bytes += strlen($chunk);
                if ($bytes > ($size ?? 536870912)) { throw new Failure('artifact_size_limit'); }
                hash_update($sha, $chunk); if ($source) { hash_update($source, $chunk); }
                if ($write && fwrite($write, $chunk) !== strlen($chunk)) { throw new Failure('staging_unwritable'); }
            }
        } finally { $body->close(); if (is_resource($write)) { fclose($write); } }
        if ($size !== null && $bytes !== $size || $response->header('Content-Length') !== '' && (int) $response->header('Content-Length') !== $bytes) { throw new Failure('size_mismatch'); }
        if ($source && !hash_equals(strtolower($hashes[$algorithm]), hash_final($source))) { throw new Failure('hash_mismatch'); }
        return ['size'=>$bytes, 'sha256'=>hash_final($sha)];
    }

    public function extract(string $archive, string $directory): void
    {
        if ($directory === '.') {
            Input::nodePath($archive);
            $this->files()->decompressFile('/', $archive)->throw();
            return;
        }
        Input::nodePath($directory); $this->mkdir($directory);
        $name = '.imm-'.bin2hex(random_bytes(16)).'.zip';
        $target = $directory.'/'.$name; $this->move($archive, $target);
        $this->files()->decompressFile('/'.$directory, $name)->throw();
        $this->remove($target);
    }

    public function exists(string $path): bool
    {
        Input::nodePath($path);
        try { return collect($this->files()->getDirectory('/' . (dirname($path) === '.' ? '' : dirname($path))))->contains('name', basename($path)); }
        catch (\Illuminate\Http\Client\RequestException $error) { if ($error->response->status() === 404) { return false; } throw $error; }
    }

    /** Snapshot metadata once per parent; never cache bytes or checksum results. */
    public function entries(array $paths): array
    {
        $wanted = []; $result = []; $requested=array_fill_keys($paths,true); $missing=[];
        foreach ($paths as $path) {
            Input::nodePath($path);
            for ($target=$path; $target!=='.'; $target=dirname($target)) { $wanted[dirname($target)][basename($target)]=$target; }
        }
        uksort($wanted,static fn($a,$b)=>(($a==='.'?-1:substr_count($a,'/'))<=>($b==='.'?-1:substr_count($b,'/'))));
        foreach ($wanted as $parent=>$names) {
            if (isset($missing[$parent])) { foreach ($names as $path) { $missing[$path]=true; } continue; }
            try { $rows = $this->files()->getDirectory('/'.($parent === '.' ? '' : $parent)); }
            catch (\Illuminate\Http\Client\RequestException $error) { if ($error->response->status() === 404) { continue; } throw $error; }
            foreach ($rows as $row) {
                if (!is_array($row) || !isset($row['name']) || !is_string($row['name'])) { throw new Failure('node_unavailable'); }
                if (isset($names[$row['name']])) {
                    $path=$names[$row['name']];
                    if (isset($wanted[$path]) && (!($row['directory']??false) || ($row['symlink']??false))) { throw new Failure('node_path_collision',['file'=>$path]); }
                    if (isset($requested[$path])) { $result[$path]=$row; }
                    unset($names[$row['name']]);
                }
            }
            foreach ($names as $path) { $missing[$path]=true; }
        }
        return $result;
    }

    public function hashOrNull(string $path): ?string
    {
        try { return $this->hash($path); }
        catch (\Illuminate\Http\Client\RequestException $error) { if ($error->response->status() === 404) { return null; } throw $error; }
    }

    public function upload(string $path, string $local): void
    {
        Input::nodePath($path);
        if (dirname($path) !== '.') { $this->mkdir(dirname($path)); }
        $handle = fopen($local, 'rb');
        if ($handle === false) { throw new Failure('staging_unwritable'); }
        try {
            $this->files()->getHttpClient()->timeout(300)->withQueryParameters(['file' => '/' . $path])
                ->withBody(Utils::streamFor($handle), 'application/octet-stream')
                ->post('/api/servers/' . $this->server->uuid . '/files/write')->throw();
        } finally { if (is_resource($handle)) { fclose($handle); } }
    }

    public function assertRegular(string $path): void
    {
        Input::nodePath($path);
        if (dirname($path) !== '.') { $this->mkdir(dirname($path)); }
        $entry = collect($this->files()->getDirectory('/'.(dirname($path) === '.' ? '' : dirname($path))))->firstWhere('name', basename($path));
        if (!$entry || !($entry['file'] ?? false) || ($entry['symlink'] ?? false)) { throw new Failure('node_path_collision', ['file'=>$path]); }
    }

    public function removeEmptyDirectory(string $path): void
    {
        if (!$this->exists($path)) { return; }
        $entry = collect($this->files()->getDirectory('/'.(dirname($path) === '.' ? '' : dirname($path))))->firstWhere('name', basename($path));
        if (!$entry || !($entry['directory'] ?? false) || ($entry['symlink'] ?? false)) { return; }
        if ($this->files()->getDirectory('/'.$path) === []) { $this->remove($path); unset($this->directories[$path]); }
    }

    public function pruneEmptyTree(string $path, int $depth = 0): void
    {
        if ($depth > 32 || !$this->exists($path)) { return; }
        $entry = collect($this->files()->getDirectory('/'.(dirname($path) === '.' ? '' : dirname($path))))->firstWhere('name', basename($path));
        if (!$entry || !($entry['directory'] ?? false) || ($entry['symlink'] ?? false)) { return; }
        foreach ($this->files()->getDirectory('/'.$path) as $child) {
            if (($child['directory'] ?? false) && !($child['symlink'] ?? false)) { $this->pruneEmptyTree($path.'/'.$child['name'], $depth+1); }
        }
        $this->removeEmptyDirectory($path);
    }

    public function hash(string $path, int $limit = 536870912): string
    {
        Input::nodePath($path);
        $response = $this->files()->getHttpClient()->timeout(300)->withOptions(['stream' => true])
            ->get('/api/servers/' . $this->server->uuid . '/files/contents', ['file' => '/'.$path, 'download' => '1'])->throw();
        $body = $response->toPsrResponse()->getBody(); $hash = hash_init('sha256'); $bytes = 0;
        try {
            while (!$body->eof()) {
                $chunk = $body->read(65536); $bytes += strlen($chunk);
                if ($bytes > $limit) { throw new Failure('artifact_size_limit'); }
                hash_update($hash, $chunk);
            }
            $length = $response->header('Content-Length');
            if ($length !== '' && $bytes !== (int) $length) { throw new Failure('size_mismatch'); }
        } finally { $body->close(); }
        return hash_final($hash);
    }

    public function text(string $path, int $limit = 1048576): string
    {
        if (!$this->exists($path)) { return ''; }
        $response = $this->files()->getHttpClient()->timeout(20)->withOptions(['stream' => true])
            ->get('/api/servers/'.$this->server->uuid.'/files/contents', ['file' => '/'.Input::nodePath($path)])->throw();
        $body = $response->toPsrResponse()->getBody();
        try { $text = $body->read($limit + 1); if (strlen($text) > $limit) { throw new Failure('artifact_size_limit'); } return $text; }
        finally { $body->close(); }
    }

    public function move(string $from, string $to): void
    {
        Input::nodePath($from); Input::nodePath($to);
        if (dirname($to) !== '.') { $this->mkdir(dirname($to)); }
        $this->files()->renameFiles('/', [['from' => $from, 'to' => $to]])->throw();
    }

    /** Native Wings accepts independent renames in one request. Never chain moves. */
    public function moveMany(array $moves): void
    {
        foreach (array_chunk($moves,100) as $chunk) {
            $targets=[];
            foreach ($chunk as $move) { Input::nodePath($move['from']); Input::nodePath($move['to']); $targets[]=dirname($move['to']); }
            $this->mkdirMany(array_values(array_filter(array_unique($targets),static fn($path)=>$path!=='.')));
            $this->files()->renameFiles('/',$chunk)->throw();
        }
    }

    public function removeMany(array $paths): void
    {
        foreach (array_chunk($paths,100) as $chunk) { foreach ($chunk as $path) { Input::nodePath($path); } $this->files()->deleteFiles('/',$chunk)->throw(); }
    }

    public function remove(string $path): void { $this->files()->deleteFiles('/', [Input::nodePath($path)])->throw(); }
}
