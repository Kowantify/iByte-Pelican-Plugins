<div wire:poll.2s="refreshProgress">
    @php
        $operation = $operations->first(fn($item) => $item->server_slot !== null) ?? $operations->first(fn($item) => $item->status !== 'planned');
        $active = $operation && !in_array($operation->status, ['planned','succeeded','failed','blocked','cancelled','rolled-back'], true);
    @endphp
    @if ($error)<p role="alert">{{ __('ibyte-minecraft-manager::messages.errors.'.$error) }}</p>@endif
    @if ($operation && $operation->status !== 'planned')
        <x-filament::section compact>
            <div class="imm-form" wire:key="install-progress-{{ $operation->id }}" role="status" aria-live="polite" aria-atomic="true">
                <div class="imm-row imm-between">
                    <strong>{{ $operation->plan['release']['title'] ?? 'Installation' }}</strong>
                    <x-filament::badge :color="$operation->status === 'succeeded' ? 'success' : ($operation->error_code ? 'danger' : 'primary')">{{ __('ibyte-minecraft-manager::messages.statuses.'.$operation->status) }}</x-filament::badge>
                </div>
                @php
                    $state = $operation->plan['progress'] ?? [];
                    $phase = $state['phase'] ?? '';
                    $known = $active && isset($state['total']) && $state['total'] > 0;
                    $fraction = $known ? max(0, min(1, $phase === 'download' ? ($state['fraction'] ?? $state['files']/$state['total']) : $state['files']/$state['total'])) : null;
                    $label = ['resolve'=>'Resolving mod files','download'=>'Downloading','verify'=>'Verifying files','apply'=>'Installing files','result'=>'Checking installation','cleanup'=>'Finishing installation'][$phase] ?? 'Preparing installation';
                @endphp
                @if ($active)
                    @if ($operation->status === 'queued')<p class="fi-section-header-description">Waiting for the install worker. Downloads will run on the server node.</p>
                    @elseif ($operation->status === 'rolling-back')<p>Restoring the previous files.</p>
                    @else
                        <div class="imm-row imm-between"><span>{{ $label }}</span>@if($known)<span>{{ number_format($fraction*100) }}% &middot; {{ $state['files'] }} / {{ $state['total'] }} files</span>@endif</div>
                    @endif
                    <progress class="imm-progress" max="1" @if($known)value="{{ $fraction }}"@endif aria-label="{{ $label }}"></progress>
                    @if(!empty($state['file']))<p class="fi-section-header-description imm-progress-file">{{ $state['file'] }}</p>@endif
                    @if ($operation->status === 'queued' && $operation->updated_at->lt(now()->subMinutes(2)))<p role="alert">{{ __('ibyte-minecraft-manager::messages.queue_delayed') }}</p>@endif
                @elseif ($operation->step === 'installed')
                    <p>Installed. Start the server when ready.</p>
                @endif
                @if ($operation->error_code)<p role="alert">{{ __('ibyte-minecraft-manager::messages.errors.'.$operation->error_code) }}</p>@endif
                @foreach ($operation->plan['failure'] ?? [] as $detail)<p>{{ $detail }}</p>@endforeach
                @if ($operation->actor_id === auth()->id() && $operation->status === 'queued')<div><x-filament::button color="gray" size="sm" wire:click="cancelReview('{{ $operation->id }}')">Cancel install</x-filament::button></div>@endif
                @if ($operation->error_code && !$operation->acknowledged_at && $operation->actor_id === auth()->id())<div><x-filament::button color="gray" size="sm" wire:click="acknowledge('{{ $operation->id }}')">Acknowledge</x-filament::button></div>@endif
            </div>
            <details class="imm-install-history"><summary class="fi-section-header-description">Recent installations</summary><div class="imm-form">
                @foreach ($operations->where('status','!=','planned')->take(10) as $previous)
                    <div wire:key="history-{{ $previous->id }}"><p>{{ $previous->plan['release']['title'] ?? $previous->kind }} &middot; {{ __('ibyte-minecraft-manager::messages.statuses.'.$previous->status) }}</p><p class="fi-section-header-description">{{ $previous->created_at->diffForHumans() }}</p>@if($previous->error_code)<p>{{ __('ibyte-minecraft-manager::messages.errors.'.$previous->error_code) }}</p>@endif</div>
                @endforeach
            </div></details>
        </x-filament::section>
    @endif
</div>
