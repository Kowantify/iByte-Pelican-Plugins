<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Catalog;

interface JsonTransport
{
    public function get(string $provider, string $path, array $query = []): array;
}
