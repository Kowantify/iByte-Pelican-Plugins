# iByte Minecraft Manager 0.1.0-preview.24

Install Minecraft server software, mods, plugins and supported modpacks through Pelican Panel and stock Wings.

Import the ZIP through Admin > Plugins and install/update it. Configure enabled providers and egg access in Minecraft Manager settings. Store the CurseForge API key in its private settings field. No Wings changes are required.

Before installation, the native Panel dialog recommends taking a backup. Backups are advisory: the plugin does not automatically create one, require one or restore one. Failed and cancelled installations keep partial files and startup changes, release their installation slot and allow another installation. Restore a native backup yourself when needed. Older blocked operations can be dismissed without restoring their files. Historical recovery copies from previous versions are not automatically deleted.

Downloads go directly from the provider to Wings. Completion-aware foreground pulls run through a moving window of at most three requests, with no fixed polling sleep between completed downloads. Current requests settle before a cancellation/failure stops subsequent work. A current transfer may take time to finish; its timeout is bounded.

Wings extracts archives into temporary operation-owned directories and performs native file moves. The Panel reads only bounded pack manifest/index JSON and filesystem metadata; it does not routinely read JARs, archive bodies, old file copies or final file contents. Temporary extraction directories may be visible while an install runs and are removed afterward. No persistent .minecraft-manager directory is created. Metadata traversal still costs API requests for large archive trees.

Completion and expected sizes are checked. Published provider hashes are stored as expected metadata, not presented as measured file checksums. There is no initial/final full-file checksum pass, no automatic rollback and no downloaded JAR inspection. Client compatibility uses provider/manifest metadata. Native Wings handles archive extraction and its own sandbox/disk checks; the former Panel-side ZIP central-directory inspection is removed.

Existing configuration files and worlds are preserved. Tracked old mod/runtime files may be replaced or retired by inventory ownership; content modifications are no longer detected by hashing. Untracked files are not blanket-deleted. Pack manifests select the exact Minecraft/loader runtime, approved Java image, server.jar launcher and existing egg variables. Permission, source-identity, path, provider URL, size and stopped-server checks remain enabled.

The catalog has Install, Add to queue and View controls. View supports Minecraft/loader filtering and shows release channels and complete supported versions/platforms. The inline install status includes stage counts and elapsed/phase timings. The backup reminder also applies when installing the queue.

Validation for preview.24 is intentionally limited at the user's request: native ZIP import/install with optional asset build stubbed, plus nine deterministic native Panel/Livewire/HTTP-contract smoke checks covering a mod, a small Modrinth pack/runtime, manifest-only Panel reads, config/world preservation, failure, cancellation, temporary cleanup, worker-failure inventory cleanup, late callback protection and the backup reminder. No fresh browser, live provider, concurrency benchmark, Linux Wings or game boot was performed. This is a preview; broad acceptance testing is deferred.
Preview.24 removes eight unused classes and obsolete local download, archive inspection and checksum helpers. Installation uses one required Wings path. Shared failure cleanup preserves unrelated inventory and ignores callbacks for settled operations. Historical job names, schema and blocked-operation dismissal remain compatible.
