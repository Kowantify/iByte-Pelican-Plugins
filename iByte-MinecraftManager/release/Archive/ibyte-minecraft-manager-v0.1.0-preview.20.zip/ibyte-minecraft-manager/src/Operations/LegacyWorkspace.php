<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use App\Models\Server;
use IByte\MinecraftManager\Models\Operation;
use Throwable;

final class LegacyWorkspace
{
    /** Move only verified, recorded old backups. Never blanket-delete server files. */
    public function migrate(NodeFiles $node, Server $server): void
    {
        if (!$node->exists('.minecraft-manager')) { return; }
        $operations = Operation::where('server_id', $server->id)->where('server_uuid', $server->uuid)
            ->where('node_id', $server->node_id)->whereNull('server_slot')->whereIn('status', ['succeeded', 'failed', 'cancelled', 'blocked'])->cursor();
        foreach ($operations as $op) {
            if (($op->plan['filesystem_format'] ?? null) === 2) { continue; }
            $plan = $op->plan;
            foreach ($plan['journal'] ?? [] as $path=>$item) {
                $expected = '.minecraft-manager/backups/'.$op->id.'/'.$path;
                if (($item['backup'] ?? '') !== $expected || empty($item['old']) || !$node->exists($expected)) { continue; }
                try {
                    $node->assertStopped(); $node->assertRegular($expected);
                    $directory = (new InstallWorkspace($node, $op))->directory();
                    if (!is_dir($directory) && !mkdir($directory, 0700, true)) { throw new \RuntimeException('Cannot save legacy recovery copy'); }
                    $name = hash('sha256', $path).'.bin';
                    $node->verifiedRead($expected, null, ['sha256'=>$item['old']], $directory.'/'.$name.'.pending');
                    if (!rename($directory.'/'.$name.'.pending', $directory.'/'.$name)) { throw new \RuntimeException('Cannot commit legacy recovery copy'); }
                    chmod($directory.'/'.$name, 0600);
                    $plan['journal'][$path]['backup_disk'] = $name;
                    $plan['legacy_backups_on_panel'] = true;
                    $op->update(['plan'=>$plan]);
                    // Metadata and verified private bytes exist before the node copy is removed.
                    if ($node->hash($expected) !== $item['old']) { throw new \RuntimeException('Legacy recovery file changed during export'); }
                    $node->remove($expected);
                } catch (Throwable $error) { report($error); }
            }
        }
        $node->pruneEmptyTree('.minecraft-manager');
    }
}
