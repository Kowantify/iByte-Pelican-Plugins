<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Operations;

use IByte\MinecraftManager\Modpacks\ArchiveExtractor;
use IByte\MinecraftManager\Modpacks\ArchiveInspector;
use IByte\MinecraftManager\Support\Failure;
use IByte\MinecraftManager\Support\PluginJava;

/** Native pulls use temporary files beside their final destination, never a work folder. */
final class NodePreparation
{
    private array $sources = [];
    private array $archives = [];

    public function __construct(private NodeFiles $node, private InstallWorkspace $workspace, private \Closure $progress) {}

    public function fetch(array $artifact, string $local): array
    {
        $remote = $this->workspace->temporary('download.zip', 'zip');
        $this->node->pullMany([['path'=>$remote, ...$artifact]], $this->progress);
        $result = $this->node->verifiedRead($remote, $artifact['size'] ?? null, $artifact['hashes'] ?? [], $local);
        $this->workspace->reserve([$remote=>$result['sha256']]);
        $this->sources[$local] = ['remote'=>$remote];
        return $result;
    }

    public function extract(string $archive, string $destination): array
    {
        // Resolve all paths/layers locally before any archive entry touches the server.
        $files = (new ArchiveExtractor)->extract($archive, $destination);
        foreach ((new ArchiveInspector)->inspect($archive) as $entry) {
            if (explode('/', $entry['name'])[0] === '.minecraft-manager') { throw new Failure('unsafe_path'); }
            foreach (explode('/', $entry['name']) as $part) { if (str_starts_with($part, '.download-')) { throw new Failure('unsafe_path'); } }
        }
        $this->archives[$archive] = $files;
        foreach ($files as $path=>$local) { $this->sources[$local] = ['archive'=>$archive, 'entry'=>$path]; }
        return $files;
    }

    private function expand(string $archive, array $selected, bool $runtime = false): array
    {
        $source = $this->sources[$archive] ?? throw new Failure('staging_unwritable');
        if (!isset($source['remote'])) {
            $parent = $this->expand($source['archive'], [$source['entry']=>'download.zip']);
            $source = ['remote'=>$parent[$source['entry']]];
        }
        $directories = array_column(array_filter((new ArchiveInspector)->inspect($archive), static fn ($entry) => $entry['directory']), 'name');
        if ($runtime) { return $this->workspace->expandRuntime($source['remote'], $this->archives[$archive], $selected, $directories); }
        return $this->workspace->expand($source['remote'], $this->archives[$archive], $selected, $directories, $this->progress);
    }

    public function complete(array $files, string $work): array
    {
        if (array_sum(array_column($files, 'size')) > 2147483648) { throw new Failure('pack_size_limit'); }
        $downloads = []; $selected = [];
        foreach ($files as $path=>&$file) {
            if (!isset($file['artifact'])) {
                $source = $this->sources[$file['local']] ?? throw new Failure('staging_unwritable');
                if (isset($source['archive'])) { $selected[$source['archive']][$source['entry']] = $path; }
                else { $file['remote'] = $source['remote']; }
                continue;
            }
            $file['remote'] = $this->workspace->temporary($path, 'part', false);
            $downloads[] = ['path'=>$file['remote'], ...$file['artifact']];
        }
        unset($file);
        if (count($downloads) > 2000) { throw new Failure('dependency_limit'); }
        $this->workspace->save();
        $this->workspace->parents(array_column($downloads, 'path'));
        $this->workspace->checkTemporaryPaths(array_column($downloads, 'path'));
        foreach ($selected as $archive=>$entries) {
            ($this->progress)(['phase'=>'verify', 'files'=>0, 'total'=>count($entries), 'file'=>'']);
            $runtime = true;
            foreach ($entries as $entry=>$path) {
                if ($entry!==$path || ($files[$path]['owner']['kind']??'')!=='software') { $runtime=false; break; }
            }
            $expanded = $this->expand($archive, $entries, $runtime);
            foreach ($entries as $entry=>$path) {
                $files[$path]['remote'] = $expanded[$entry];
                $files[$path]['applied'] = $runtime;
            }
        }
        if ($downloads) { $this->node->pullMany($downloads, $this->progress); }
        $total = count($files); $done = 0; $verifiedWrites = [];
        foreach ($files as $path=>&$file) {
            ++$done;
            if (!isset($file['artifact'])) { continue; }
            ($this->progress)(['phase'=>'verify', 'files'=>$done-1, 'total'=>$total, 'file'=>$path]);
            $local = !empty($file['inspect_client']) || isset($file['plugin_platform']) ? $work.'/inspect.jar' : null;
            $verified = $this->node->verifiedRead($file['remote'], $file['size'], $file['artifact']['hashes'] ?? [], $local);
            $file['sha256'] = $verified['sha256'];
            $verifiedWrites[$file['remote']] = $file['sha256'];
            if (isset($file['plugin_platform'])) {
                try { (new PluginJava)->check($local, $file['plugin_platform'], $file['java']); }
                catch (Failure $error) { throw new Failure($error->reason, ['file'=>$path, ...$error->context]); }
            }
            if ($local) {
                $jar = new \ZipArchive;
                if (!empty($file['inspect_client']) && $jar->open($local, \ZipArchive::RDONLY) === true) {
                    $entry = $jar->statName('fabric.mod.json');
                    $metadata = $entry && $entry['size'] <= 1048576 ? json_decode($jar->getFromName('fabric.mod.json'), true) : null;
                    $jar->close();
                    if (($metadata['environment'] ?? null) === 'client') { unset($files[$path]); }
                }
                unlink($local);
            }
        }
        unset($file);
        $this->workspace->reserve($verifiedWrites);
        return $files;
    }
}
