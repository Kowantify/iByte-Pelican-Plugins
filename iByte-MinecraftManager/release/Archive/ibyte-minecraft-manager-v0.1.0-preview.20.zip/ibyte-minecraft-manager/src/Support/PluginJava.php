<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Support;

use Symfony\Component\Yaml\Yaml;
use Symfony\Component\Yaml\Exception\ParseException;

/** Read declared entry-point headers; never execute a downloaded plugin. */
final class PluginJava
{
    public function check(string $file, string $platform, ?int $current): ?int
    {
        $platform = strtolower($platform);
        $descriptors = match ($platform) {
            'paper', 'purpur', 'folia' => ['paper-plugin.yml', 'plugin.yml'],
            'bukkit', 'craftbukkit', 'spigot' => ['plugin.yml'],
            'bungeecord', 'waterfall' => ['bungee.yml', 'plugin.yml'],
            'velocity' => ['velocity-plugin.json'],
            default => [],
        };
        if (!$descriptors) { return null; }
        $zip = new \ZipArchive;
        if ($zip->open($file, \ZipArchive::RDONLY) !== true) { throw new Failure('invalid_plugin_descriptor'); }
        try {
            if ($zip->numFiles > 100000) { throw new Failure('artifact_size_limit'); }
            $descriptor = null;
            foreach ($descriptors as $name) { if ($zip->locateName($name) !== false) { $descriptor = $name; break; } }
            if (!$descriptor) { throw new Failure('invalid_plugin_descriptor'); }
            $stat = $zip->statName($descriptor);
            if (!$stat || $stat['size'] > 1048576 || !in_array($stat['comp_method'], [0,8], true)) { throw new Failure('invalid_plugin_descriptor'); }
            $bytes = $zip->getFromName($descriptor);
            if (!is_string($bytes)) { throw new Failure('invalid_plugin_descriptor'); }
            $metadata = str_ends_with($descriptor, '.json') ? json_decode($bytes, true, 32, JSON_THROW_ON_ERROR) : Yaml::parse($bytes);
            if (!is_array($metadata) || !is_string($metadata['main'] ?? null)) { throw new Failure('invalid_plugin_descriptor'); }
            if ($platform === 'folia' && ($metadata['folia-supported'] ?? false) !== true) { throw new Failure('plugin_platform_incompatible'); }
            $manifest = $zip->getFromName('META-INF/MANIFEST.MF', 65536);
            $mainSection = preg_split('/\r?\n\r?\n/', preg_replace('/\r?\n /', '', is_string($manifest) ? $manifest : ''))[0];
            $multi = (bool) preg_match('/^Multi-Release:\s*true\s*$/im', $mainSection);
            $required = 1;
            foreach ($descriptor === 'paper-plugin.yml' ? ['main', 'bootstrapper', 'loader'] : ['main'] as $key) {
                if (!isset($metadata[$key])) { continue; }
                $class = $metadata[$key];
                if (!is_string($class) || strlen($class) > 512 || !preg_match('/\A(?:[\pL_$][\pL\pN\pM_$]*\.)*[\pL_$][\pL\pN\pM_$]*\z/uD', $class)) { throw new Failure('invalid_plugin_descriptor'); }
                $path = str_replace('.', '/', $class).'.class';
                if ($multi && $current !== null) {
                    for ($version = $current; $version >= 9; --$version) {
                        $candidate = 'META-INF/versions/'.$version.'/'.$path;
                        if ($zip->locateName($candidate) !== false) { $path = $candidate; break; }
                    }
                }
                $stat = $zip->statName($path);
                if (!$stat || !in_array($stat['comp_method'], [0,8], true)) { throw new Failure('invalid_plugin_descriptor'); }
                $header = $zip->getFromName($path, 8);
                if (!is_string($header) || strlen($header) !== 8 || substr($header, 0, 4) !== "\xca\xfe\xba\xbe") { throw new Failure('invalid_plugin_descriptor'); }
                $format = unpack('nminor/nmajor', substr($header, 4));
                if ($format['major'] < 45) { throw new Failure('invalid_plugin_descriptor'); }
                if ($format['major'] >= 56 && $format['minor'] === 65535) { throw new Failure('plugin_java_preview'); }
                $required = max($required, $format['major'] - 44);
            }
            if ($current !== null && $required > $current) {
                throw new Failure('plugin_java_incompatible', ['requirement'=>'Requires Java '.$required.'; the server image uses Java '.$current.'.']);
            }
            return $required;
        } catch (ParseException|\JsonException) { throw new Failure('invalid_plugin_descriptor'); }
        finally { $zip->close(); }
    }
}
