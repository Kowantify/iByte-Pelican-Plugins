<?php

declare(strict_types=1);

namespace IByte\MinecraftManager\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

final class Operation extends Model
{
    protected $table = 'imm_operations';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $guarded = [];
    protected $hidden = ['idempotency', 'digest', 'server_slot'];

    public function scopeForFeed(Builder $query): Builder
    {
        $query->select(['id', 'server_id', 'server_slot', 'actor_id', 'kind', 'provider', 'status', 'step',
            'error_code', 'created_at', 'updated_at', 'acknowledged_at']);
        // The journal is LONGTEXT. PostgreSQL JSON operators require an explicit cast.
        if ($query->getConnection()->getDriverName() === 'pgsql') {
            $query->selectRaw('CAST("selection" AS JSONB) ->> \'intent\' AS feed_intent, CAST("plan" AS JSONB) #>> \'{release,title}\' AS feed_title');
            foreach (['progress', 'failure', 'source_resolutions', 'skipped'] as $key) {
                $query->selectRaw('CAST("plan" AS JSONB) -> \''.$key.'\' AS feed_'.$key);
            }
            return $query;
        }
        return $query->addSelect(['selection->intent as feed_intent', 'plan->release->title as feed_title',
            'plan->progress as feed_progress', 'plan->failure as feed_failure',
            'plan->source_resolutions as feed_source_resolutions', 'plan->skipped as feed_skipped']);
    }

    protected function casts(): array
    {
        return [
            'actor_id' => 'integer', 'server_id' => 'integer', 'node_id' => 'integer', 'server_slot' => 'integer',
            'selection' => 'array', 'plan' => 'array', 'expires_at' => 'immutable_datetime',
            'started_at' => 'immutable_datetime', 'finished_at' => 'immutable_datetime',
            'acknowledged_at' => 'immutable_datetime',
        ];
    }
}
