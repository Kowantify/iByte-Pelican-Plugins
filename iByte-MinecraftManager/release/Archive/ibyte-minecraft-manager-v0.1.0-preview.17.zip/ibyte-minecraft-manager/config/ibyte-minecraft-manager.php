<?php

return [
    'version' => '0.1.0-preview.17',
    'catalog_ttl' => 300,
    'max_json_bytes' => 4 * 1024 * 1024,
    'http_timeout' => 15,
    'max_archive_entries' => 10000,
    'max_expanded_bytes' => 2 * 1024 * 1024 * 1024,
    // Installs use stock Wings streaming, stopped-state checks and retained journals.
];
