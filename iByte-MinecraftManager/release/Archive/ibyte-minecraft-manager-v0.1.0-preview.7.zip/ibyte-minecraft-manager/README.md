# iByte Minecraft Manager 0.1.0-preview.7

Install exact Minecraft server versions, mods, plugins and modpacks through native Pelican Panel and unmodified stock Wings. No Blueprint, node addon or downloaded host executable is required. Pelican itself runs its normal asset build during plugin installation.

## Setup

1. Import the ZIP in Admin → Plugins, install it and wait for Pelican's normal installation queue. Restart existing Panel workers after plugin updates so their loaded PHP classes refresh.
2. As root administrator, open Admin → Minecraft Manager → Settings. Enable the feature and desired sources. Select an installed egg and enable its sidebar entry. No software family, loader, content type, launcher path or image mapping is required. Existing image/software mapping fields from earlier previews are ignored for access and catalog browsing.
3. Enter the CurseForge API key in the private password field. It is encrypted using the Panel application key and never returned to clients. The distributed ZIP contains no API key.
4. Run `php artisan minecraft-manager:work` from the Panel directory as the normal Panel worker user, under your process supervisor. Keep the regular Panel worker running too. Minecraft Manager uses its own queue and a 31-minute reservation, with a 30-minute job timeout. It inherits the configured database or Redis backend; other queue drivers are refused for installs. Stop/restart this worker through your supervisor during upgrades. Setting supervisor stop-wait to at least 1860 seconds allows a running install to finish.
5. Owners have normal access. Subusers need `minecraft-manager.browse`, `minecraft-manager.plan`, and the relevant `minecraft-manager.software`, `.packages` or `.packs` permission. Installs also require native `file.read`, `file.read-content`, `file.create`, `file.update`, `file.delete`; runtime/pack installs additionally require `startup.update`, and `startup.docker-image` when switching images. Reauthorization occurs in the worker and before replacements.

## Install

Stop the server and leave it stopped throughout the operation. Select an exact release in Server Software, Mods & Plugins, or Modpacks. For manually configured servers, choose the target Minecraft version and loader in the release review when the release is ambiguous. Review, choose **Install selected release**, and confirm. Monitor Activity. Success means the prepared files were installed and their node readback hashes matched; it does not mean the game was started. Start it yourself afterward. Accept the Minecraft EULA through the normal server workflow when applicable; the plugin never accepts it automatically.

The optional metadata check does not install files. Create a fresh review if it expires or has already been used. Runtime installs record the selected software/version and select a Java image already allowed by the native installed egg. Runtime startup becomes `java -Xms128M -XX:MaxRAMPercentage=95.0 -jar "<launcher>" nogui`; allocations, resource limits, egg and skip-scripts setting are preserved. The nogui argument is omitted for Velocity/BungeeCord/Waterfall. Custom JVM flags need reapplication afterward. Keep an independent world backup before changing game versions.

## Supported installation paths

- MCJars immutable build recipes containing download, unzip and remove operations. Only prepared Java launchers and runtime libraries are installed; unknown operations/layouts are refused. Live artifact preparation was checked for Vanilla, Paper, Fabric, Forge, NeoForge, Quilt and Velocity. Catalog discovery includes other families, whose recipes are checked individually. No blanket promise for every historic build.
- Modrinth and authorized CurseForge JARs, with required dependencies resolved to compatible exact releases. Optional dependencies are excluded. Modrinth client-only releases are rejected. CurseForge cannot reliably identify all client-only Forge mods; verify the selected project is intended for servers.
- Modrinth mrpack manifests: exact Minecraft/loader selection, required server files, common overrides and server overrides. Client-only and optional server entries are excluded.
- CurseForge manifests: exact required project/file IDs, overrides and exact runtime; when linked, dedicated server-pack content is preferred. Supported content must be at the archive root. Scripts and bundled installer programs are not executed. Fabric jars explicitly marked client-only are excluded during manifest assembly. Some client-oriented Forge packs require a dedicated server pack or operator adjustment before they can start.

Worlds, server.properties, player/operator lists and existing configuration files are preserved. Pack content is limited to mods, plugins, config/defaultconfigs, kubejs, scripts, patchouli_books, global_packs and datapacks. Unchanged obsolete files previously managed by this plugin are retired; arbitrary manual additions remain. Edited managed artifacts block replacement rather than being discarded. Individual installs cannot overwrite a tracked pack-owned filename.

Bounds: 512 MiB per downloaded artifact, 2 GiB total prepared/downloaded content, 10,000 archive entries, 256 MiB per extracted entry, 2,000 downloads and bounded dependency depth. Downloads require approved public HTTPS hosts, validated redirects and provider checksums where supplied. CurseForge SHA-1 is supported. MCJars recipes supply size/HTTPS rather than a publisher checksum; local SHA-256 checks verify transfer integrity, not independent publisher authenticity. The Panel needs free temporary disk space for downloads plus extraction.

## Failure and recovery

The worker uploads into `.minecraft-manager/staging/<operation UUID>/`, hashes staged bytes through Wings' binary content stream, records a durable journal, and moves replaced files into `.minecraft-manager/backups/<operation UUID>/`. Backups remain after success. They consume server disk quota; review and remove old operation directories with native Files only when recovery is no longer needed. Panel temporary files are removed after handled completion.

Handled replacement failures attempt to restore original bytes/startup. A concurrent edit or unreachable node can leave **Needs reconciliation**, retaining the server reservation. Stop the Minecraft Manager worker first. Inspect recovery paths with `php artisan minecraft-manager:reconcile <operation UUID> --inspect`. Preserve any edits, restore the recorded original files from operation backups through native Files/SFTP, remove newly created paths whose old hash is null, and restore the recorded pre-install startup/image. Then run `php artisan minecraft-manager:reconcile <operation UUID> --worker-stopped`. It verifies original file hashes, absence of newly created paths, startup/image, stopped state and original node identity before syncing and releasing the reservation. It never discards concurrent edits. Inspect the operation's retained plan in Panel storage for previous startup details. A hard-killed worker may leave an active phase; reconciliation accepts that phase only after 31 minutes and verification.

Stock Wings does not provide an exclusive lock against native Files, SFTP or power controls. Avoid those actions during installs. Repeated checks and backups reduce risk but do not make an install globally atomic. There is no automatic backup restore, unattended update scheduler, one-click disable/uninstall manager, or provider support beyond MCJars/Modrinth/CurseForge in this release.

## Update, uninstall and evidence

Let installs finish before updating, disabling, uninstalling or rolling back plugin code. Keep the previous ZIP. Native plugin lifecycle retains profiles, encrypted credentials, inventory and operation journals and does not remove game files. Keep the Panel application key safe. Missing tables can be repaired from the admin page; native plugin updates run the journal-column migration.

Test environment: native Pelican canary `a3b415fe4cdb8670ecad782f1d54020f166ab725`, PHP 8.5.11, Laravel 13.35, Filament 5.10.1, Livewire 4.4.7, SQLite/Windows, patched HTTP Foundation 8.1.9. Native lifecycle/permissions/Livewire, deterministic install and recovery contracts, real browser confirmation/queue flow, and live artifact preparation were exercised. The native HTTP transfer test uses a simulated HTTP response and node operations use an in-memory fixture. No live Wings deployment or Linux game/proxy startup was available. This is a functional installer preview, with that remaining deployment validation gap.

## Preview.3 installation fix

The migration no longer depends on plugin namespace autoloading. This fixes preview.2 installations that failed with SchemaInstaller class not found in a pre-existing worker. The corrected ZIP was tested through native Panel UI upload and Install, a real pre-existing queue worker, real Yarn install/build, both migrations and Enabled status. No manual namespace registration was used. If the Panel already reports a missing public/build/manifest.json, restore its core built assets or rebuild from the installed Panel directory with yarn install --frozen-lockfile followed by yarn build. The ZIP does not replace Panel core assets. The earlier missing-manifest log alone does not reveal why that host's build failed.

## Preview.4 existing-worker migration fix

Laravel caches anonymous migration objects by their file path in long-running workers. A worker that already failed with preview.2 can retain that object after a preview.3 ZIP replaces the file. Preview.4 uses new migration paths, so the same existing worker resolves the corrected migrations. Both are idempotent and preserve existing tables/data. Import preview.4 through the normal UI and click Install if shown; no manual migration edit or database reset is needed. A same-process regression reproduces the preview.2 failure and preview.3 cached failure, then verifies the new paths complete without restarting that process.


## Preview.5 egg access and full catalogs

An enabled egg grants sidebar access for all of that egg's server images. The mapping is only an availability toggle; current images and legacy mapping software/loader/content values do not hide catalogs or decide install targets. Turning off an egg still removes access, and tenant/subuser/native file permissions remain enforced.

Server Software automatically lists all MCJars families. Mods & Plugins has an independent Mods/Plugins selector; Modpacks has its own catalog. Enabled Modrinth/CurseForge providers can be switched directly. Version and loader/platform search filters default empty, including on servers with tracked runtime information. Tabs automatically load the first page. Search/pagination and channel controls narrow results only when the player chooses them. Experimental releases can be browsed independently; administrator policy still governs installing them.

Exact release reviews select the install target from a user choice, a tracked installed runtime, or a single unambiguous provider version/loader. Ambiguous releases remain visible and expose installation choices. Compatibility is checked at review/installation, not used to hide catalogs. A package incompatible with the last tracked runtime needs the matching server software installed first. Manual runtime information is not guessed from the enabled egg. Mods go to mods/ and plugins to plugins/. Modrinth plugin releases with legacy project_type=mod are classified using the selected release's loaders.

Runtime installs use the current image or an image already allowed in native egg configuration that identifies the required Java major (for example java_21). This is a native runtime prerequisite, not an extra Minecraft Manager image mapping. Worlds/config preservation, transfer verification and stopped-state requirements still apply.
## Preview.7 catalog and installation flow

Server pages use scoped responsive styles, provider project thumbnails, compact search and expandable optional filters. Popular projects appear first when browsing. Select server software, Minecraft version and exact build with dropdowns; prepared runtime launchers are installed as server.jar and native startup targets that file. Fabric/Quilt properties and relative libraries remain in place.

For several mods/plugins: choose a project release, confirm its Minecraft version/loader if needed, and Add to selection. Repeat for up to 20 projects using the same version, loader and content type, then Review selection and confirm once. A single durable operation resolves the combined dependency graph, rejects conflicts, stages/verifies all files and uses the existing rollback journal. Provider releases, native permissions and server state are rechecked by the install worker. Selection trays last for the current page session; exact reviews expire after ten minutes. Modpacks and runtime switches remain separate installations. No automatic server start or EULA acceptance.
